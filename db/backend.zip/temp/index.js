
export const tempProducts = [
    {
      "product_sku": "026679",
      "product_categoryId": "400073",
      "product_name": "CROMETTA 85 1jet/ porter’c душевой набор 1,60 м, хром’",
      "product_mpn": "27577000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "CROMETTA 85",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "32.80",
      "product_currency": "EUR",
      "product_price_online": "984",
      "sourcePrice": "21.32",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_026679_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_026679_1.jpg"
      ],
      "description": "Ручной душ Crometta 85 1jet, ½’ (# 28585000), держатель Porter’C (# 27521000), шланг Metaflex 1,25 м  ½’ (# 28266000)",
      parameters: [
        {
          "parameter_id": "26679_Brand",
          "product_sku": "26679",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "26679_Series",
          "product_sku": "26679",
          "parameter_name": "Серия",
          "parameter_value": "CROMETTA 85"
        }
      ]
    },
    {
      "product_sku": "026681",
      "product_categoryId": "400053",
      "product_name": "ECOSTAT Select термостат для душа",
      "product_mpn": "13161000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "Ecostat Select",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "347.20",
      "product_currency": "EUR",
      "product_price_online": "10416",
      "sourcePrice": "225.68",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_026681_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_026681_1.jpg"
      ],
      "description": "Ecostat Select Термостат для душаПредохранительный стопор при 40°C, расход воды: 30 л/мин, расход воды у ручного душа: 30 л/мин, полка из безопасного стекла, поверхность полки: хром или белый, кнопка Ecostop ограничивает расход воды до 10 л/мин",
      parameters: [
        {
          "parameter_id": "26681_000000101",
          "product_sku": "26681",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "26681_000000102",
          "product_sku": "26681",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26681_000000103",
          "product_sku": "26681",
          "parameter_name": "Тип управления",
          "parameter_value": "Термостат"
        },
        {
          "parameter_id": "26681_000000104",
          "product_sku": "26681",
          "parameter_name": "С полочкой",
          "parameter_value": "Да"
        },
        {
          "parameter_id": "26681_000000105",
          "product_sku": "26681",
          "parameter_name": "Положение регулятора",
          "parameter_value": "Сбоку"
        },
        {
          "parameter_id": "26681_000000129",
          "product_sku": "26681",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "26681_000000130",
          "product_sku": "26681",
          "parameter_name": "Форма накладки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26681_Brand",
          "product_sku": "26681",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "26681_Series",
          "product_sku": "26681",
          "parameter_name": "Серия",
          "parameter_value": "Ecostat Select"
        }
      ]
    },
    {
      "product_sku": "026682",
      "product_categoryId": "400013",
      "product_name": "Hansgrohe Запасная часть",
      "product_mpn": "94153000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "HANSGROHE",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "19.10",
      "product_currency": "EUR",
      "product_price_online": "573",
      "sourcePrice": "12.42",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      "description": "Запасная часть, хром.",
      parameters: [
        {
          "parameter_id": "26682_000000025",
          "product_sku": "26682",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "26682_000000026",
          "product_sku": "26682",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "26682_Brand",
          "product_sku": "26682",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "26682_Series",
          "product_sku": "26682",
          "parameter_name": "Серия",
          "parameter_value": "HANSGROHE"
        }
      ]
    },
    {
      "product_sku": "026686",
      "product_categoryId": "400072",
      "product_name": "JESENIK смеситель скрытого монтажа для душа (смеситель.с переключ., верхн.душ 200 мм, ручной душ 120 мм 3 режима)",
      "product_mpn": "VR-15140",
      "manufacturer_name": "IMPRESE",
      "product_seria": "JESENIK",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "101",
      "product_currency": "EUR",
      "product_price_old": "135.0000",
      "product_price_online": "2980",
      "sourcePrice": "78",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_026686_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_026686_1.jpg"
      ],
      "description": "JESENIK смеситель скрытого монтажа для душа(смес.с переключ.,верхн.душ диам.200мм,ручной душ 120мм,3режима)Однорычажный, керамический узел смешивания, подходит для проточных нагревателей, поверхность: хром, форма верхнего душа: круглая, диаметр верхнего душа: 200 мм, функции ручного душа: 3 функции (ливень, массаж, туман), шланг: гибкий, двойное обплетение, 150 см, держатель для ручного душа, расход воды ручного душа: до 11,1 л/мин, расход воды верхнего душа: до 11,2 л/мин",
      parameters: [
        {
          "parameter_id": "26686_000000156",
          "product_sku": "26686",
          "parameter_name": "Ширина лейки верхнего душа, мм",
          "parameter_value": "200"
        },
        {
          "parameter_id": "26686_000000157",
          "product_sku": "26686",
          "parameter_name": "Длина лейки верхнего душа, мм",
          "parameter_value": "200"
        },
        {
          "parameter_id": "26686_000000158",
          "product_sku": "26686",
          "parameter_name": "Длина кронштейна (от стены), мм",
          "parameter_value": "333"
        },
        {
          "parameter_id": "26686_000000160",
          "product_sku": "26686",
          "parameter_name": "Мин. Высота, мм",
          "parameter_value": "0"
        },
        {
          "parameter_id": "26686_000000161",
          "product_sku": "26686",
          "parameter_name": "Регулируемая высота стойки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26686_000000162",
          "product_sku": "26686",
          "parameter_name": "Форма лейки верхнего душа",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "26686_000000163",
          "product_sku": "26686",
          "parameter_name": "Монтаж",
          "parameter_value": "Скрытый"
        },
        {
          "parameter_id": "26686_000000164",
          "product_sku": "26686",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "26686_000000165",
          "product_sku": "26686",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "26686_000000166",
          "product_sku": "26686",
          "parameter_name": "Смеситель",
          "parameter_value": "Для душа"
        },
        {
          "parameter_id": "26686_000000167",
          "product_sku": "26686",
          "parameter_name": "Кол-во режимов ручного душа",
          "parameter_value": "3"
        },
        {
          "parameter_id": "26686_000000168",
          "product_sku": "26686",
          "parameter_name": "Кол-во режимов верхнего душа",
          "parameter_value": "1"
        },
        {
          "parameter_id": "26686_Brand",
          "product_sku": "26686",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "26686_Series",
          "product_sku": "26686",
          "parameter_name": "Серия",
          "parameter_value": "JESENIK"
        }
      ]
    },
    {
      "product_sku": "026689",
      "product_categoryId": "400068",
      "product_name": "JESENIK смеситель для кухни, хром, 35 мм",
      "product_mpn": "20140",
      "manufacturer_name": "IMPRESE",
      "product_seria": "JESENIK",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "36",
      "product_currency": "EUR",
      "product_price_online": "1062",
      "sourcePrice": "25.20",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_026689_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_026689_1.jpg"
      ],
      "description": "JESENIK смеситель для кухни, хром, 35 мм Однорычажный, керамический узел смешивания, расход воды до 7 л/мин, аэратор, подходит для проточных нагревателей\nМодель установленного картриджа Sedal EN- 35 S/D AZ",
      parameters: [
        {
          "parameter_id": "26689_000000106",
          "product_sku": "26689",
          "parameter_name": "Длина излива",
          "parameter_value": "223"
        },
        {
          "parameter_id": "26689_000000107",
          "product_sku": "26689",
          "parameter_name": "Высота излива",
          "parameter_value": "127"
        },
        {
          "parameter_id": "26689_000000108",
          "product_sku": "26689",
          "parameter_name": "Высота смесителя",
          "parameter_value": "140"
        },
        {
          "parameter_id": "26689_000000109",
          "product_sku": "26689",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной"
        },
        {
          "parameter_id": "26689_000000110",
          "product_sku": "26689",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "26689_000000111",
          "product_sku": "26689",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "26689_000000112",
          "product_sku": "26689",
          "parameter_name": "Тип излива",
          "parameter_value": "Длинный"
        },
        {
          "parameter_id": "26689_000000113",
          "product_sku": "26689",
          "parameter_name": "Выдвижной излив",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26689_000000114",
          "product_sku": "26689",
          "parameter_name": "Вывод для фильтрованной в",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26689_000000115",
          "product_sku": "26689",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26689_000000116",
          "product_sku": "26689",
          "parameter_name": "Особенности",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26689_Brand",
          "product_sku": "26689",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "26689_Series",
          "product_sku": "26689",
          "parameter_name": "Серия",
          "parameter_value": "JESENIK"
        }
      ]
    },
    {
      "product_sku": "026690",
      "product_categoryId": "400068",
      "product_name": "JESENIK смеситель для кухни, хром, 35 мм",
      "product_mpn": "20140-15",
      "manufacturer_name": "IMPRESE",
      "product_seria": "JESENIK",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "28",
      "product_currency": "EUR",
      "product_price_old": "35.0000",
      "product_price_online": "826",
      "sourcePrice": "22",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_026690_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_026690_1.jpg"
      ],
      "description": "JESENIK смеситель для кухни, хром, 35 мм Однорычажный, керамический узел смешивания, расход воды до 7 л/мин, аэратор, подходит для проточных нагревателей\nМодель установленного картриджа Sedal EN- 35 S/D AZ",
      parameters: [
        {
          "parameter_id": "26690_000000106",
          "product_sku": "26690",
          "parameter_name": "Длина излива",
          "parameter_value": "151"
        },
        {
          "parameter_id": "26690_000000107",
          "product_sku": "26690",
          "parameter_name": "Высота излива",
          "parameter_value": "73"
        },
        {
          "parameter_id": "26690_000000108",
          "product_sku": "26690",
          "parameter_name": "Высота смесителя",
          "parameter_value": "105"
        },
        {
          "parameter_id": "26690_000000109",
          "product_sku": "26690",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной"
        },
        {
          "parameter_id": "26690_000000110",
          "product_sku": "26690",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "26690_000000111",
          "product_sku": "26690",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "26690_000000112",
          "product_sku": "26690",
          "parameter_name": "Тип излива",
          "parameter_value": "Длинный"
        },
        {
          "parameter_id": "26690_000000113",
          "product_sku": "26690",
          "parameter_name": "Выдвижной излив",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26690_000000114",
          "product_sku": "26690",
          "parameter_name": "Вывод для фильтрованной в",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26690_000000115",
          "product_sku": "26690",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26690_000000116",
          "product_sku": "26690",
          "parameter_name": "Особенности",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26690_Brand",
          "product_sku": "26690",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "26690_Series",
          "product_sku": "26690",
          "parameter_name": "Серия",
          "parameter_value": "JESENIK"
        }
      ]
    },
    {
      "product_sku": "026693",
      "product_categoryId": "400042",
      "product_name": "JESENIK смеситель для ванны, хром, 35 мм",
      "product_mpn": "10140",
      "manufacturer_name": "IMPRESE",
      "product_seria": "JESENIK",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "68",
      "product_currency": "EUR",
      "product_price_online": "2006",
      "sourcePrice": "47.60",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_026693_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_026693_1.jpg"
      ],
      "description": "JESENIK смеситель для ванны, хром, 35 мм Однорычажный, керамический узел смешивания, расход воды до 22 л/мин, аэратор, подходит для проточных нагревателей\nМодель установленного картриджа Sedal EN- 35 С/D",
      parameters: [
        {
          "parameter_id": "26693_000000093",
          "product_sku": "26693",
          "parameter_name": "Длина излива",
          "parameter_value": "171"
        },
        {
          "parameter_id": "26693_000000094",
          "product_sku": "26693",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "26693_000000095",
          "product_sku": "26693",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "26693_000000096",
          "product_sku": "26693",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26693_000000097",
          "product_sku": "26693",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "26693_000000098",
          "product_sku": "26693",
          "parameter_name": "Тип переключателя ванна/душ",
          "parameter_value": "Выжимной"
        },
        {
          "parameter_id": "26693_000000099",
          "product_sku": "26693",
          "parameter_name": "Повротный излив",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26693_000000100",
          "product_sku": "26693",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "2"
        },
        {
          "parameter_id": "26693_000000126",
          "product_sku": "26693",
          "parameter_name": "Кол-во потребителей",
          "parameter_value": "2"
        },
        {
          "parameter_id": "26693_000000128",
          "product_sku": "26693",
          "parameter_name": "Форма накладки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26693_Brand",
          "product_sku": "26693",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "26693_Series",
          "product_sku": "26693",
          "parameter_name": "Серия",
          "parameter_value": "JESENIK"
        }
      ]
    },
    {
      "product_sku": "026704",
      "product_categoryId": "400068",
      "product_name": "KRINICE смеситель для кухни, хром, 35 мм",
      "product_mpn": "55110",
      "manufacturer_name": "IMPRESE",
      "product_seria": "KRINICE",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "50",
      "product_currency": "EUR",
      "product_price_online": "1475",
      "sourcePrice": "35",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_026704_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_026704_1.jpg"
      ],
      "description": "KRINICE смеситель для кухни, хром, 35мм Однорычажный, керамический узел смешивания, расход воды до 7 л/мин, аэратор, подходит для проточных нагревателей\nМодель установленного картриджа Sedal EN- 35 S/D AZ",
      parameters: [
        {
          "parameter_id": "26704_000000106",
          "product_sku": "26704",
          "parameter_name": "Длина излива",
          "parameter_value": "165"
        },
        {
          "parameter_id": "26704_000000107",
          "product_sku": "26704",
          "parameter_name": "Высота излива",
          "parameter_value": "230"
        },
        {
          "parameter_id": "26704_000000108",
          "product_sku": "26704",
          "parameter_name": "Высота смесителя",
          "parameter_value": "256"
        },
        {
          "parameter_id": "26704_000000109",
          "product_sku": "26704",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной"
        },
        {
          "parameter_id": "26704_000000110",
          "product_sku": "26704",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "26704_000000111",
          "product_sku": "26704",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "26704_000000112",
          "product_sku": "26704",
          "parameter_name": "Тип излива",
          "parameter_value": "U-образный"
        },
        {
          "parameter_id": "26704_000000113",
          "product_sku": "26704",
          "parameter_name": "Выдвижной излив",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26704_000000114",
          "product_sku": "26704",
          "parameter_name": "Вывод для фильтрованной в",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26704_000000115",
          "product_sku": "26704",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26704_000000116",
          "product_sku": "26704",
          "parameter_name": "Особенности",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26704_Brand",
          "product_sku": "26704",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "26704_Series",
          "product_sku": "26704",
          "parameter_name": "Серия",
          "parameter_value": "KRINICE"
        }
      ]
    },
    {
      "product_sku": "026705",
      "product_categoryId": "40003",
      "product_name": "KRINICE смеситель для умывальника, хром, 35 мм",
      "product_mpn": "05110",
      "manufacturer_name": "IMPRESE",
      "product_seria": "KRINICE",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "36",
      "product_currency": "EUR",
      "product_price_online": "1062",
      "sourcePrice": "25.20",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_026705_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_026705_1.jpg"
      ],
      "description": "Однорычажный смеситель для раковины, керамический узел смешивания, расход воды до 7 л/мин, аэратор, подходит для проточных нагревателейХарактеристики картриджей, используемых в продукции компании «Imprese»:- максимальная температура горячей воды - 90° С- химическая устойчивость- непригодные условия для образования микроорганизмов- устойчивость к перепадам давления и температуры воды- обеспечивает идеальную пропорцию смешивания горячей и холодной воды- бесшумная работа (уровень шума между 17 и 19 децибел), что обязательно для работы картриджей класса А- гарантия на бесперебойную работу открытие-закрытие не менее 70000 раз - безопасен в использовании в контакте с питьевой водой- диаметр изделий: 25 мм, 35 мм, 40 мм Компания «Imprese» при комплектации своей продукции использует испанские картриджы «SEDAL» класса А (международный сертификат ISO9001). Производитель уверен в качестве своей продукции и гарантирует 5 лет безупречной работы, точность регулировки струи и температуры воды как при низком, так и при высоком давлении.\nМодель установленного картриджа Sedal EN- 35 С/D",
      parameters: [
        {
          "parameter_id": "26705_000000117",
          "product_sku": "26705",
          "parameter_name": "Длина излива",
          "parameter_value": "103"
        },
        {
          "parameter_id": "26705_000000118",
          "product_sku": "26705",
          "parameter_name": "Высота излива",
          "parameter_value": "64"
        },
        {
          "parameter_id": "26705_000000119",
          "product_sku": "26705",
          "parameter_name": "Высота смесителя",
          "parameter_value": "131"
        },
        {
          "parameter_id": "26705_000000120",
          "product_sku": "26705",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной"
        },
        {
          "parameter_id": "26705_000000121",
          "product_sku": "26705",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "26705_000000122",
          "product_sku": "26705",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26705_000000123",
          "product_sku": "26705",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "26705_000000124",
          "product_sku": "26705",
          "parameter_name": "Наличие донного клапана",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26705_000000125",
          "product_sku": "26705",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "1"
        },
        {
          "parameter_id": "26705_Brand",
          "product_sku": "26705",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "26705_Series",
          "product_sku": "26705",
          "parameter_name": "Серия",
          "parameter_value": "KRINICE"
        }
      ]
    },
    {
      "product_sku": "026716",
      "product_categoryId": "400068",
      "product_name": "MALSE смеситель для кухни, хром, 35 мм",
      "product_mpn": "55010",
      "manufacturer_name": "IMPRESE",
      "product_seria": "MALSE",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "50",
      "product_currency": "EUR",
      "product_price_online": "1475",
      "sourcePrice": "35",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_026716_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_026716_1.jpg"
      ],
      "description": "MALSE смеситель для кухни, хром, 35мм Однорычажный, керамический узел смешивания, расход воды до 7 л/мин, аэратор, подходит для проточных нагревателей\nМодель установленного картриджа Sedal EN- 35 S/D AZ",
      parameters: [
        {
          "parameter_id": "26716_000000106",
          "product_sku": "26716",
          "parameter_name": "Длина излива",
          "parameter_value": "182"
        },
        {
          "parameter_id": "26716_000000107",
          "product_sku": "26716",
          "parameter_name": "Высота излива",
          "parameter_value": "228"
        },
        {
          "parameter_id": "26716_000000108",
          "product_sku": "26716",
          "parameter_name": "Высота смесителя",
          "parameter_value": "349"
        },
        {
          "parameter_id": "26716_000000109",
          "product_sku": "26716",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной"
        },
        {
          "parameter_id": "26716_000000110",
          "product_sku": "26716",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Сатин"
        },
        {
          "parameter_id": "26716_000000111",
          "product_sku": "26716",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "26716_000000112",
          "product_sku": "26716",
          "parameter_name": "Тип излива",
          "parameter_value": "U-образный"
        },
        {
          "parameter_id": "26716_000000113",
          "product_sku": "26716",
          "parameter_name": "Выдвижной излив",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26716_000000114",
          "product_sku": "26716",
          "parameter_name": "Вывод для фильтрованной в",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26716_000000115",
          "product_sku": "26716",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26716_000000116",
          "product_sku": "26716",
          "parameter_name": "Особенности",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26716_Brand",
          "product_sku": "26716",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "26716_Series",
          "product_sku": "26716",
          "parameter_name": "Серия",
          "parameter_value": "MALSE"
        }
      ]
    },
    {
      "product_sku": "026729",
      "product_categoryId": "400053",
      "product_name": "RALSKO NEW двухвентильнный смеситель для душа,хром",
      "product_mpn": "15240NEW",
      "manufacturer_name": "IMPRESE",
      "product_seria": "RALSKO NEW",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "33.75",
      "product_currency": "EUR",
      "product_price_old": "45.0000",
      "product_price_online": "996",
      "sourcePrice": "31.50",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_026729_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_026729_1.jpg"
      ],
      "description": "RALSKO NEW двухвентильнный смеситель для душа, хромКрестовые рукоятки, керамический узел смешивания, расход воды до 22 л/мин, подходит для проточных нагревателей",
      parameters: [
        {
          "parameter_id": "26729_Brand",
          "product_sku": "26729",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "26729_Series",
          "product_sku": "26729",
          "parameter_name": "Серия",
          "parameter_value": "RALSKO NEW"
        }
      ]
    },
    {
      "product_sku": "026730",
      "product_categoryId": "40003",
      "product_name": "RALSKO NEW смеситель для раковины двухвентильнный, хром",
      "product_mpn": "05240NEW",
      "manufacturer_name": "IMPRESE",
      "product_seria": "RALSKO NEW",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "40",
      "product_currency": "EUR",
      "product_price_old": "47.0000",
      "product_price_online": "1180",
      "sourcePrice": "32.90",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_026730_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_026730_1.jpg"
      ],
      "description": "RALSKO NEW двухвентильнный смеситель для раковины, хромКрестовые рукоятки, керамический узел смешивания, расход воды до 7 л/мин, аэратор, подходит для проточных нагревателей",
      parameters: [
        {
          "parameter_id": "26730_000000117",
          "product_sku": "26730",
          "parameter_name": "Длина излива",
          "parameter_value": "138"
        },
        {
          "parameter_id": "26730_000000118",
          "product_sku": "26730",
          "parameter_name": "Высота излива",
          "parameter_value": "130"
        },
        {
          "parameter_id": "26730_000000119",
          "product_sku": "26730",
          "parameter_name": "Высота смесителя",
          "parameter_value": "189"
        },
        {
          "parameter_id": "26730_000000120",
          "product_sku": "26730",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной"
        },
        {
          "parameter_id": "26730_000000121",
          "product_sku": "26730",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "26730_000000122",
          "product_sku": "26730",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26730_000000123",
          "product_sku": "26730",
          "parameter_name": "Тип управления",
          "parameter_value": "Двухвентильный"
        },
        {
          "parameter_id": "26730_000000124",
          "product_sku": "26730",
          "parameter_name": "Наличие донного клапана",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26730_000000125",
          "product_sku": "26730",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "1"
        },
        {
          "parameter_id": "26730_Brand",
          "product_sku": "26730",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "26730_Series",
          "product_sku": "26730",
          "parameter_name": "Серия",
          "parameter_value": "RALSKO NEW"
        }
      ]
    },
    {
      "product_sku": "026732",
      "product_categoryId": "400068",
      "product_name": "DAICY смеситель для кухни однорычажный с подключением питьевой воды.",
      "product_mpn": "55009-F",
      "manufacturer_name": "IMPRESE",
      "product_seria": "DAICY",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "112",
      "product_currency": "EUR",
      "product_price_online": "3304",
      "sourcePrice": "78.40",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_026732_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_026732_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_026732_2.jpg"
      ],
      "description": "DAICY смеситель для кухни однорычажный с подключением питьевой воды, латунь, поворотный излив, цвет - хром. Керамическая кран-букса для запора питьевой воды. Расход воды до 7 л/м, аератор от Neoperl. Подходит для проточных нагревателей. Шланги подключения воды. В комплекте к данному смесителю прилагается специальное крепление — большая гайка.\nМодель установленного картриджа Sedal EN- 35 С/D",
      parameters: [
        {
          "parameter_id": "26732_000000106",
          "product_sku": "26732",
          "parameter_name": "Длина излива",
          "parameter_value": "238"
        },
        {
          "parameter_id": "26732_000000107",
          "product_sku": "26732",
          "parameter_name": "Высота излива",
          "parameter_value": "311"
        },
        {
          "parameter_id": "26732_000000108",
          "product_sku": "26732",
          "parameter_name": "Высота смесителя",
          "parameter_value": "349"
        },
        {
          "parameter_id": "26732_000000109",
          "product_sku": "26732",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной"
        },
        {
          "parameter_id": "26732_000000110",
          "product_sku": "26732",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "26732_000000111",
          "product_sku": "26732",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "26732_000000112",
          "product_sku": "26732",
          "parameter_name": "Тип излива",
          "parameter_value": "Г-образный"
        },
        {
          "parameter_id": "26732_000000113",
          "product_sku": "26732",
          "parameter_name": "Выдвижной излив",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26732_000000114",
          "product_sku": "26732",
          "parameter_name": "Вывод для фильтрованной в",
          "parameter_value": "Да"
        },
        {
          "parameter_id": "26732_000000115",
          "product_sku": "26732",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26732_000000116",
          "product_sku": "26732",
          "parameter_name": "Особенности",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "26732_Brand",
          "product_sku": "26732",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "26732_Series",
          "product_sku": "26732",
          "parameter_name": "Серия",
          "parameter_value": "DAICY"
        }
      ]
    },
    {
      "product_sku": "026733",
      "product_categoryId": "400068",
      "product_name": "TOBIO смеситель для кухни двухвентильный 1/2 \"крестики\", поверхность титан, 40 мм",
      "product_mpn": "TOB2008R satin",
      "manufacturer_name": "TOBIO",
      "product_seria": "",
      "product_status": "Распродажа",
      "product_price": "21.06",
      "product_currency": "USD",
      "product_price_online": "21.06",
      "sourcePrice": "11.79",
      "sourceCurrency": "USD",
      "product_availability_local": "true",
      "ext_info": "false",
      "description": "Смеситель для кухни настольный, двухрычажный, поворотный излив, хром.",
      parameters: [
        {
          "parameter_id": "26733_Brand",
          "product_sku": "26733",
          "parameter_name": "Бренд",
          "parameter_value": "TOBIO"
        },
        {
          "parameter_id": "26733_Series",
          "product_sku": "26733",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "027307",
      "product_categoryId": "400072",
      "product_name": "WITOW система душевая (смеситель для ванны, верхний и ручной душ)",
      "product_mpn": "T-10080",
      "manufacturer_name": "IMPRESE",
      "product_seria": "WITOW",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "151",
      "product_currency": "EUR",
      "product_price_old": "215.0000",
      "product_price_online": "4455",
      "sourcePrice": "116",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_027307_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_027307_1.jpg"
      ],
      "description": "WITOW система душевая (смеситель для ванны, верхний и ручной душ) \nДушевая колонна, материал: латунь, поверхность: хром, высота душевой колонны: 1420 мм, диаметр трубки душевой колонны: 25 мм, диаметр держателя верхней лейки: 25 мм, диаметр верхнего душа: 200 мм, форма верхнего душа: круглая, диаметр ручного душа: 100 мм, функции ручного душа: 1 функция (ливень), держатель для ручного душа, шланг: гибкий, двойное обплетения, 150 см, расход воды ручного душа: до 11,1 л/мин, расход воды верхнего душа: до 11,2 л/мин, смеситель для душа однорычажный\nМодель установленного картриджа Sedal EN- 35 S/D AZ",
      parameters: [
        {
          "parameter_id": "27307_000000156",
          "product_sku": "27307",
          "parameter_name": "Ширина лейки верхнего душа, мм",
          "parameter_value": "200"
        },
        {
          "parameter_id": "27307_000000157",
          "product_sku": "27307",
          "parameter_name": "Длина лейки верхнего душа, мм",
          "parameter_value": "200"
        },
        {
          "parameter_id": "27307_000000158",
          "product_sku": "27307",
          "parameter_name": "Длина кронштейна (от стены), мм",
          "parameter_value": "435"
        },
        {
          "parameter_id": "27307_000000160",
          "product_sku": "27307",
          "parameter_name": "Мин. Высота, мм",
          "parameter_value": "1 420"
        },
        {
          "parameter_id": "27307_000000161",
          "product_sku": "27307",
          "parameter_name": "Регулируемая высота стойки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "27307_000000162",
          "product_sku": "27307",
          "parameter_name": "Форма лейки верхнего душа",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "27307_000000163",
          "product_sku": "27307",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "27307_000000164",
          "product_sku": "27307",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "27307_000000165",
          "product_sku": "27307",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "27307_000000166",
          "product_sku": "27307",
          "parameter_name": "Смеситель",
          "parameter_value": "Для ванны"
        },
        {
          "parameter_id": "27307_000000167",
          "product_sku": "27307",
          "parameter_name": "Кол-во режимов ручного душа",
          "parameter_value": "1"
        },
        {
          "parameter_id": "27307_000000168",
          "product_sku": "27307",
          "parameter_name": "Кол-во режимов верхнего душа",
          "parameter_value": "1"
        },
        {
          "parameter_id": "27307_Brand",
          "product_sku": "27307",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "27307_Series",
          "product_sku": "27307",
          "parameter_name": "Серия",
          "parameter_value": "WITOW"
        }
      ]
    },
    {
      "product_sku": "027310",
      "product_categoryId": "400072",
      "product_name": "WITOW система душевая (смеситель для душа, верхний и ручной душ)",
      "product_mpn": "T-15080",
      "manufacturer_name": "IMPRESE",
      "product_seria": "WITOW",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "135",
      "product_currency": "EUR",
      "product_price_old": "180.0000",
      "product_price_online": "3983",
      "sourcePrice": "104",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_027310_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_027310_1.jpg"
      ],
      "description": "WITOW система душевая (смеситель для душа, верхний и ручной душ) Душевая колонна, материал: латунь, поверхность: хром, высота душевой колонны: 1327 мм, диаметр трубки душевой колонны: 25 мм, диаметр держателя верхней лейки: 25 мм, диаметр верхнего душа: 200 мм, форма верхнего душа: круглая, диаметр ручного душа: 100 мм, функции ручного душа: 1 функция (ливень), держатель для ручного душа, шланг: гибкий, нерж. сталь, двойная оплётка, 150 см, расход воды ручного душа: до 11,1 л/мин, расход воды верхнего душа: до 11,2 л/мин, смеситель для душа однорычажный\nМодель установленного картриджа Sedal EN- 35 S/D AZ",
      parameters: [
        {
          "parameter_id": "27310_000000156",
          "product_sku": "27310",
          "parameter_name": "Ширина лейки верхнего душа, мм",
          "parameter_value": "200"
        },
        {
          "parameter_id": "27310_000000157",
          "product_sku": "27310",
          "parameter_name": "Длина лейки верхнего душа, мм",
          "parameter_value": "200"
        },
        {
          "parameter_id": "27310_000000158",
          "product_sku": "27310",
          "parameter_name": "Длина кронштейна (от стены), мм",
          "parameter_value": "435"
        },
        {
          "parameter_id": "27310_000000160",
          "product_sku": "27310",
          "parameter_name": "Мин. Высота, мм",
          "parameter_value": "1 327"
        },
        {
          "parameter_id": "27310_000000161",
          "product_sku": "27310",
          "parameter_name": "Регулируемая высота стойки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "27310_000000162",
          "product_sku": "27310",
          "parameter_name": "Форма лейки верхнего душа",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "27310_000000163",
          "product_sku": "27310",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "27310_000000164",
          "product_sku": "27310",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "27310_000000165",
          "product_sku": "27310",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "27310_000000166",
          "product_sku": "27310",
          "parameter_name": "Смеситель",
          "parameter_value": "Для душа"
        },
        {
          "parameter_id": "27310_000000167",
          "product_sku": "27310",
          "parameter_name": "Кол-во режимов ручного душа",
          "parameter_value": "1"
        },
        {
          "parameter_id": "27310_000000168",
          "product_sku": "27310",
          "parameter_name": "Кол-во режимов верхнего душа",
          "parameter_value": "1"
        },
        {
          "parameter_id": "27310_Brand",
          "product_sku": "27310",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "27310_Series",
          "product_sku": "27310",
          "parameter_name": "Серия",
          "parameter_value": "WITOW"
        }
      ]
    },
    {
      "product_sku": "027315",
      "product_categoryId": "400032",
      "product_name": "CUTHNA stribro смеситель для биде двухвентильный, хром",
      "product_mpn": "40280 stribro",
      "manufacturer_name": "IMPRESE",
      "product_seria": "CUTHNA",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "49",
      "product_currency": "EUR",
      "product_price_online": "1446",
      "sourcePrice": "24.50",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_027315_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_027315_1.jpg"
      ],
      "description": "Cuthna stribro двухвентильный смеситель для биде, хром Крестовые рукоятки, керамический узел смешивания, расход воды до 7 л/мин, аэратор, подходит для проточных нагревателей",
      parameters: [
        {
          "parameter_id": "27315_000000087",
          "product_sku": "27315",
          "parameter_name": "Длина излива",
          "parameter_value": "11"
        },
        {
          "parameter_id": "27315_000000088",
          "product_sku": "27315",
          "parameter_name": "Высота излива",
          "parameter_value": "9,5"
        },
        {
          "parameter_id": "27315_000000089",
          "product_sku": "27315",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "27315_000000090",
          "product_sku": "27315",
          "parameter_name": "Тип управления",
          "parameter_value": "Двухвентильный"
        },
        {
          "parameter_id": "27315_000000091",
          "product_sku": "27315",
          "parameter_name": "Наличие донного клапана",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "27315_000000092",
          "product_sku": "27315",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "1"
        },
        {
          "parameter_id": "27315_Brand",
          "product_sku": "27315",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "27315_Series",
          "product_sku": "27315",
          "parameter_name": "Серия",
          "parameter_value": "CUTHNA"
        }
      ]
    },
    {
      "product_sku": "027318",
      "product_categoryId": "400042",
      "product_name": "CUTHNA stribro смеситель для ванны двухвентильный, хром",
      "product_mpn": "10280 stribro",
      "manufacturer_name": "IMPRESE",
      "product_seria": "CUTHNA",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "110",
      "product_currency": "EUR",
      "product_price_online": "3245",
      "sourcePrice": "55",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_027318_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_027318_1.jpg"
      ],
      "description": "Cuthna stribro двухвентильный смеситель для ванны, хром Крестовые рукоятки, керамический узел смешивания, расход воды до 22 л/мин, аэратор, подходит для проточных нагревателей",
      parameters: [
        {
          "parameter_id": "27318_000000093",
          "product_sku": "27318",
          "parameter_name": "Длина излива",
          "parameter_value": "175"
        },
        {
          "parameter_id": "27318_000000094",
          "product_sku": "27318",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "27318_000000095",
          "product_sku": "27318",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "27318_000000096",
          "product_sku": "27318",
          "parameter_name": "Комплектация",
          "parameter_value": "Лейка, шланг"
        },
        {
          "parameter_id": "27318_000000097",
          "product_sku": "27318",
          "parameter_name": "Тип управления",
          "parameter_value": "Двухвентильный"
        },
        {
          "parameter_id": "27318_000000098",
          "product_sku": "27318",
          "parameter_name": "Тип переключателя ванна/душ",
          "parameter_value": "Поворотный"
        },
        {
          "parameter_id": "27318_000000099",
          "product_sku": "27318",
          "parameter_name": "Повротный излив",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "27318_000000100",
          "product_sku": "27318",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "2"
        },
        {
          "parameter_id": "27318_000000126",
          "product_sku": "27318",
          "parameter_name": "Кол-во потребителей",
          "parameter_value": "2"
        },
        {
          "parameter_id": "27318_000000128",
          "product_sku": "27318",
          "parameter_name": "Форма накладки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "27318_Brand",
          "product_sku": "27318",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "27318_Series",
          "product_sku": "27318",
          "parameter_name": "Серия",
          "parameter_value": "CUTHNA"
        }
      ]
    },
    {
      "product_sku": "027320",
      "product_categoryId": "400042",
      "product_name": "WITOW смеситель для ванны, хром, 35 мм",
      "product_mpn": "10080",
      "manufacturer_name": "IMPRESE",
      "product_seria": "WITOW",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "62",
      "product_currency": "EUR",
      "product_price_online": "1829",
      "sourcePrice": "43.40",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_027320_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_027320_1.jpg"
      ],
      "description": "WITOW смеситель для ванны, хром, 35 мм Однорычажный, керамический узел смешивания, расход воды до 22 л/мин, аэратор, подходит для проточных нагревателей\nМодель установленного картриджа Sedal EN- 35 S/D AZ",
      parameters: [
        {
          "parameter_id": "27320_000000093",
          "product_sku": "27320",
          "parameter_name": "Длина излива",
          "parameter_value": "162"
        },
        {
          "parameter_id": "27320_000000094",
          "product_sku": "27320",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "27320_000000095",
          "product_sku": "27320",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "27320_000000096",
          "product_sku": "27320",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "27320_000000097",
          "product_sku": "27320",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "27320_000000098",
          "product_sku": "27320",
          "parameter_name": "Тип переключателя ванна/душ",
          "parameter_value": "Выжимной"
        },
        {
          "parameter_id": "27320_000000099",
          "product_sku": "27320",
          "parameter_name": "Повротный излив",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "27320_000000100",
          "product_sku": "27320",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "2"
        },
        {
          "parameter_id": "27320_000000126",
          "product_sku": "27320",
          "parameter_name": "Кол-во потребителей",
          "parameter_value": "2"
        },
        {
          "parameter_id": "27320_000000128",
          "product_sku": "27320",
          "parameter_name": "Форма накладки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "27320_Brand",
          "product_sku": "27320",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "27320_Series",
          "product_sku": "27320",
          "parameter_name": "Серия",
          "parameter_value": "WITOW"
        }
      ]
    },
    {
      "product_sku": "027322",
      "product_categoryId": "400042",
      "product_name": "HORAK смеситель для ванны, хром, 40 мм",
      "product_mpn": "10170",
      "manufacturer_name": "IMPRESE",
      "product_seria": "HORAK",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "70",
      "product_currency": "EUR",
      "product_price_online": "2065",
      "sourcePrice": "49",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_027322_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_027322_1.jpg"
      ],
      "description": "HORAK смеситель для ванны, хром, 40 ммОднорычажный, керамический узел смешивания, расход воды до 22 л/мин, аэратор, подходит для проточных нагревателей\nМодель установленного картриджа Sedal D-40AZSD",
      parameters: [
        {
          "parameter_id": "27322_000000093",
          "product_sku": "27322",
          "parameter_name": "Длина излива",
          "parameter_value": "184"
        },
        {
          "parameter_id": "27322_000000094",
          "product_sku": "27322",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "27322_000000095",
          "product_sku": "27322",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "27322_000000096",
          "product_sku": "27322",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "27322_000000097",
          "product_sku": "27322",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "27322_000000098",
          "product_sku": "27322",
          "parameter_name": "Тип переключателя ванна/душ",
          "parameter_value": "Выжимной"
        },
        {
          "parameter_id": "27322_000000099",
          "product_sku": "27322",
          "parameter_name": "Повротный излив",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "27322_000000100",
          "product_sku": "27322",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "2"
        },
        {
          "parameter_id": "27322_000000126",
          "product_sku": "27322",
          "parameter_name": "Кол-во потребителей",
          "parameter_value": "2"
        },
        {
          "parameter_id": "27322_000000128",
          "product_sku": "27322",
          "parameter_name": "Форма накладки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "27322_Brand",
          "product_sku": "27322",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "27322_Series",
          "product_sku": "27322",
          "parameter_name": "Серия",
          "parameter_value": "HORAK"
        }
      ]
    },
    {
      "product_sku": "027324",
      "product_categoryId": "400053",
      "product_name": "WITOW смеситель для душа, хром, 35 мм",
      "product_mpn": "15080",
      "manufacturer_name": "IMPRESE",
      "product_seria": "WITOW",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "45",
      "product_currency": "EUR",
      "product_price_online": "1328",
      "sourcePrice": "31.50",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_027324_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_027324_1.jpg"
      ],
      "description": "WITOW смеситель для душа, хром, 35 мм Однорычажный, керамический узел смешивания, расход воды до 22 л/мин, аэратор, подходит для проточных нагревателей\nМодель установленного картриджа Sedal EN- 35 S/D AZ",
      parameters: [
        {
          "parameter_id": "27324_000000101",
          "product_sku": "27324",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "27324_000000102",
          "product_sku": "27324",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "27324_000000103",
          "product_sku": "27324",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "27324_000000104",
          "product_sku": "27324",
          "parameter_name": "С полочкой",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "27324_000000105",
          "product_sku": "27324",
          "parameter_name": "Положение регулятора",
          "parameter_value": "Спереди по центру"
        },
        {
          "parameter_id": "27324_000000129",
          "product_sku": "27324",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "27324_000000130",
          "product_sku": "27324",
          "parameter_name": "Форма накладки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "27324_Brand",
          "product_sku": "27324",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "27324_Series",
          "product_sku": "27324",
          "parameter_name": "Серия",
          "parameter_value": "WITOW"
        }
      ]
    },
    {
      "product_sku": "027326",
      "product_categoryId": "400053",
      "product_name": "HORAK смеситель для душа, хром, 40 мм",
      "product_mpn": "15170",
      "manufacturer_name": "IMPRESE",
      "product_seria": "HORAK",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "54",
      "product_currency": "EUR",
      "product_price_online": "1593",
      "sourcePrice": "37.80",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_027326_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_027326_1.jpg"
      ],
      "description": "HORAK смеситель для душа, хром, 40 мм Однорычажный, керамический узел смешивания, расход воды до 22 л/мин, аэратор, подходит для проточных нагревателей\nМодель установленного картриджа Sedal D-40AZSD",
      parameters: [
        {
          "parameter_id": "27326_000000101",
          "product_sku": "27326",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "27326_000000102",
          "product_sku": "27326",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "27326_000000103",
          "product_sku": "27326",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "27326_000000104",
          "product_sku": "27326",
          "parameter_name": "С полочкой",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "27326_000000105",
          "product_sku": "27326",
          "parameter_name": "Положение регулятора",
          "parameter_value": "Спереди по центру"
        },
        {
          "parameter_id": "27326_000000129",
          "product_sku": "27326",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "27326_000000130",
          "product_sku": "27326",
          "parameter_name": "Форма накладки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "27326_Brand",
          "product_sku": "27326",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "27326_Series",
          "product_sku": "27326",
          "parameter_name": "Серия",
          "parameter_value": "HORAK"
        }
      ]
    },
    {
      "product_sku": "027331",
      "product_categoryId": "40003",
      "product_name": "CUTHNA stribro смеситель для умывальника двухвентильный, хром",
      "product_mpn": "05280 stribro",
      "manufacturer_name": "IMPRESE",
      "product_seria": "CUTHNA",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "49",
      "product_currency": "EUR",
      "product_price_online": "1446",
      "sourcePrice": "24.50",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_027331_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_027331_1.jpg"
      ],
      "description": "Cuthna stribro двухвентильный смеситель для раковины, хром Крестовые рукоятки, керамический узел смешивания, расход воды до 7 л/мин, аэратор, подходит для проточных нагревателей",
      parameters: [
        {
          "parameter_id": "27331_000000117",
          "product_sku": "27331",
          "parameter_name": "Длина излива",
          "parameter_value": "124"
        },
        {
          "parameter_id": "27331_000000118",
          "product_sku": "27331",
          "parameter_name": "Высота излива",
          "parameter_value": "86"
        },
        {
          "parameter_id": "27331_000000119",
          "product_sku": "27331",
          "parameter_name": "Высота смесителя",
          "parameter_value": "120"
        },
        {
          "parameter_id": "27331_000000120",
          "product_sku": "27331",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной"
        },
        {
          "parameter_id": "27331_000000121",
          "product_sku": "27331",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "27331_000000122",
          "product_sku": "27331",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "27331_000000123",
          "product_sku": "27331",
          "parameter_name": "Тип управления",
          "parameter_value": "Двухвентильный"
        },
        {
          "parameter_id": "27331_000000124",
          "product_sku": "27331",
          "parameter_name": "Наличие донного клапана",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "27331_000000125",
          "product_sku": "27331",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "1"
        },
        {
          "parameter_id": "27331_Brand",
          "product_sku": "27331",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "27331_Series",
          "product_sku": "27331",
          "parameter_name": "Серия",
          "parameter_value": "CUTHNA"
        }
      ]
    },
    {
      "product_sku": "027335",
      "product_categoryId": "40003",
      "product_name": "HORAK смеситель для умывальника, хром, 40 мм",
      "product_mpn": "05170",
      "manufacturer_name": "IMPRESE",
      "product_seria": "HORAK",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "48",
      "product_currency": "EUR",
      "product_price_online": "1416",
      "sourcePrice": "33.60",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_027335_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_027335_1.jpg"
      ],
      "description": "Однорычажный смеситель для умывальника, керамический узел смешивания, расход воды до 7 л/мин, аэратор, подходит для работы с проточным водонагревателем. хром\nМодель установленного картриджа Sedal D-40AZSD",
      parameters: [
        {
          "parameter_id": "27335_000000117",
          "product_sku": "27335",
          "parameter_name": "Длина излива",
          "parameter_value": "118"
        },
        {
          "parameter_id": "27335_000000118",
          "product_sku": "27335",
          "parameter_name": "Высота излива",
          "parameter_value": "80"
        },
        {
          "parameter_id": "27335_000000119",
          "product_sku": "27335",
          "parameter_name": "Высота смесителя",
          "parameter_value": "176"
        },
        {
          "parameter_id": "27335_000000120",
          "product_sku": "27335",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной"
        },
        {
          "parameter_id": "27335_000000121",
          "product_sku": "27335",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "27335_000000122",
          "product_sku": "27335",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "27335_000000123",
          "product_sku": "27335",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "27335_000000124",
          "product_sku": "27335",
          "parameter_name": "Наличие донного клапана",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "27335_000000125",
          "product_sku": "27335",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "1"
        },
        {
          "parameter_id": "27335_Brand",
          "product_sku": "27335",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "27335_Series",
          "product_sku": "27335",
          "parameter_name": "Серия",
          "parameter_value": "HORAK"
        }
      ]
    },
    {
      "product_sku": "027816",
      "product_categoryId": "1800074",
      "product_name": "PALACE унитаз подвесной 36*56см",
      "product_mpn": "H8207000000001",
      "manufacturer_name": "LAUFEN",
      "product_seria": "PALACE",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 31
      },
      "exchangeRate_product_price_online": {
        "EUR": 31
      },
      "product_price": "302.38",
      "product_currency": "EUR",
      "product_price_online": "9374",
      "sourcePrice": "211.67",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_027816_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_027816_1.jpg"
      ],
      "description": "Унитаз подвесной, глубокое смывание\nСиденье в комплект не входит. Рекомендуется сиденье 891700",
      parameters: [
        {
          "parameter_id": "27816_000000041",
          "product_sku": "27816",
          "parameter_name": "Длина",
          "parameter_value": "560"
        },
        {
          "parameter_id": "27816_000000042",
          "product_sku": "27816",
          "parameter_name": "Ширина",
          "parameter_value": "360"
        },
        {
          "parameter_id": "27816_000000043",
          "product_sku": "27816",
          "parameter_name": "Высота",
          "parameter_value": "380"
        },
        {
          "parameter_id": "27816_000000044",
          "product_sku": "27816",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "27816_000000045",
          "product_sku": "27816",
          "parameter_name": "Подключение к канализации",
          "parameter_value": "Горизонтальное"
        },
        {
          "parameter_id": "27816_000000046",
          "product_sku": "27816",
          "parameter_name": "Безободковый",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "27816_000000047",
          "product_sku": "27816",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "27816_000000048",
          "product_sku": "27816",
          "parameter_name": "Тип изделия",
          "parameter_value": "Унитаз подвесной"
        },
        {
          "parameter_id": "27816_000000049",
          "product_sku": "27816",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "27816_000000050",
          "product_sku": "27816",
          "parameter_name": "Комплектация",
          "parameter_value": "Без бачка"
        },
        {
          "parameter_id": "27816_000000051",
          "product_sku": "27816",
          "parameter_name": "Тип слива бачка",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "27816_000000052",
          "product_sku": "27816",
          "parameter_name": "Подвод воды",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "27816_000000053",
          "product_sku": "27816",
          "parameter_name": "Сиденье, крышка",
          "parameter_value": "Без сиденья"
        },
        {
          "parameter_id": "27816_000000054",
          "product_sku": "27816",
          "parameter_name": "Материал сиденья",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "27816_000000055",
          "product_sku": "27816",
          "parameter_name": "Унитаз с функцией биде",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "27816_Brand",
          "product_sku": "27816",
          "parameter_name": "Бренд",
          "parameter_value": "LAUFEN"
        },
        {
          "parameter_id": "27816_Series",
          "product_sku": "27816",
          "parameter_name": "Серия",
          "parameter_value": "PALACE"
        }
      ]
    },
    {
      "product_sku": "027817",
      "product_categoryId": "180008",
      "product_name": "PALACE бачок, подвод воды слева/справа/посередине",
      "product_mpn": "H8287000002781",
      "manufacturer_name": "LAUFEN",
      "product_seria": "PALACE",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 31
      },
      "exchangeRate_product_price_online": {
        "EUR": 31
      },
      "product_price": "193.96",
      "product_currency": "EUR",
      "product_price_online": "6013",
      "sourcePrice": "135.77",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_027817_0.jpg"
      ],
      "description": "Бачок, подвод воды (слева или справа) и сзади по центру",
      parameters: [
        {
          "parameter_id": "27817_000000018",
          "product_sku": "27817",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "27817_000000019",
          "product_sku": "27817",
          "parameter_name": "Подвод воды",
          "parameter_value": "Боковой"
        },
        {
          "parameter_id": "27817_000000022",
          "product_sku": "27817",
          "parameter_name": "Тип управления",
          "parameter_value": "Двойной"
        },
        {
          "parameter_id": "27817_000000026",
          "product_sku": "27817",
          "parameter_name": "Страна производитель",
          "parameter_value": "Швейцария"
        },
        {
          "parameter_id": "27817_Brand",
          "product_sku": "27817",
          "parameter_name": "Бренд",
          "parameter_value": "LAUFEN"
        },
        {
          "parameter_id": "27817_Series",
          "product_sku": "27817",
          "parameter_name": "Серия",
          "parameter_value": "PALACE"
        }
      ]
    },
    {
      "product_sku": "027818",
      "product_categoryId": "1800054",
      "product_name": "PALACE биде подвесное 36*43см",
      "product_mpn": "H8307010003041",
      "manufacturer_name": "LAUFEN",
      "product_seria": "PALACE",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 31
      },
      "exchangeRate_product_price_online": {
        "EUR": 31
      },
      "product_price": "274.69",
      "product_currency": "EUR",
      "product_price_online": "8515",
      "sourcePrice": "192.28",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_027818_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_027818_1.jpg"
      ],
      "description": "Биде с наличием одного отверстия под смеситель, с переливом",
      parameters: [
        {
          "parameter_id": "27818_000000014",
          "product_sku": "27818",
          "parameter_name": "Глубина",
          "parameter_value": "560"
        },
        {
          "parameter_id": "27818_000000016",
          "product_sku": "27818",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "27818_000000018",
          "product_sku": "27818",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "27818_000000023",
          "product_sku": "27818",
          "parameter_name": "Тип установки смесителя",
          "parameter_value": "1 отверстие"
        },
        {
          "parameter_id": "27818_000000026",
          "product_sku": "27818",
          "parameter_name": "Страна производитель",
          "parameter_value": "Швейцария"
        },
        {
          "parameter_id": "27818_000000029",
          "product_sku": "27818",
          "parameter_name": "Перелив",
          "parameter_value": "С переливом"
        },
        {
          "parameter_id": "27818_Brand",
          "product_sku": "27818",
          "parameter_name": "Бренд",
          "parameter_value": "LAUFEN"
        },
        {
          "parameter_id": "27818_Series",
          "product_sku": "27818",
          "parameter_name": "Серия",
          "parameter_value": "PALACE"
        }
      ]
    },
    {
      "product_sku": "027819",
      "product_categoryId": "180001",
      "product_name": "PALACE унитаз напольный, слив вертикальный , выпуск Vario, без бачка",
      "product_mpn": "H8247060000001",
      "manufacturer_name": "LAUFEN",
      "product_seria": "PALACE",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 31
      },
      "exchangeRate_product_price_online": {
        "EUR": 31
      },
      "product_price": "329.81",
      "product_currency": "EUR",
      "product_price_online": "10224",
      "sourcePrice": "230.87",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_027819_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_027819_1.jpg"
      ],
      "description": "Напольный унитаз, глубокое смывание, выпуск vario 70-305\nСиденье в комплект не входит. Рекомендуется сиденье 891700, 891701\nБачок в комплект не входит. Рекомендуется бачок 828703, 828705",
      parameters: [
        {
          "parameter_id": "27819_000000041",
          "product_sku": "27819",
          "parameter_name": "Длина",
          "parameter_value": "700"
        },
        {
          "parameter_id": "27819_000000042",
          "product_sku": "27819",
          "parameter_name": "Ширина",
          "parameter_value": "360"
        },
        {
          "parameter_id": "27819_000000043",
          "product_sku": "27819",
          "parameter_name": "Высота",
          "parameter_value": "400"
        },
        {
          "parameter_id": "27819_000000044",
          "product_sku": "27819",
          "parameter_name": "Монтаж",
          "parameter_value": "Напольный"
        },
        {
          "parameter_id": "27819_000000045",
          "product_sku": "27819",
          "parameter_name": "Подключение к канализации",
          "parameter_value": "Универсальное"
        },
        {
          "parameter_id": "27819_000000046",
          "product_sku": "27819",
          "parameter_name": "Безободковый",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "27819_000000047",
          "product_sku": "27819",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "27819_000000048",
          "product_sku": "27819",
          "parameter_name": "Тип изделия",
          "parameter_value": "Унитаз-компакт"
        },
        {
          "parameter_id": "27819_000000049",
          "product_sku": "27819",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "27819_000000050",
          "product_sku": "27819",
          "parameter_name": "Комплектация",
          "parameter_value": "Без бачка"
        },
        {
          "parameter_id": "27819_000000051",
          "product_sku": "27819",
          "parameter_name": "Тип слива бачка",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "27819_000000052",
          "product_sku": "27819",
          "parameter_name": "Подвод воды",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "27819_000000053",
          "product_sku": "27819",
          "parameter_name": "Сиденье, крышка",
          "parameter_value": "Без сиденья"
        },
        {
          "parameter_id": "27819_000000054",
          "product_sku": "27819",
          "parameter_name": "Материал сиденья",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "27819_000000055",
          "product_sku": "27819",
          "parameter_name": "Унитаз с функцией биде",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "27819_Brand",
          "product_sku": "27819",
          "parameter_name": "Бренд",
          "parameter_value": "LAUFEN"
        },
        {
          "parameter_id": "27819_Series",
          "product_sku": "27819",
          "parameter_name": "Серия",
          "parameter_value": "PALACE"
        }
      ]
    },
    {
      "product_sku": "028629",
      "product_categoryId": "400072",
      "product_name": "Raindance Select S 240 Showerpipe Душевая система с Термостатом",
      "product_mpn": "27115000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "RAINDANCE SELECT S SHOWERPIPE",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "824",
      "product_currency": "EUR",
      "product_price_online": "24720",
      "sourcePrice": "535.60",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_028629_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_028629_1.jpg"
      ],
      "description": "Raindance Select S 240 Showerpipe Душевая система с Термостатом Размер душевого диска: 240 mm, тип струи: RainAir (дождевая струя с подмешиванием воздуха), расход воды при режиме RainAir: 17 л/мин., поверхность душевого диска: хром, длина  держателя для душа: 460 mm, поворотный держатель для душа, термостат Ecostat Comfort, предохранительный стопор при 40°C, настройка ограничения температуры горячей воды, управление путем поворота, вид монтажа: внешний, держатель для ручного душа с регулируемой высотой",
      parameters: [
        {
          "parameter_id": "28629_000000156",
          "product_sku": "28629",
          "parameter_name": "Ширина лейки верхнего душа, мм",
          "parameter_value": "236"
        },
        {
          "parameter_id": "28629_000000157",
          "product_sku": "28629",
          "parameter_name": "Длина лейки верхнего душа, мм",
          "parameter_value": "236"
        },
        {
          "parameter_id": "28629_000000158",
          "product_sku": "28629",
          "parameter_name": "Длина кронштейна (от стены), мм",
          "parameter_value": "445"
        },
        {
          "parameter_id": "28629_000000160",
          "product_sku": "28629",
          "parameter_name": "Мин. Высота, мм",
          "parameter_value": "1 212"
        },
        {
          "parameter_id": "28629_000000161",
          "product_sku": "28629",
          "parameter_name": "Регулируемая высота стойки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "28629_000000162",
          "product_sku": "28629",
          "parameter_name": "Форма лейки верхнего душа",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "28629_000000163",
          "product_sku": "28629",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "28629_000000164",
          "product_sku": "28629",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "28629_000000165",
          "product_sku": "28629",
          "parameter_name": "Тип управления",
          "parameter_value": "Термостат"
        },
        {
          "parameter_id": "28629_000000166",
          "product_sku": "28629",
          "parameter_name": "Смеситель",
          "parameter_value": "Для душа"
        },
        {
          "parameter_id": "28629_000000167",
          "product_sku": "28629",
          "parameter_name": "Кол-во режимов ручного душа",
          "parameter_value": "3"
        },
        {
          "parameter_id": "28629_000000168",
          "product_sku": "28629",
          "parameter_name": "Кол-во режимов верхнего душа",
          "parameter_value": "1"
        },
        {
          "parameter_id": "28629_Brand",
          "product_sku": "28629",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "28629_Series",
          "product_sku": "28629",
          "parameter_name": "Серия",
          "parameter_value": "RAINDANCE SELECT S SHOWERPIPE"
        }
      ]
    },
    {
      "product_sku": "028631",
      "product_categoryId": "180001",
      "product_name": "RUNA компакт напольный гор.выпуск бачок 3/6л. нижн.подвод сиденье твердое (укр.)",
      "product_mpn": "L89200000",
      "manufacturer_name": "KOLO Украина",
      "product_seria": "RUNA",
      "product_status": null,
      "exchangeRate_product_source_price": [],
      "exchangeRate_product_price_online": [],
      "product_price": "2913",
      "product_currency": "UAH",
      "product_price_online": "2825",
      "sourcePrice": "2184.75",
      "sourceCurrency": "UAH",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_028631_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_028631_1.jpg"
      ],
      "description": "Тип установки: напольный; слив: горизонтальный; комплектация: с бачком; подвод воды: нижний; материал сиденья: полипропилен; вес: 30 кг",
      parameters: [
        {
          "parameter_id": "28631_000000041",
          "product_sku": "28631",
          "parameter_name": "Длина",
          "parameter_value": "755"
        },
        {
          "parameter_id": "28631_000000042",
          "product_sku": "28631",
          "parameter_name": "Ширина",
          "parameter_value": "365"
        },
        {
          "parameter_id": "28631_000000043",
          "product_sku": "28631",
          "parameter_name": "Высота",
          "parameter_value": "635"
        },
        {
          "parameter_id": "28631_000000044",
          "product_sku": "28631",
          "parameter_name": "Монтаж",
          "parameter_value": "Напольный"
        },
        {
          "parameter_id": "28631_000000045",
          "product_sku": "28631",
          "parameter_name": "Подключение к канализации",
          "parameter_value": "Горизонтальное"
        },
        {
          "parameter_id": "28631_000000046",
          "product_sku": "28631",
          "parameter_name": "Безободковый",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "28631_000000047",
          "product_sku": "28631",
          "parameter_name": "Форма",
          "parameter_value": "Округлая"
        },
        {
          "parameter_id": "28631_000000048",
          "product_sku": "28631",
          "parameter_name": "Тип изделия",
          "parameter_value": "Унитаз-компакт"
        },
        {
          "parameter_id": "28631_000000049",
          "product_sku": "28631",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "28631_000000050",
          "product_sku": "28631",
          "parameter_name": "Комплектация",
          "parameter_value": "Бачок в комплекте"
        },
        {
          "parameter_id": "28631_000000051",
          "product_sku": "28631",
          "parameter_name": "Тип слива бачка",
          "parameter_value": "2 кнопки"
        },
        {
          "parameter_id": "28631_000000052",
          "product_sku": "28631",
          "parameter_name": "Подвод воды",
          "parameter_value": "Нижний"
        },
        {
          "parameter_id": "28631_000000053",
          "product_sku": "28631",
          "parameter_name": "Сиденье, крышка",
          "parameter_value": "Сиденье для унитаза"
        },
        {
          "parameter_id": "28631_000000054",
          "product_sku": "28631",
          "parameter_name": "Материал сиденья",
          "parameter_value": "Дюропласт"
        },
        {
          "parameter_id": "28631_000000055",
          "product_sku": "28631",
          "parameter_name": "Унитаз с функцией биде",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "28631_Brand",
          "product_sku": "28631",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Украина"
        },
        {
          "parameter_id": "28631_Series",
          "product_sku": "28631",
          "parameter_name": "Серия",
          "parameter_value": "RUNA"
        }
      ]
    },
    {
      "product_sku": "028632",
      "product_categoryId": "180001",
      "product_name": "RUNA компакт напольный кос.выпуск бачок 3/6л. нижн.подвод сиденье твердое (укр.)",
      "product_mpn": "L89201000",
      "manufacturer_name": "KOLO Украина",
      "product_seria": "RUNA",
      "product_status": null,
      "exchangeRate_product_source_price": [],
      "exchangeRate_product_price_online": [],
      "product_price": "2913",
      "product_currency": "UAH",
      "product_price_online": "2825",
      "sourcePrice": "2184.75",
      "sourceCurrency": "UAH",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_028632_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_028632_1.jpg"
      ],
      "description": "Тип установки: напольный, слив: косой, комплектация: с бачком, объем бачка 3/6 л, подвод воды: нижний, вес 30 кг",
      parameters: [
        {
          "parameter_id": "28632_000000041",
          "product_sku": "28632",
          "parameter_name": "Длина",
          "parameter_value": "755"
        },
        {
          "parameter_id": "28632_000000042",
          "product_sku": "28632",
          "parameter_name": "Ширина",
          "parameter_value": "365"
        },
        {
          "parameter_id": "28632_000000043",
          "product_sku": "28632",
          "parameter_name": "Высота",
          "parameter_value": "635"
        },
        {
          "parameter_id": "28632_000000044",
          "product_sku": "28632",
          "parameter_name": "Монтаж",
          "parameter_value": "Напольный"
        },
        {
          "parameter_id": "28632_000000045",
          "product_sku": "28632",
          "parameter_name": "Подключение к канализации",
          "parameter_value": "Косое"
        },
        {
          "parameter_id": "28632_000000046",
          "product_sku": "28632",
          "parameter_name": "Безободковый",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "28632_000000047",
          "product_sku": "28632",
          "parameter_name": "Форма",
          "parameter_value": "Округлая"
        },
        {
          "parameter_id": "28632_000000048",
          "product_sku": "28632",
          "parameter_name": "Тип изделия",
          "parameter_value": "Унитаз-компакт"
        },
        {
          "parameter_id": "28632_000000049",
          "product_sku": "28632",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "28632_000000050",
          "product_sku": "28632",
          "parameter_name": "Комплектация",
          "parameter_value": "Бачок в комплекте"
        },
        {
          "parameter_id": "28632_000000051",
          "product_sku": "28632",
          "parameter_name": "Тип слива бачка",
          "parameter_value": "2 кнопки"
        },
        {
          "parameter_id": "28632_000000052",
          "product_sku": "28632",
          "parameter_name": "Подвод воды",
          "parameter_value": "Нижний"
        },
        {
          "parameter_id": "28632_000000053",
          "product_sku": "28632",
          "parameter_name": "Сиденье, крышка",
          "parameter_value": "Сиденье для унитаза"
        },
        {
          "parameter_id": "28632_000000054",
          "product_sku": "28632",
          "parameter_name": "Материал сиденья",
          "parameter_value": "Дюропласт"
        },
        {
          "parameter_id": "28632_000000055",
          "product_sku": "28632",
          "parameter_name": "Унитаз с функцией биде",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "28632_Brand",
          "product_sku": "28632",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Украина"
        },
        {
          "parameter_id": "28632_Series",
          "product_sku": "28632",
          "parameter_name": "Серия",
          "parameter_value": "RUNA"
        }
      ]
    },
    {
      "product_sku": "028634",
      "product_categoryId": "1800054",
      "product_name": "RUNA биде напольное (укр.)",
      "product_mpn": "L85000000",
      "manufacturer_name": "KOLO Украина",
      "product_seria": "RUNA",
      "product_status": null,
      "exchangeRate_product_source_price": [],
      "exchangeRate_product_price_online": [],
      "product_price": "1191",
      "product_currency": "UAH",
      "product_price_online": "1155",
      "sourcePrice": "893.25",
      "sourceCurrency": "UAH",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_028634_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_028634_1.jpg"
      ],
      "description": "Напольное, с полкой под смеситель на 1 отверстие, в комплекте крепления для монтажа",
      parameters: [
        {
          "parameter_id": "28634_000000013",
          "product_sku": "28634",
          "parameter_name": "Материал",
          "parameter_value": "Санфаянс"
        },
        {
          "parameter_id": "28634_000000014",
          "product_sku": "28634",
          "parameter_name": "Глубина",
          "parameter_value": "530"
        },
        {
          "parameter_id": "28634_000000016",
          "product_sku": "28634",
          "parameter_name": "Монтаж",
          "parameter_value": "Отдельностоящий/напольный"
        },
        {
          "parameter_id": "28634_000000018",
          "product_sku": "28634",
          "parameter_name": "Форма",
          "parameter_value": "Округлая"
        },
        {
          "parameter_id": "28634_000000023",
          "product_sku": "28634",
          "parameter_name": "Тип установки смесителя",
          "parameter_value": "1 отверстие"
        },
        {
          "parameter_id": "28634_000000026",
          "product_sku": "28634",
          "parameter_name": "Страна производитель",
          "parameter_value": "Польша"
        },
        {
          "parameter_id": "28634_000000029",
          "product_sku": "28634",
          "parameter_name": "Перелив",
          "parameter_value": "С переливом"
        },
        {
          "parameter_id": "28634_Brand",
          "product_sku": "28634",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Украина"
        },
        {
          "parameter_id": "28634_Series",
          "product_sku": "28634",
          "parameter_name": "Серия",
          "parameter_value": "RUNA"
        }
      ]
    },
    {
      "product_sku": "028636",
      "product_categoryId": "180004",
      "product_name": "RUNA умывальник с отверстием, с переливом 55*45 см (укр.)",
      "product_mpn": "L81155000",
      "manufacturer_name": "KOLO Украина",
      "product_seria": "RUNA",
      "product_status": null,
      "exchangeRate_product_source_price": [],
      "exchangeRate_product_price_online": [],
      "product_price": "696",
      "product_currency": "UAH",
      "product_price_online": "674",
      "sourcePrice": "522",
      "sourceCurrency": "UAH",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_028636_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_028636_1.jpg"
      ],
      "description": "Универсальная установка, округлая форма, 1 отверстие под смеситель в центре",
      parameters: [
        {
          "parameter_id": "28636_000000058",
          "product_sku": "28636",
          "parameter_name": "Ширина",
          "parameter_value": "550"
        },
        {
          "parameter_id": "28636_000000059",
          "product_sku": "28636",
          "parameter_name": "Глубина",
          "parameter_value": "450"
        },
        {
          "parameter_id": "28636_000000060",
          "product_sku": "28636",
          "parameter_name": "Высота",
          "parameter_value": "185"
        },
        {
          "parameter_id": "28636_000000061",
          "product_sku": "28636",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "28636_000000062",
          "product_sku": "28636",
          "parameter_name": "Форма",
          "parameter_value": "Полукруглая"
        },
        {
          "parameter_id": "28636_000000063",
          "product_sku": "28636",
          "parameter_name": "Особенности формы",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "28636_000000064",
          "product_sku": "28636",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "28636_000000065",
          "product_sku": "28636",
          "parameter_name": "Комплектация",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "28636_000000066",
          "product_sku": "28636",
          "parameter_name": "Материал",
          "parameter_value": "Керамика"
        },
        {
          "parameter_id": "28636_000000067",
          "product_sku": "28636",
          "parameter_name": "Перелив",
          "parameter_value": "С переливом"
        },
        {
          "parameter_id": "28636_000000068",
          "product_sku": "28636",
          "parameter_name": "Отверстия под смеситель",
          "parameter_value": "1"
        },
        {
          "parameter_id": "28636_000000069",
          "product_sku": "28636",
          "parameter_name": "Кол-во смесителей",
          "parameter_value": "1"
        },
        {
          "parameter_id": "28636_000000070",
          "product_sku": "28636",
          "parameter_name": "Особенности",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "28636_Brand",
          "product_sku": "28636",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Украина"
        },
        {
          "parameter_id": "28636_Series",
          "product_sku": "28636",
          "parameter_name": "Серия",
          "parameter_value": "RUNA"
        }
      ]
    },
    {
      "product_sku": "028637",
      "product_categoryId": "180004",
      "product_name": "RUNA умывальник с отверстием, с переливом 60*48 см (укр.)",
      "product_mpn": "L81160000",
      "manufacturer_name": "KOLO Украина",
      "product_seria": "RUNA",
      "product_status": null,
      "exchangeRate_product_source_price": [],
      "exchangeRate_product_price_online": [],
      "product_price": "753",
      "product_currency": "UAH",
      "product_price_online": "729",
      "sourcePrice": "564.75",
      "sourceCurrency": "UAH",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_028637_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_028637_1.jpg"
      ],
      "description": "1 отверстие под смеситель в центре, крепится с помощью винтов",
      parameters: [
        {
          "parameter_id": "28637_000000058",
          "product_sku": "28637",
          "parameter_name": "Ширина",
          "parameter_value": "600"
        },
        {
          "parameter_id": "28637_000000059",
          "product_sku": "28637",
          "parameter_name": "Глубина",
          "parameter_value": "480"
        },
        {
          "parameter_id": "28637_000000060",
          "product_sku": "28637",
          "parameter_name": "Высота",
          "parameter_value": "185"
        },
        {
          "parameter_id": "28637_000000061",
          "product_sku": "28637",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "28637_000000062",
          "product_sku": "28637",
          "parameter_name": "Форма",
          "parameter_value": "Полукруглая"
        },
        {
          "parameter_id": "28637_000000063",
          "product_sku": "28637",
          "parameter_name": "Особенности формы",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "28637_000000064",
          "product_sku": "28637",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "28637_000000065",
          "product_sku": "28637",
          "parameter_name": "Комплектация",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "28637_000000066",
          "product_sku": "28637",
          "parameter_name": "Материал",
          "parameter_value": "Керамика"
        },
        {
          "parameter_id": "28637_000000067",
          "product_sku": "28637",
          "parameter_name": "Перелив",
          "parameter_value": "С переливом"
        },
        {
          "parameter_id": "28637_000000068",
          "product_sku": "28637",
          "parameter_name": "Отверстия под смеситель",
          "parameter_value": "1"
        },
        {
          "parameter_id": "28637_000000069",
          "product_sku": "28637",
          "parameter_name": "Кол-во смесителей",
          "parameter_value": "1"
        },
        {
          "parameter_id": "28637_000000070",
          "product_sku": "28637",
          "parameter_name": "Особенности",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "28637_Brand",
          "product_sku": "28637",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Украина"
        },
        {
          "parameter_id": "28637_Series",
          "product_sku": "28637",
          "parameter_name": "Серия",
          "parameter_value": "RUNA"
        }
      ]
    },
    {
      "product_sku": "028640",
      "product_categoryId": "180001",
      "product_name": "FREJA компакт напольный гор.выпуск бачок 3/6л. нижн.подвод, сиденье дюропласт (укр.)",
      "product_mpn": "L79200000",
      "manufacturer_name": "KOLO Украина",
      "product_seria": "FREJA",
      "product_status": null,
      "exchangeRate_product_source_price": [],
      "exchangeRate_product_price_online": [],
      "product_price": "2736",
      "product_currency": "UAH",
      "product_price_online": "2653",
      "sourcePrice": "2052",
      "sourceCurrency": "UAH",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_028640_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_028640_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_028640_2.jpg"
      ],
      "description": "Монтаж напольный, выпуск горизонтальный, объем бачка 6 л, подвод воды нижний, вес 28 кг",
      parameters: [
        {
          "parameter_id": "28640_000000041",
          "product_sku": "28640",
          "parameter_name": "Длина",
          "parameter_value": "640"
        },
        {
          "parameter_id": "28640_000000042",
          "product_sku": "28640",
          "parameter_name": "Ширина",
          "parameter_value": "354"
        },
        {
          "parameter_id": "28640_000000043",
          "product_sku": "28640",
          "parameter_name": "Высота",
          "parameter_value": "780"
        },
        {
          "parameter_id": "28640_000000044",
          "product_sku": "28640",
          "parameter_name": "Монтаж",
          "parameter_value": "Напольный"
        },
        {
          "parameter_id": "28640_000000045",
          "product_sku": "28640",
          "parameter_name": "Подключение к канализации",
          "parameter_value": "Горизонтальное"
        },
        {
          "parameter_id": "28640_000000046",
          "product_sku": "28640",
          "parameter_name": "Безободковый",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "28640_000000047",
          "product_sku": "28640",
          "parameter_name": "Форма",
          "parameter_value": "Округлая"
        },
        {
          "parameter_id": "28640_000000048",
          "product_sku": "28640",
          "parameter_name": "Тип изделия",
          "parameter_value": "Унитаз-компакт"
        },
        {
          "parameter_id": "28640_000000049",
          "product_sku": "28640",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "28640_000000050",
          "product_sku": "28640",
          "parameter_name": "Комплектация",
          "parameter_value": "Бачок в комплекте"
        },
        {
          "parameter_id": "28640_000000051",
          "product_sku": "28640",
          "parameter_name": "Тип слива бачка",
          "parameter_value": "2 кнопки"
        },
        {
          "parameter_id": "28640_000000052",
          "product_sku": "28640",
          "parameter_name": "Подвод воды",
          "parameter_value": "Нижний"
        },
        {
          "parameter_id": "28640_000000053",
          "product_sku": "28640",
          "parameter_name": "Сиденье, крышка",
          "parameter_value": "Сиденье для унитаза"
        },
        {
          "parameter_id": "28640_000000054",
          "product_sku": "28640",
          "parameter_name": "Материал сиденья",
          "parameter_value": "Дюропласт"
        },
        {
          "parameter_id": "28640_000000055",
          "product_sku": "28640",
          "parameter_name": "Унитаз с функцией биде",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "28640_Brand",
          "product_sku": "28640",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Украина"
        },
        {
          "parameter_id": "28640_Series",
          "product_sku": "28640",
          "parameter_name": "Серия",
          "parameter_value": "FREJA"
        }
      ]
    },
    {
      "product_sku": "028641",
      "product_categoryId": "180001",
      "product_name": "FREJA компакт напольный кос.выпуск бачок 6 л нижн.подвод сиденье (укр.)",
      "product_mpn": "L79201000",
      "manufacturer_name": "KOLO Украина",
      "product_seria": "FREJA",
      "product_status": null,
      "exchangeRate_product_source_price": [],
      "exchangeRate_product_price_online": [],
      "product_price": "2313",
      "product_currency": "UAH",
      "product_price_online": "2243",
      "sourcePrice": "1734.75",
      "sourceCurrency": "UAH",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_028641_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_028641_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_028641_2.jpg"
      ],
      "description": "Тип установки: напольный; слив: косой; комплектация: с бачком; подвод воды: нижний; объем бачка 3/6 л, вес 24,5 кгПодробнее:http://bt.rozetka.com.ua/kolo-freja-l79201/p242566/",
      parameters: [
        {
          "parameter_id": "28641_000000041",
          "product_sku": "28641",
          "parameter_name": "Длина",
          "parameter_value": "640"
        },
        {
          "parameter_id": "28641_000000042",
          "product_sku": "28641",
          "parameter_name": "Ширина",
          "parameter_value": "354"
        },
        {
          "parameter_id": "28641_000000043",
          "product_sku": "28641",
          "parameter_name": "Высота",
          "parameter_value": "780"
        },
        {
          "parameter_id": "28641_000000044",
          "product_sku": "28641",
          "parameter_name": "Монтаж",
          "parameter_value": "Напольный"
        },
        {
          "parameter_id": "28641_000000045",
          "product_sku": "28641",
          "parameter_name": "Подключение к канализации",
          "parameter_value": "Косое"
        },
        {
          "parameter_id": "28641_000000046",
          "product_sku": "28641",
          "parameter_name": "Безободковый",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "28641_000000047",
          "product_sku": "28641",
          "parameter_name": "Форма",
          "parameter_value": "Округлая"
        },
        {
          "parameter_id": "28641_000000048",
          "product_sku": "28641",
          "parameter_name": "Тип изделия",
          "parameter_value": "Унитаз-компакт"
        },
        {
          "parameter_id": "28641_000000049",
          "product_sku": "28641",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "28641_000000050",
          "product_sku": "28641",
          "parameter_name": "Комплектация",
          "parameter_value": "Бачок в комплекте"
        },
        {
          "parameter_id": "28641_000000051",
          "product_sku": "28641",
          "parameter_name": "Тип слива бачка",
          "parameter_value": "1 кнопка"
        },
        {
          "parameter_id": "28641_000000052",
          "product_sku": "28641",
          "parameter_name": "Подвод воды",
          "parameter_value": "Нижний"
        },
        {
          "parameter_id": "28641_000000053",
          "product_sku": "28641",
          "parameter_name": "Сиденье, крышка",
          "parameter_value": "Сиденье для унитаза"
        },
        {
          "parameter_id": "28641_000000054",
          "product_sku": "28641",
          "parameter_name": "Материал сиденья",
          "parameter_value": "Полипропилен"
        },
        {
          "parameter_id": "28641_000000055",
          "product_sku": "28641",
          "parameter_name": "Унитаз с функцией биде",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "28641_Brand",
          "product_sku": "28641",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Украина"
        },
        {
          "parameter_id": "28641_Series",
          "product_sku": "28641",
          "parameter_name": "Серия",
          "parameter_value": "FREJA"
        }
      ]
    },
    {
      "product_sku": "028642",
      "product_categoryId": "1800054",
      "product_name": "FREJA биде напольное (укр.)",
      "product_mpn": "L75000000",
      "manufacturer_name": "KOLO Украина",
      "product_seria": "FREJA",
      "product_status": null,
      "exchangeRate_product_source_price": [],
      "exchangeRate_product_price_online": [],
      "product_price": "1065",
      "product_currency": "UAH",
      "product_price_online": "1032",
      "sourcePrice": "798.75",
      "sourceCurrency": "UAH",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_028642_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_028642_1.jpg"
      ],
      "description": "Монтаж: напольный, 1 отверстие под смеситель, с переливом",
      parameters: [
        {
          "parameter_id": "28642_000000013",
          "product_sku": "28642",
          "parameter_name": "Материал",
          "parameter_value": "Санфаянс"
        },
        {
          "parameter_id": "28642_000000014",
          "product_sku": "28642",
          "parameter_name": "Глубина",
          "parameter_value": "530"
        },
        {
          "parameter_id": "28642_000000016",
          "product_sku": "28642",
          "parameter_name": "Монтаж",
          "parameter_value": "Отдельностоящий/напольный"
        },
        {
          "parameter_id": "28642_000000018",
          "product_sku": "28642",
          "parameter_name": "Форма",
          "parameter_value": "Округлая"
        },
        {
          "parameter_id": "28642_000000023",
          "product_sku": "28642",
          "parameter_name": "Тип установки смесителя",
          "parameter_value": "1 отверстие"
        },
        {
          "parameter_id": "28642_000000026",
          "product_sku": "28642",
          "parameter_name": "Страна производитель",
          "parameter_value": "Польша"
        },
        {
          "parameter_id": "28642_000000029",
          "product_sku": "28642",
          "parameter_name": "Перелив",
          "parameter_value": "С переливом"
        },
        {
          "parameter_id": "28642_Brand",
          "product_sku": "28642",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Украина"
        },
        {
          "parameter_id": "28642_Series",
          "product_sku": "28642",
          "parameter_name": "Серия",
          "parameter_value": "FREJA"
        }
      ]
    },
    {
      "product_sku": "028645",
      "product_categoryId": "180004",
      "product_name": "FREJA умывальник с отверстием, с переливом 60*47 см (укр.)",
      "product_mpn": "L71160000",
      "manufacturer_name": "KOLO Украина",
      "product_seria": "FREJA",
      "product_status": null,
      "exchangeRate_product_source_price": [],
      "exchangeRate_product_price_online": [],
      "product_price": "699",
      "product_currency": "UAH",
      "product_price_online": "677",
      "sourcePrice": "524.25",
      "sourceCurrency": "UAH",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_028645_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_028645_1.jpg"
      ],
      "description": "1 отверстие под смеситель, с переливом",
      parameters: [
        {
          "parameter_id": "28645_000000058",
          "product_sku": "28645",
          "parameter_name": "Ширина",
          "parameter_value": "600"
        },
        {
          "parameter_id": "28645_000000059",
          "product_sku": "28645",
          "parameter_name": "Глубина",
          "parameter_value": "470"
        },
        {
          "parameter_id": "28645_000000060",
          "product_sku": "28645",
          "parameter_name": "Высота",
          "parameter_value": "160"
        },
        {
          "parameter_id": "28645_000000061",
          "product_sku": "28645",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "28645_000000062",
          "product_sku": "28645",
          "parameter_name": "Форма",
          "parameter_value": "Полукруглая"
        },
        {
          "parameter_id": "28645_000000063",
          "product_sku": "28645",
          "parameter_name": "Особенности формы",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "28645_000000064",
          "product_sku": "28645",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "28645_000000065",
          "product_sku": "28645",
          "parameter_name": "Комплектация",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "28645_000000066",
          "product_sku": "28645",
          "parameter_name": "Материал",
          "parameter_value": "Керамика"
        },
        {
          "parameter_id": "28645_000000067",
          "product_sku": "28645",
          "parameter_name": "Перелив",
          "parameter_value": "С переливом"
        },
        {
          "parameter_id": "28645_000000068",
          "product_sku": "28645",
          "parameter_name": "Отверстия под смеситель",
          "parameter_value": "1"
        },
        {
          "parameter_id": "28645_000000069",
          "product_sku": "28645",
          "parameter_name": "Кол-во смесителей",
          "parameter_value": "1"
        },
        {
          "parameter_id": "28645_000000070",
          "product_sku": "28645",
          "parameter_name": "Особенности",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "28645_Brand",
          "product_sku": "28645",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Украина"
        },
        {
          "parameter_id": "28645_Series",
          "product_sku": "28645",
          "parameter_name": "Серия",
          "parameter_value": "FREJA"
        }
      ]
    },
    {
      "product_sku": "029132",
      "product_categoryId": "200031",
      "product_name": "Rapid SL комплект углового монтажа",
      "product_mpn": "38562001",
      "manufacturer_name": "GROHE",
      "product_seria": "RAPID SL",
      "product_status": "Акция",
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_029132_0.jpg"
      ],
      "description": "Комплект углового монтажа для унитаза, биде, раковины и писсуара, одиночный или рядный монтаж на рельсе, расстояние между углами макс. 625 мм, крепежный материал для углового монтажа, 2 настенных угла 1,13 м",
      parameters: [
        {
          "parameter_id": "29132_000000026",
          "product_sku": "29132",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "29132_Brand",
          "product_sku": "29132",
          "parameter_name": "Бренд",
          "parameter_value": "GROHE"
        },
        {
          "parameter_id": "29132_Series",
          "product_sku": "29132",
          "parameter_name": "Серия",
          "parameter_value": "RAPID SL"
        }
      ]
    },
    {
      "product_sku": "029146",
      "product_categoryId": "1800056",
      "product_name": "LA BELLE умывальник для тумбы 85*44см",
      "product_mpn": "613785R1",
      "manufacturer_name": "VILLEROY & BOCH",
      "product_seria": "LA BELLE",
      "product_status": "Распродажа",
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_029146_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_029146_1.jpg"
      ],
      "description": "Умывальник без наличия отверстий под смеситель, без перелива, включает незапираемый сливной клапан с керамической крышкой, включает вырезной шаблон",
      parameters: [
        {
          "parameter_id": "29146_000000001",
          "product_sku": "29146",
          "parameter_name": "Ширина",
          "parameter_value": "850"
        },
        {
          "parameter_id": "29146_000000013",
          "product_sku": "29146",
          "parameter_name": "Материал",
          "parameter_value": "Санфаянс"
        },
        {
          "parameter_id": "29146_000000014",
          "product_sku": "29146",
          "parameter_name": "Глубина",
          "parameter_value": "440"
        },
        {
          "parameter_id": "29146_000000016",
          "product_sku": "29146",
          "parameter_name": "Монтаж",
          "parameter_value": "Накладной"
        },
        {
          "parameter_id": "29146_000000018",
          "product_sku": "29146",
          "parameter_name": "Форма",
          "parameter_value": "Округлая"
        },
        {
          "parameter_id": "29146_000000023",
          "product_sku": "29146",
          "parameter_name": "Тип установки смесителя",
          "parameter_value": "Без отверстия"
        },
        {
          "parameter_id": "29146_000000025",
          "product_sku": "29146",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Улучшенное покрытие"
        },
        {
          "parameter_id": "29146_000000026",
          "product_sku": "29146",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "29146_000000029",
          "product_sku": "29146",
          "parameter_name": "Перелив",
          "parameter_value": "Без перелива"
        },
        {
          "parameter_id": "29146_Brand",
          "product_sku": "29146",
          "parameter_name": "Бренд",
          "parameter_value": "VILLEROY & BOCH"
        },
        {
          "parameter_id": "29146_Series",
          "product_sku": "29146",
          "parameter_name": "Серия",
          "parameter_value": "LA BELLE"
        }
      ]
    },
    {
      "product_sku": "033909",
      "product_categoryId": "1800081",
      "product_name": "KOLO блок питания, для 5 писсуаров (пол.)",
      "product_mpn": "96019000",
      "manufacturer_name": "KOLO Польша",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": [],
      "exchangeRate_product_price_online": [],
      "product_price": "3582",
      "product_currency": "UAH",
      "product_price_online": "3582",
      "sourcePrice": "2614.86",
      "sourceCurrency": "UAH",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_033909_0.jpg"
      ],
      "description": "Блок питания (для 5 писсуаров) Kolo, 230 V. Материал - металл.",
      parameters: [
        {
          "parameter_id": "33909_000000026",
          "product_sku": "33909",
          "parameter_name": "Страна производитель",
          "parameter_value": "Польша"
        },
        {
          "parameter_id": "33909_Brand",
          "product_sku": "33909",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Польша"
        },
        {
          "parameter_id": "33909_Series",
          "product_sku": "33909",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "034500",
      "product_categoryId": "1800074",
      "product_name": "SUBWAY 2.0. унитаз подвесной 37,5*56,5см",
      "product_mpn": "56001001",
      "manufacturer_name": "VILLEROY & BOCH",
      "product_seria": "SUBWAY 2.0",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29
      },
      "exchangeRate_product_price_online": {
        "EUR": 29
      },
      "product_price": "415",
      "product_currency": "EUR",
      "product_price_online": "12035",
      "sourcePrice": "257.30",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_034500_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_034500_1.jpg"
      ],
      "description": "Унитаз с вертикальным смывом, крепежный комплект &amp;amp;quot;SupraFix 2.0&amp;amp;quot; входит в комплект поставки, с системой экономии воды AQUAREDUCT : объем воды для смыва 3 / 4,5 литра",
      parameters: [
        {
          "parameter_id": "34500_Brand",
          "product_sku": "34500",
          "parameter_name": "Бренд",
          "parameter_value": "VILLEROY & BOCH"
        },
        {
          "parameter_id": "34500_Series",
          "product_sku": "34500",
          "parameter_name": "Серия",
          "parameter_value": "SUBWAY 2.0"
        }
      ]
    },
    {
      "product_sku": "034923",
      "product_categoryId": "600066",
      "product_name": "FIRST поддон 90*90см, полукруглый, с интегрированной панелью и ножками",
      "product_mpn": "XBN1690000",
      "manufacturer_name": "KOLO Польша",
      "product_seria": "FIRST",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_034923_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_034923_1.jpg"
      ],
      "description": "Душевой поддон с интегрированной панелью, угловой, акриловый, размеры: 90*90 см, выпуск 90 мм",
      parameters: [
        {
          "parameter_id": "34923_000000001",
          "product_sku": "34923",
          "parameter_name": "Ширина",
          "parameter_value": "900"
        },
        {
          "parameter_id": "34923_000000011",
          "product_sku": "34923",
          "parameter_name": "Тип поддона",
          "parameter_value": "Мелкий"
        },
        {
          "parameter_id": "34923_000000013",
          "product_sku": "34923",
          "parameter_name": "Материал",
          "parameter_value": "Акрил"
        },
        {
          "parameter_id": "34923_000000014",
          "product_sku": "34923",
          "parameter_name": "Глубина",
          "parameter_value": "40"
        },
        {
          "parameter_id": "34923_000000015",
          "product_sku": "34923",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "900"
        },
        {
          "parameter_id": "34923_000000018",
          "product_sku": "34923",
          "parameter_name": "Форма",
          "parameter_value": "Угловая"
        },
        {
          "parameter_id": "34923_000000026",
          "product_sku": "34923",
          "parameter_name": "Страна производитель",
          "parameter_value": "Польша"
        },
        {
          "parameter_id": "34923_Brand",
          "product_sku": "34923",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Польша"
        },
        {
          "parameter_id": "34923_Series",
          "product_sku": "34923",
          "parameter_name": "Серия",
          "parameter_value": "FIRST"
        }
      ]
    },
    {
      "product_sku": "034949",
      "product_categoryId": "90007",
      "product_name": "Axor Carlton Мыльница",
      "product_mpn": "41433000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "AXOR CARLTON",
      "product_status": "Распродажа",
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_034949_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_034949_1.jpg"
      ],
      "description": "Мыльница с металлическим держателем, настенный монтаж",
      parameters: [
        {
          "parameter_id": "34949_000000013",
          "product_sku": "34949",
          "parameter_name": "Материал",
          "parameter_value": "Стекло"
        },
        {
          "parameter_id": "34949_000000016",
          "product_sku": "34949",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "34949_000000025",
          "product_sku": "34949",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Матовый"
        },
        {
          "parameter_id": "34949_000000026",
          "product_sku": "34949",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "34949_Brand",
          "product_sku": "34949",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "34949_Series",
          "product_sku": "34949",
          "parameter_name": "Серия",
          "parameter_value": "AXOR CARLTON"
        }
      ]
    },
    {
      "product_sku": "034993",
      "product_categoryId": "400045",
      "product_name": "HORAK набор (05170 + 10170 + R670SD + 1115 + W100SL1 C + 21*27*80)",
      "product_mpn": "0510170670",
      "manufacturer_name": "IMPRESE",
      "product_seria": "HORAK",
      "product_status": "Акция",
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_034993_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_034993_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_034993_2.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_034993_3.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_034993_4.jpg"
      ],
      "description": "HORAK набор (05170 + 10170 + R670SD + 1115 + W100SL1 C + 21*27*80)\nКомплект для ванной комнаты: смеситель для раковины + смеситель для ванны + душевая штанга\nматериал штанги: нержавеющая сталь",
      parameters: [
        {
          "parameter_id": "34993_000000026",
          "product_sku": "34993",
          "parameter_name": "Страна производитель",
          "parameter_value": "Чехия"
        },
        {
          "parameter_id": "34993_Brand",
          "product_sku": "34993",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "34993_Series",
          "product_sku": "34993",
          "parameter_name": "Серия",
          "parameter_value": "HORAK"
        }
      ]
    },
    {
      "product_sku": "035118",
      "product_categoryId": "180001",
      "product_name": "FREJA компакт напольный гор.выпуск бачок 3/6л. нижн.подвод сиденье твердое Soft-close (укр.)",
      "product_mpn": "L79211000",
      "manufacturer_name": "KOLO Украина",
      "product_seria": "FREJA",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_035118_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_035118_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_035118_2.jpg"
      ],
      "description": "Напольный, подвод воды: нижний, выпуск: горизонтальный, объем бачка 3/6 л, вес 28 кг",
      parameters: [
        {
          "parameter_id": "35118_000000041",
          "product_sku": "35118",
          "parameter_name": "Длина",
          "parameter_value": "640"
        },
        {
          "parameter_id": "35118_000000042",
          "product_sku": "35118",
          "parameter_name": "Ширина",
          "parameter_value": "354"
        },
        {
          "parameter_id": "35118_000000043",
          "product_sku": "35118",
          "parameter_name": "Высота",
          "parameter_value": "780"
        },
        {
          "parameter_id": "35118_000000044",
          "product_sku": "35118",
          "parameter_name": "Монтаж",
          "parameter_value": "Напольный"
        },
        {
          "parameter_id": "35118_000000045",
          "product_sku": "35118",
          "parameter_name": "Подключение к канализации",
          "parameter_value": "Горизонтальное"
        },
        {
          "parameter_id": "35118_000000046",
          "product_sku": "35118",
          "parameter_name": "Безободковый",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "35118_000000047",
          "product_sku": "35118",
          "parameter_name": "Форма",
          "parameter_value": "Округлая"
        },
        {
          "parameter_id": "35118_000000048",
          "product_sku": "35118",
          "parameter_name": "Тип изделия",
          "parameter_value": "Унитаз-компакт"
        },
        {
          "parameter_id": "35118_000000049",
          "product_sku": "35118",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "35118_000000050",
          "product_sku": "35118",
          "parameter_name": "Комплектация",
          "parameter_value": "Бачок в комплекте"
        },
        {
          "parameter_id": "35118_000000051",
          "product_sku": "35118",
          "parameter_name": "Тип слива бачка",
          "parameter_value": "2 кнопки"
        },
        {
          "parameter_id": "35118_000000052",
          "product_sku": "35118",
          "parameter_name": "Подвод воды",
          "parameter_value": "Нижний"
        },
        {
          "parameter_id": "35118_000000053",
          "product_sku": "35118",
          "parameter_name": "Сиденье, крышка",
          "parameter_value": "Сиденье для унитаза Soft-close"
        },
        {
          "parameter_id": "35118_000000054",
          "product_sku": "35118",
          "parameter_name": "Материал сиденья",
          "parameter_value": "Дюропласт"
        },
        {
          "parameter_id": "35118_000000055",
          "product_sku": "35118",
          "parameter_name": "Унитаз с функцией биде",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "35118_Brand",
          "product_sku": "35118",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Украина"
        },
        {
          "parameter_id": "35118_Series",
          "product_sku": "35118",
          "parameter_name": "Серия",
          "parameter_value": "FREJA"
        }
      ]
    },
    {
      "product_sku": "035734",
      "product_categoryId": "400023",
      "product_name": "Axor Bouroullec Подключение для душевого Шланга",
      "product_mpn": "19622000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "AXOR BOUROULLEC",
      "product_status": "Распродажа",
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_035734_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_035734_1.jpg"
      ],
      "description": "Axor Bouroullec Подключение для душевого Шланга",
      parameters: [
        {
          "parameter_id": "35734_000000016",
          "product_sku": "35734",
          "parameter_name": "Монтаж",
          "parameter_value": "Встраиваемый в стену"
        },
        {
          "parameter_id": "35734_000000025",
          "product_sku": "35734",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "35734_000000026",
          "product_sku": "35734",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "35734_Brand",
          "product_sku": "35734",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "35734_Series",
          "product_sku": "35734",
          "parameter_name": "Серия",
          "parameter_value": "AXOR BOUROULLEC"
        }
      ]
    },
    {
      "product_sku": "035820",
      "product_categoryId": "200031",
      "product_name": "Geberit Пара коротких стоек для крепежа в пол",
      "product_mpn": "457.888.26.1",
      "manufacturer_name": "GEBERIT",
      "product_seria": "KOMBIFIX",
      "product_status": "Распродажа",
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_035820_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_035820_1.jpg"
      ],
      "description": "Geberit Пара коротких стоек для крепежа в пол.",
      parameters: [
        {
          "parameter_id": "35820_000000026",
          "product_sku": "35820",
          "parameter_name": "Страна производитель",
          "parameter_value": "Швейцария"
        },
        {
          "parameter_id": "35820_Brand",
          "product_sku": "35820",
          "parameter_name": "Бренд",
          "parameter_value": "GEBERIT"
        },
        {
          "parameter_id": "35820_Series",
          "product_sku": "35820",
          "parameter_name": "Серия",
          "parameter_value": "KOMBIFIX"
        }
      ]
    },
    {
      "product_sku": "036035",
      "product_categoryId": "180001",
      "product_name": "GAP компакт в комплекте: унитаз, бачок 3/4,5, сиденье с системой плавного опускания",
      "product_mpn": "A34947800W",
      "manufacturer_name": "ROCA",
      "product_seria": "GAP",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_036035_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_036035_1.jpg"
      ],
      "description": "GAP компакт в комплекте: унитаз, бачок 3/4,5, сиденье slow-closing (медленное закрывание)",
      parameters: [
        {
          "parameter_id": "36035_000000041",
          "product_sku": "36035",
          "parameter_name": "Длина",
          "parameter_value": "650"
        },
        {
          "parameter_id": "36035_000000042",
          "product_sku": "36035",
          "parameter_name": "Ширина",
          "parameter_value": "365"
        },
        {
          "parameter_id": "36035_000000043",
          "product_sku": "36035",
          "parameter_name": "Высота",
          "parameter_value": "790"
        },
        {
          "parameter_id": "36035_000000044",
          "product_sku": "36035",
          "parameter_name": "Монтаж",
          "parameter_value": "Напольный"
        },
        {
          "parameter_id": "36035_000000045",
          "product_sku": "36035",
          "parameter_name": "Подключение к канализации",
          "parameter_value": "Горизонтальное"
        },
        {
          "parameter_id": "36035_000000046",
          "product_sku": "36035",
          "parameter_name": "Безободковый",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "36035_000000047",
          "product_sku": "36035",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "36035_000000048",
          "product_sku": "36035",
          "parameter_name": "Тип изделия",
          "parameter_value": "Унитаз-компакт"
        },
        {
          "parameter_id": "36035_000000049",
          "product_sku": "36035",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "36035_000000050",
          "product_sku": "36035",
          "parameter_name": "Комплектация",
          "parameter_value": "Бачок в комплекте"
        },
        {
          "parameter_id": "36035_000000051",
          "product_sku": "36035",
          "parameter_name": "Тип слива бачка",
          "parameter_value": "2 кнопки"
        },
        {
          "parameter_id": "36035_000000052",
          "product_sku": "36035",
          "parameter_name": "Подвод воды",
          "parameter_value": "Нижний"
        },
        {
          "parameter_id": "36035_000000053",
          "product_sku": "36035",
          "parameter_name": "Сиденье, крышка",
          "parameter_value": "Сиденье для унитаза Soft-close"
        },
        {
          "parameter_id": "36035_000000054",
          "product_sku": "36035",
          "parameter_name": "Материал сиденья",
          "parameter_value": "Дюропласт"
        },
        {
          "parameter_id": "36035_000000055",
          "product_sku": "36035",
          "parameter_name": "Унитаз с функцией биде",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "36035_Brand",
          "product_sku": "36035",
          "parameter_name": "Бренд",
          "parameter_value": "ROCA"
        },
        {
          "parameter_id": "36035_Series",
          "product_sku": "36035",
          "parameter_name": "Серия",
          "parameter_value": "GAP"
        }
      ]
    },
    {
      "product_sku": "036085",
      "product_categoryId": "400073",
      "product_name": "Raindance Select E 120 Ручной душ, белый/хром",
      "product_mpn": "26520400",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "Raindance Select E",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_036085_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_036085_1.jpg"
      ],
      "description": "Raindance Select Ручной душ Размер душевого диска: 120 mm, тип струи: Rain, RainAir (дождевая струя с подмешиванием воздуха), массаж, расход воды: 16 л/мин, комфортное переключение типа струи кнопкой выбора, подходит для работы с проточным водонагревателем",
      parameters: [
        {
          "parameter_id": "36085_000000170",
          "product_sku": "36085",
          "parameter_name": "Диаметр/Диагональ, мм",
          "parameter_value": "120"
        },
        {
          "parameter_id": "36085_000000171",
          "product_sku": "36085",
          "parameter_name": "Форма лейки ручного душа",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "36085_000000172",
          "product_sku": "36085",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром/белый"
        },
        {
          "parameter_id": "36085_000000173",
          "product_sku": "36085",
          "parameter_name": "Кол-во режимов ручного душа",
          "parameter_value": "3"
        },
        {
          "parameter_id": "36085_000000174",
          "product_sku": "36085",
          "parameter_name": "Способ переключения режимов",
          "parameter_value": "Кнопка"
        },
        {
          "parameter_id": "36085_Brand",
          "product_sku": "36085",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "36085_Series",
          "product_sku": "36085",
          "parameter_name": "Серия",
          "parameter_value": "Raindance Select E"
        }
      ]
    },
    {
      "product_sku": "036086",
      "product_categoryId": "400071",
      "product_name": "Raindance Select 120 Unica Set Душевой набор, цвет хромбелый, 0,65 м",
      "product_mpn": "26620400",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "RAINDANCE SELECT",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_036086_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_036086_1.jpg"
      ],
      "description": "Raindance Select 130 Unica Set Душевой набор, 0,65 м Тип струи: Rain, RainAir, массаж, комфортное переключение типа струи кнопкой выбора, размер душевого диска: 120 mm, максимальный расход воды: 16 л/мин, пластина для виравнивания плитки (серая)",
      parameters: [
        {
          "parameter_id": "36086_000000150",
          "product_sku": "36086",
          "parameter_name": "Высота, мм",
          "parameter_value": "650"
        },
        {
          "parameter_id": "36086_000000151",
          "product_sku": "36086",
          "parameter_name": "Тип держателя",
          "parameter_value": "Штанга"
        },
        {
          "parameter_id": "36086_000000152",
          "product_sku": "36086",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "36086_000000153",
          "product_sku": "36086",
          "parameter_name": "Форма лейки ручного душа",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "36086_000000154",
          "product_sku": "36086",
          "parameter_name": "Мыльница",
          "parameter_value": "Да"
        },
        {
          "parameter_id": "36086_000000155",
          "product_sku": "36086",
          "parameter_name": "Кол-во режимов ручного душа",
          "parameter_value": "3"
        },
        {
          "parameter_id": "36086_000000175",
          "product_sku": "36086",
          "parameter_name": "Диаметр/Диагональ, мм",
          "parameter_value": "120"
        },
        {
          "parameter_id": "36086_000000176",
          "product_sku": "36086",
          "parameter_name": "Способ переключения режимов",
          "parameter_value": "Кнопка"
        },
        {
          "parameter_id": "36086_000000177",
          "product_sku": "36086",
          "parameter_name": "Цвет диска ручного душа",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "36086_Brand",
          "product_sku": "36086",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "36086_Series",
          "product_sku": "36086",
          "parameter_name": "Серия",
          "parameter_value": "RAINDANCE SELECT"
        }
      ]
    },
    {
      "product_sku": "036114",
      "product_categoryId": "1800074",
      "product_name": "IDOL унитаз подвесной сиденье мягкое (укр.)",
      "product_mpn": "M1310000U",
      "manufacturer_name": "KOLO Украина",
      "product_seria": "IDOL",
      "product_status": "Акция",
      "exchangeRate_product_source_price": [],
      "exchangeRate_product_price_online": [],
      "product_price": "1197",
      "product_currency": "UAH",
      "product_price_old": "1242.0000",
      "product_price_online": "1197",
      "sourcePrice": "931.50",
      "sourceCurrency": "UAH",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_036114_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_036114_1.jpg"
      ],
      "description": "Унитаз подвесной, мягкое сиденье. Материал - санфаянс, тип сидения - полипропилен, форма - округлая, горизонтальное подключение к канализации. Глубина - 510 мм.",
      parameters: [
        {
          "parameter_id": "36114_Brand",
          "product_sku": "36114",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Украина"
        },
        {
          "parameter_id": "36114_Series",
          "product_sku": "36114",
          "parameter_name": "Серия",
          "parameter_value": "IDOL"
        }
      ]
    },
    {
      "product_sku": "036126",
      "product_categoryId": "800047",
      "product_name": "HAPPY D 2 консоль 120см (цвет белый глянец)",
      "product_mpn": "025C-22",
      "manufacturer_name": "DURAVIT",
      "product_seria": "HAPPY D",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 28
      },
      "exchangeRate_product_price_online": {
        "EUR": 28
      },
      "product_price": "498",
      "product_currency": "EUR",
      "product_price_online": "12550",
      "sourcePrice": "298.80",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_036126_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_036126_1.jpg"
      ],
      "description": "0",
      parameters: [
        {
          "parameter_id": "36126_000000001",
          "product_sku": "36126",
          "parameter_name": "Ширина",
          "parameter_value": "1 200"
        },
        {
          "parameter_id": "36126_000000013",
          "product_sku": "36126",
          "parameter_name": "Материал",
          "parameter_value": "ДСП"
        },
        {
          "parameter_id": "36126_000000015",
          "product_sku": "36126",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "24"
        },
        {
          "parameter_id": "36126_000000016",
          "product_sku": "36126",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "36126_000000025",
          "product_sku": "36126",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Белый глянец"
        },
        {
          "parameter_id": "36126_000000026",
          "product_sku": "36126",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "36126_Brand",
          "product_sku": "36126",
          "parameter_name": "Бренд",
          "parameter_value": "DURAVIT"
        },
        {
          "parameter_id": "36126_Series",
          "product_sku": "36126",
          "parameter_name": "Серия",
          "parameter_value": "HAPPY D"
        }
      ]
    },
    {
      "product_sku": "036129",
      "product_categoryId": "18000102",
      "product_name": "DURASTYLE сидение для унитаза, с автоматическим закрыванием",
      "product_mpn": "0063790000",
      "manufacturer_name": "DURAVIT",
      "product_seria": "DURASTYLE",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 28
      },
      "exchangeRate_product_price_online": {
        "EUR": 28
      },
      "product_price": "122.40",
      "product_currency": "EUR",
      "product_price_old": "153.0000",
      "product_price_online": "3427",
      "sourcePrice": "91.80",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_036129_0.jpg"
      ],
      "description": "Сиденье для унитаза с автоматическим закрыванием, петли из нержавеющей стали, съёмное",
      parameters: [
        {
          "parameter_id": "36129_000000018",
          "product_sku": "36129",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "36129_000000026",
          "product_sku": "36129",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "36129_000000027",
          "product_sku": "36129",
          "parameter_name": "Тип сидения",
          "parameter_value": "Дюропласт"
        },
        {
          "parameter_id": "36129_Brand",
          "product_sku": "36129",
          "parameter_name": "Бренд",
          "parameter_value": "DURAVIT"
        },
        {
          "parameter_id": "36129_Series",
          "product_sku": "36129",
          "parameter_name": "Серия",
          "parameter_value": "DURASTYLE"
        }
      ]
    },
    {
      "product_sku": "036164",
      "product_categoryId": "500036",
      "product_name": "OBERON ванна 190*90см с ножками",
      "product_mpn": "UBQ199OBE2V-01",
      "manufacturer_name": "VILLEROY & BOCH",
      "product_seria": "OBERON",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29
      },
      "exchangeRate_product_price_online": {
        "EUR": 29
      },
      "product_price": "650",
      "product_currency": "EUR",
      "product_price_old": "1464.0000",
      "product_price_online": "18850",
      "sourcePrice": "1024.80",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_036164_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_036164_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_036164_2.jpg"
      ],
      "description": "Ванна 190*90см с ножками",
      parameters: [
        {
          "parameter_id": "36164_000000071",
          "product_sku": "36164",
          "parameter_name": "Длина",
          "parameter_value": "1 900"
        },
        {
          "parameter_id": "36164_000000072",
          "product_sku": "36164",
          "parameter_name": "Ширина",
          "parameter_value": "900"
        },
        {
          "parameter_id": "36164_000000073",
          "product_sku": "36164",
          "parameter_name": "Высота",
          "parameter_value": "635"
        },
        {
          "parameter_id": "36164_000000074",
          "product_sku": "36164",
          "parameter_name": "Материал",
          "parameter_value": "Искуственный камень"
        },
        {
          "parameter_id": "36164_000000075",
          "product_sku": "36164",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый глянец"
        },
        {
          "parameter_id": "36164_000000076",
          "product_sku": "36164",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "36164_000000077",
          "product_sku": "36164",
          "parameter_name": "Ориентация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "36164_000000078",
          "product_sku": "36164",
          "parameter_name": "Монтаж",
          "parameter_value": "Пристенный"
        },
        {
          "parameter_id": "36164_000000080",
          "product_sku": "36164",
          "parameter_name": "Опора",
          "parameter_value": "Ножки"
        },
        {
          "parameter_id": "36164_000000081",
          "product_sku": "36164",
          "parameter_name": "Панель",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "36164_000000082",
          "product_sku": "36164",
          "parameter_name": "Сифон",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "36164_Brand",
          "product_sku": "36164",
          "parameter_name": "Бренд",
          "parameter_value": "VILLEROY & BOCH"
        },
        {
          "parameter_id": "36164_Series",
          "product_sku": "36164",
          "parameter_name": "Серия",
          "parameter_value": "OBERON"
        }
      ]
    },
    {
      "product_sku": "036195",
      "product_categoryId": "1800056",
      "product_name": "SOLO умывальник мебельный 50 см (укр.)",
      "product_mpn": "7195000U",
      "manufacturer_name": "KOLO Украина",
      "product_seria": "SOLO",
      "product_status": null,
      "exchangeRate_product_source_price": [],
      "exchangeRate_product_price_online": [],
      "product_price": "594",
      "product_currency": "UAH",
      "product_price_online": "576",
      "sourcePrice": "445.50",
      "sourceCurrency": "UAH",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_036195_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_036195_1.jpg"
      ],
      "description": "SOLO умывальник мебельный 50 см, с отверстием под смеситель, с переливом",
      parameters: [
        {
          "parameter_id": "36195_000000013",
          "product_sku": "36195",
          "parameter_name": "Материал",
          "parameter_value": "Санфаянс"
        },
        {
          "parameter_id": "36195_000000014",
          "product_sku": "36195",
          "parameter_name": "Глубина",
          "parameter_value": "420"
        },
        {
          "parameter_id": "36195_000000016",
          "product_sku": "36195",
          "parameter_name": "Монтаж",
          "parameter_value": "Накладной"
        },
        {
          "parameter_id": "36195_000000018",
          "product_sku": "36195",
          "parameter_name": "Форма",
          "parameter_value": "Округлая"
        },
        {
          "parameter_id": "36195_000000023",
          "product_sku": "36195",
          "parameter_name": "Тип установки смесителя",
          "parameter_value": "1 отверстие"
        },
        {
          "parameter_id": "36195_000000026",
          "product_sku": "36195",
          "parameter_name": "Страна производитель",
          "parameter_value": "Польша"
        },
        {
          "parameter_id": "36195_000000029",
          "product_sku": "36195",
          "parameter_name": "Перелив",
          "parameter_value": "С переливом"
        },
        {
          "parameter_id": "36195_Brand",
          "product_sku": "36195",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Украина"
        },
        {
          "parameter_id": "36195_Series",
          "product_sku": "36195",
          "parameter_name": "Серия",
          "parameter_value": "SOLO"
        }
      ]
    },
    {
      "product_sku": "036228",
      "product_categoryId": "180008",
      "product_name": "FREJA бачок 3/6 л керамический с крышкой, без арматуры (укр.)",
      "product_mpn": "L74000000",
      "manufacturer_name": "KOLO Украина",
      "product_seria": "FREJA",
      "product_status": null,
      "exchangeRate_product_source_price": [],
      "exchangeRate_product_price_online": [],
      "product_price": "693",
      "product_currency": "UAH",
      "product_price_online": "693",
      "sourcePrice": "519.75",
      "sourceCurrency": "UAH",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_036228_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_036228_1.jpg"
      ],
      "description": "Бачок 3/6 л керамический с крышкой (укр.) Kolo FREJA",
      parameters: [
        {
          "parameter_id": "36228_000000018",
          "product_sku": "36228",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "36228_000000019",
          "product_sku": "36228",
          "parameter_name": "Подвод воды",
          "parameter_value": "Нижний"
        },
        {
          "parameter_id": "36228_000000022",
          "product_sku": "36228",
          "parameter_name": "Тип управления",
          "parameter_value": "Двойной"
        },
        {
          "parameter_id": "36228_000000026",
          "product_sku": "36228",
          "parameter_name": "Страна производитель",
          "parameter_value": "Польша"
        },
        {
          "parameter_id": "36228_Brand",
          "product_sku": "36228",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Украина"
        },
        {
          "parameter_id": "36228_Series",
          "product_sku": "36228",
          "parameter_name": "Серия",
          "parameter_value": "FREJA"
        }
      ]
    },
    {
      "product_sku": "036250",
      "product_categoryId": "400068",
      "product_name": "Focus Смеситель для кухни, однорычажный",
      "product_mpn": "31815000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "FOCUS",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "226.53",
      "product_currency": "EUR",
      "product_price_online": "6796",
      "sourcePrice": "147.24",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_036250_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_036250_1.jpg"
      ],
      "description": "Focus Смеситель для кухни, однорычажныйПоворотная область 150°, ламинарная и душевая струя, душевая струя, которая фиксируется, настройка струи нажатием кнопки, магнитный держатель для душа MagFit, душевой шланг Quick-Connect, подходит для работы с проточным водонагревателем",
      parameters: [
        {
          "parameter_id": "36250_000000106",
          "product_sku": "36250",
          "parameter_name": "Длина излива",
          "parameter_value": "220"
        },
        {
          "parameter_id": "36250_000000107",
          "product_sku": "36250",
          "parameter_name": "Высота излива",
          "parameter_value": "157"
        },
        {
          "parameter_id": "36250_000000108",
          "product_sku": "36250",
          "parameter_name": "Высота смесителя",
          "parameter_value": "411"
        },
        {
          "parameter_id": "36250_000000109",
          "product_sku": "36250",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной"
        },
        {
          "parameter_id": "36250_000000110",
          "product_sku": "36250",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "36250_000000111",
          "product_sku": "36250",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "36250_000000112",
          "product_sku": "36250",
          "parameter_name": "Тип излива",
          "parameter_value": "U-образный"
        },
        {
          "parameter_id": "36250_000000113",
          "product_sku": "36250",
          "parameter_name": "Выдвижной излив",
          "parameter_value": "Да"
        },
        {
          "parameter_id": "36250_000000114",
          "product_sku": "36250",
          "parameter_name": "Вывод для фильтрованной в",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "36250_000000115",
          "product_sku": "36250",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "36250_000000116",
          "product_sku": "36250",
          "parameter_name": "Особенности",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "36250_Brand",
          "product_sku": "36250",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "36250_Series",
          "product_sku": "36250",
          "parameter_name": "Серия",
          "parameter_value": "FOCUS"
        }
      ]
    },
    {
      "product_sku": "037658",
      "product_categoryId": "180008",
      "product_name": "O.NOVO бачок с боковым подключением",
      "product_mpn": "57605101",
      "manufacturer_name": "VILLEROY & BOCH",
      "product_seria": "O.NOVO",
      "product_status": "Распродажа",
      "product_price": "166",
      "product_currency": "EUR",
      "product_price_online": "166",
      "sourcePrice": "89.64",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_037658_0.jpg"
      ],
      "description": "Бачок сливной, сливной механизм с двойной кнопкой, слив 3/6 л, хром",
      parameters: [
        {
          "parameter_id": "37658_000000018",
          "product_sku": "37658",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "37658_000000019",
          "product_sku": "37658",
          "parameter_name": "Подвод воды",
          "parameter_value": "Боковой"
        },
        {
          "parameter_id": "37658_000000022",
          "product_sku": "37658",
          "parameter_name": "Тип управления",
          "parameter_value": "Двойной"
        },
        {
          "parameter_id": "37658_000000026",
          "product_sku": "37658",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "37658_Brand",
          "product_sku": "37658",
          "parameter_name": "Бренд",
          "parameter_value": "VILLEROY & BOCH"
        },
        {
          "parameter_id": "37658_Series",
          "product_sku": "37658",
          "parameter_name": "Серия",
          "parameter_value": "O.NOVO"
        }
      ]
    },
    {
      "product_sku": "037664",
      "product_categoryId": "400070",
      "product_name": "Душ верхний 200х200 мм",
      "product_mpn": "SQ200",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "39",
      "product_currency": "EUR",
      "product_price_online": "1151",
      "sourcePrice": "27.30",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_037664_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_037664_1.jpg"
      ],
      "description": "Душ верхний, диаметр 200 ммЛейка, размер: 200х200 мм, 1 функция: ливень, поверхность: хром",
      parameters: [
        {
          "parameter_id": "37664_000000142",
          "product_sku": "37664",
          "parameter_name": "Длина лейки верхнего душа, мм",
          "parameter_value": "200"
        },
        {
          "parameter_id": "37664_000000143",
          "product_sku": "37664",
          "parameter_name": "Длина кронштейна (от стены), мм",
          "parameter_value": "0"
        },
        {
          "parameter_id": "37664_000000144",
          "product_sku": "37664",
          "parameter_name": "Ширина лейки верхнего душа, мм",
          "parameter_value": "200"
        },
        {
          "parameter_id": "37664_000000145",
          "product_sku": "37664",
          "parameter_name": "Материал лейки",
          "parameter_value": "Пластик"
        },
        {
          "parameter_id": "37664_000000146",
          "product_sku": "37664",
          "parameter_name": "Форма лейки верхнего душа",
          "parameter_value": "Квадратная"
        },
        {
          "parameter_id": "37664_000000147",
          "product_sku": "37664",
          "parameter_name": "Монтаж",
          "parameter_value": "Универсальный"
        },
        {
          "parameter_id": "37664_000000148",
          "product_sku": "37664",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "37664_000000149",
          "product_sku": "37664",
          "parameter_name": "Кол-во режимов верхнего душа",
          "parameter_value": "1"
        },
        {
          "parameter_id": "37664_Brand",
          "product_sku": "37664",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "37664_Series",
          "product_sku": "37664",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "037665",
      "product_categoryId": "400071",
      "product_name": "Набор душевой (ручной душ 1 режим, шланг, держатель), сатин",
      "product_mpn": "1115+S023+W100SL1 BN",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "20",
      "product_currency": "EUR",
      "product_price_online": "590",
      "sourcePrice": "14",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_037665_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_037665_1.jpg"
      ],
      "description": "Набор душевой - ручной душ 1 режим, шланг, держатель, сатин, блистерЛейка диаметр: 100 мм, поверхность: хром, 1 функция: ливень, шланг гибкий двойное обплетение длина: 150 см, держатель, поверхность: сатин",
      parameters: [
        {
          "parameter_id": "37665_000000150",
          "product_sku": "37665",
          "parameter_name": "Высота, мм",
          "parameter_value": "0"
        },
        {
          "parameter_id": "37665_000000151",
          "product_sku": "37665",
          "parameter_name": "Тип держателя",
          "parameter_value": "Держатель"
        },
        {
          "parameter_id": "37665_000000152",
          "product_sku": "37665",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Сатин"
        },
        {
          "parameter_id": "37665_000000153",
          "product_sku": "37665",
          "parameter_name": "Форма лейки ручного душа",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "37665_000000154",
          "product_sku": "37665",
          "parameter_name": "Мыльница",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "37665_000000155",
          "product_sku": "37665",
          "parameter_name": "Кол-во режимов ручного душа",
          "parameter_value": "1"
        },
        {
          "parameter_id": "37665_000000175",
          "product_sku": "37665",
          "parameter_name": "Диаметр/Диагональ, мм",
          "parameter_value": "100"
        },
        {
          "parameter_id": "37665_000000176",
          "product_sku": "37665",
          "parameter_name": "Способ переключения режимов",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "37665_000000177",
          "product_sku": "37665",
          "parameter_name": "Цвет диска ручного душа",
          "parameter_value": "Сатин"
        },
        {
          "parameter_id": "37665_Brand",
          "product_sku": "37665",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "37665_Series",
          "product_sku": "37665",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "037666",
      "product_categoryId": "400071",
      "product_name": "Набор душевой (ручной душ 3 режима, шланг, держатель)",
      "product_mpn": "S1001003",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "19",
      "product_currency": "EUR",
      "product_price_online": "561",
      "sourcePrice": "13.30",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_037666_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_037666_1.jpg"
      ],
      "description": "Набор душевой - ручной душ 3 режима, шланг, держатель, блистерЛейка диаметр: 100 мм, поверхность: хром, 3 функции: ливень, массаж, туман, шланг гибкий двойное обплетение длина: 150 см, держатель, поверхность: хром",
      parameters: [
        {
          "parameter_id": "37666_000000150",
          "product_sku": "37666",
          "parameter_name": "Высота, мм",
          "parameter_value": "0"
        },
        {
          "parameter_id": "37666_000000151",
          "product_sku": "37666",
          "parameter_name": "Тип держателя",
          "parameter_value": "Держатель"
        },
        {
          "parameter_id": "37666_000000152",
          "product_sku": "37666",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "37666_000000153",
          "product_sku": "37666",
          "parameter_name": "Форма лейки ручного душа",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "37666_000000154",
          "product_sku": "37666",
          "parameter_name": "Мыльница",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "37666_000000155",
          "product_sku": "37666",
          "parameter_name": "Кол-во режимов ручного душа",
          "parameter_value": "3"
        },
        {
          "parameter_id": "37666_000000175",
          "product_sku": "37666",
          "parameter_name": "Диаметр/Диагональ, мм",
          "parameter_value": "100"
        },
        {
          "parameter_id": "37666_000000176",
          "product_sku": "37666",
          "parameter_name": "Способ переключения режимов",
          "parameter_value": "Поворотный"
        },
        {
          "parameter_id": "37666_000000177",
          "product_sku": "37666",
          "parameter_name": "Цвет диска ручного душа",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "37666_Brand",
          "product_sku": "37666",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "37666_Series",
          "product_sku": "37666",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "038445",
      "product_categoryId": "40003",
      "product_name": "BREEZE смеситель для умывальника двухвентильный 1/2 \"крестики\", хром",
      "product_mpn": "RBZ017-1",
      "manufacturer_name": "ROZZY JENORI",
      "product_seria": "BREEZE",
      "product_status": null,
      "product_price": "27",
      "product_currency": "USD",
      "product_price_online": "27",
      "sourcePrice": "16.20",
      "sourceCurrency": "USD",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_038445_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_038445_1.jpg"
      ],
      "description": "Двухвентильный смеситель для раковины, двухвентильный, крестовые ручки, хром",
      parameters: [
        {
          "parameter_id": "38445_000000117",
          "product_sku": "38445",
          "parameter_name": "Длина излива",
          "parameter_value": "125"
        },
        {
          "parameter_id": "38445_000000118",
          "product_sku": "38445",
          "parameter_name": "Высота излива",
          "parameter_value": "105"
        },
        {
          "parameter_id": "38445_000000119",
          "product_sku": "38445",
          "parameter_name": "Высота смесителя",
          "parameter_value": "125"
        },
        {
          "parameter_id": "38445_000000120",
          "product_sku": "38445",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной"
        },
        {
          "parameter_id": "38445_000000121",
          "product_sku": "38445",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "38445_000000122",
          "product_sku": "38445",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "38445_000000123",
          "product_sku": "38445",
          "parameter_name": "Тип управления",
          "parameter_value": "Двухвентильный"
        },
        {
          "parameter_id": "38445_000000124",
          "product_sku": "38445",
          "parameter_name": "Наличие донного клапана",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "38445_000000125",
          "product_sku": "38445",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "1"
        },
        {
          "parameter_id": "38445_Brand",
          "product_sku": "38445",
          "parameter_name": "Бренд",
          "parameter_value": "ROZZY JENORI"
        },
        {
          "parameter_id": "38445_Series",
          "product_sku": "38445",
          "parameter_name": "Серия",
          "parameter_value": "BREEZE"
        }
      ]
    },
    {
      "product_sku": "038446",
      "product_categoryId": "400042",
      "product_name": "BREEZE смеситель для ванны, излив 250 мм (прямой), двухвентильный 1/2 \"крестики\",  хром",
      "product_mpn": "RBZ017-9B",
      "manufacturer_name": "ROZZY JENORI",
      "product_seria": "BREEZE",
      "product_status": null,
      "product_price": "39",
      "product_currency": "USD",
      "product_price_online": "39",
      "sourcePrice": "23.40",
      "sourceCurrency": "USD",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_038446_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_038446_1.jpg"
      ],
      "description": "Двухвентильный смеситель для ванны, излив 250 мм (прямой), двухвентильный, ручки крестики, покрытие: хром; в комплекте: шланг, лейка, держатель",
      parameters: [
        {
          "parameter_id": "38446_000000093",
          "product_sku": "38446",
          "parameter_name": "Длина излива",
          "parameter_value": "300"
        },
        {
          "parameter_id": "38446_000000094",
          "product_sku": "38446",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "38446_000000095",
          "product_sku": "38446",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "38446_000000096",
          "product_sku": "38446",
          "parameter_name": "Комплектация",
          "parameter_value": "Лейка, шланг, держатель"
        },
        {
          "parameter_id": "38446_000000097",
          "product_sku": "38446",
          "parameter_name": "Тип управления",
          "parameter_value": "Двухвентильный"
        },
        {
          "parameter_id": "38446_000000098",
          "product_sku": "38446",
          "parameter_name": "Тип переключателя ванна/душ",
          "parameter_value": "Поворотный"
        },
        {
          "parameter_id": "38446_000000099",
          "product_sku": "38446",
          "parameter_name": "Повротный излив",
          "parameter_value": "Да"
        },
        {
          "parameter_id": "38446_000000100",
          "product_sku": "38446",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "2"
        },
        {
          "parameter_id": "38446_000000126",
          "product_sku": "38446",
          "parameter_name": "Кол-во потребителей",
          "parameter_value": "2"
        },
        {
          "parameter_id": "38446_000000128",
          "product_sku": "38446",
          "parameter_name": "Форма накладки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "38446_Brand",
          "product_sku": "38446",
          "parameter_name": "Бренд",
          "parameter_value": "ROZZY JENORI"
        },
        {
          "parameter_id": "38446_Series",
          "product_sku": "38446",
          "parameter_name": "Серия",
          "parameter_value": "BREEZE"
        }
      ]
    },
    {
      "product_sku": "038533",
      "product_categoryId": "400053",
      "product_name": "FIESTA смеситель для душа, хром, 35 мм",
      "product_mpn": "15153100",
      "manufacturer_name": "VOLLE",
      "product_seria": "FIESTA",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "40",
      "product_currency": "EUR",
      "product_price_online": "1180",
      "sourcePrice": "26",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_038533_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_038533_1.jpg"
      ],
      "description": "Смеситель для душа Volle Fiesta 15153100\nХарактеристики:\n•\tТип управления - однорычажный\n•\tТип монтажа - настенный, 2 отверстия\n•\tМатериал - латунь\n•\tПокрытие - хром\n•\tРасход воды - до 22 л/мин\n•\tКерамический картридж Sedal Ø 35 мм\n•\tВ комплект входят эксцентрики с возможностью регулирования +/- 10 мм\nДизайн изделия отвечает современным тенденциям в области интерьеров ванных комнат и основным требованиям эргономичности. Смеситель спроектирован в соответствии с концепцией ТМ Volle и потому великолепно сочетается с большинством коллекций сантехники.\nИспользование в качестве материала смесителя латуни гарантирует многолетнюю беспроблемную работу, а надёжный керамический картридж способствует удобной регулировке температуры и экономии воды.\nГарантия: \n•\tКорпус смесителя - 5 лет\n•\tПодвижные и неметаллические комплектующие - 2 года\nВ случае использования продукции в общественной или промышленной сферах гарантийный срок составляет 6 месяцев",
      parameters: [
        {
          "parameter_id": "38533_000000101",
          "product_sku": "38533",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "38533_000000102",
          "product_sku": "38533",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "38533_000000103",
          "product_sku": "38533",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "38533_000000104",
          "product_sku": "38533",
          "parameter_name": "С полочкой",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "38533_000000105",
          "product_sku": "38533",
          "parameter_name": "Положение регулятора",
          "parameter_value": "Спереди по центру"
        },
        {
          "parameter_id": "38533_000000129",
          "product_sku": "38533",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "38533_000000130",
          "product_sku": "38533",
          "parameter_name": "Форма накладки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "38533_Brand",
          "product_sku": "38533",
          "parameter_name": "Бренд",
          "parameter_value": "VOLLE"
        },
        {
          "parameter_id": "38533_Series",
          "product_sku": "38533",
          "parameter_name": "Серия",
          "parameter_value": "FIESTA"
        }
      ]
    },
    {
      "product_sku": "038534",
      "product_categoryId": "400032",
      "product_name": "KRINICE смеситель для биде, хром,  35мм",
      "product_mpn": "40110",
      "manufacturer_name": "IMPRESE",
      "product_seria": "KRINICE",
      "product_status": "Спеццена",
      "product_price": "27",
      "product_currency": "EUR",
      "product_price_old": "36.0000",
      "product_price_online": "27",
      "sourcePrice": "19.08",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_038534_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_038534_1.jpg"
      ],
      "description": "KRINICE смеситель для биде, хром, 35мм Однорычажный, керамический узел смешивания, расход воды до 7 л/мин, аэратор, подходит для проточных нагревателей\nМодель установленного картриджа Sedal EN- 35 С/D",
      parameters: [
        {
          "parameter_id": "38534_000000087",
          "product_sku": "38534",
          "parameter_name": "Длина излива",
          "parameter_value": "10,8"
        },
        {
          "parameter_id": "38534_000000088",
          "product_sku": "38534",
          "parameter_name": "Высота излива",
          "parameter_value": "11,1"
        },
        {
          "parameter_id": "38534_000000089",
          "product_sku": "38534",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "38534_000000090",
          "product_sku": "38534",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "38534_000000091",
          "product_sku": "38534",
          "parameter_name": "Наличие донного клапана",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "38534_000000092",
          "product_sku": "38534",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "1"
        },
        {
          "parameter_id": "38534_Brand",
          "product_sku": "38534",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "38534_Series",
          "product_sku": "38534",
          "parameter_name": "Серия",
          "parameter_value": "KRINICE"
        }
      ]
    },
    {
      "product_sku": "038535",
      "product_categoryId": "400032",
      "product_name": "VYSKOV смеситель для биде,хром, 35 мм",
      "product_mpn": "40340",
      "manufacturer_name": "IMPRESE",
      "product_seria": "VYSKOV",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "62",
      "product_currency": "EUR",
      "product_price_online": "1829",
      "sourcePrice": "43.40",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_038535_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_038535_1.jpg"
      ],
      "description": "VYSKOV смеситель для биде,хром, 35мм Однорычажный, керамический узел смешивания, расход воды до 7 л/мин, движущийся аэратор, подходит для проточных нагревателей",
      parameters: [
        {
          "parameter_id": "38535_000000087",
          "product_sku": "38535",
          "parameter_name": "Длина излива",
          "parameter_value": "12,9"
        },
        {
          "parameter_id": "38535_000000088",
          "product_sku": "38535",
          "parameter_name": "Высота излива",
          "parameter_value": "12,6"
        },
        {
          "parameter_id": "38535_000000089",
          "product_sku": "38535",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "38535_000000090",
          "product_sku": "38535",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "38535_000000091",
          "product_sku": "38535",
          "parameter_name": "Наличие донного клапана",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "38535_000000092",
          "product_sku": "38535",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "1"
        },
        {
          "parameter_id": "38535_Brand",
          "product_sku": "38535",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "38535_Series",
          "product_sku": "38535",
          "parameter_name": "Серия",
          "parameter_value": "VYSKOV"
        }
      ]
    },
    {
      "product_sku": "038537",
      "product_categoryId": "400070",
      "product_name": "KRINICE душ верхний 100 мм, держатель",
      "product_mpn": "VR-15110 (S)",
      "manufacturer_name": "IMPRESE",
      "product_seria": "KRINICE",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "29",
      "product_currency": "EUR",
      "product_price_online": "856",
      "sourcePrice": "20.30",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_038537_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_038537_1.jpg"
      ],
      "description": "KRINICE душ верхний (диам. 100мм) для смесителя скрытого монтажаФорма верхнего душа: круглая, диаметр верхнего душа: 100 мм, расход воды верхнего душа: до 11,2 л/хв",
      parameters: [
        {
          "parameter_id": "38537_000000142",
          "product_sku": "38537",
          "parameter_name": "Длина лейки верхнего душа, мм",
          "parameter_value": "100"
        },
        {
          "parameter_id": "38537_000000143",
          "product_sku": "38537",
          "parameter_name": "Длина кронштейна (от стены), мм",
          "parameter_value": "153"
        },
        {
          "parameter_id": "38537_000000144",
          "product_sku": "38537",
          "parameter_name": "Ширина лейки верхнего душа, мм",
          "parameter_value": "100"
        },
        {
          "parameter_id": "38537_000000145",
          "product_sku": "38537",
          "parameter_name": "Материал лейки",
          "parameter_value": "Пластик"
        },
        {
          "parameter_id": "38537_000000146",
          "product_sku": "38537",
          "parameter_name": "Форма лейки верхнего душа",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "38537_000000147",
          "product_sku": "38537",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "38537_000000148",
          "product_sku": "38537",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "38537_000000149",
          "product_sku": "38537",
          "parameter_name": "Кол-во режимов верхнего душа",
          "parameter_value": "1"
        },
        {
          "parameter_id": "38537_Brand",
          "product_sku": "38537",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "38537_Series",
          "product_sku": "38537",
          "parameter_name": "Серия",
          "parameter_value": "KRINICE"
        }
      ]
    },
    {
      "product_sku": "038538",
      "product_categoryId": "400010",
      "product_name": "Шланг для душа с двойной оплеткой, стандарт, 1,6 м ПЭпак",
      "product_mpn": "1116",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "6",
      "product_currency": "EUR",
      "product_price_online": "177",
      "sourcePrice": "4.20",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_038538_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_038538_1.jpg"
      ],
      "description": "Шланг для душа, нержавеющая сталь, двойное обплетение, диаметр подключения 1/2, длина 1,6 м",
      parameters: [
        {
          "parameter_id": "38538_000000013",
          "product_sku": "38538",
          "parameter_name": "Материал",
          "parameter_value": "Металл"
        },
        {
          "parameter_id": "38538_000000015",
          "product_sku": "38538",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "1 600"
        },
        {
          "parameter_id": "38538_000000025",
          "product_sku": "38538",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "38538_000000026",
          "product_sku": "38538",
          "parameter_name": "Страна производитель",
          "parameter_value": "Чехия"
        },
        {
          "parameter_id": "38538_Brand",
          "product_sku": "38538",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "38538_Series",
          "product_sku": "38538",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "038540",
      "product_categoryId": "1400077",
      "product_name": "GEBERIT cлив-перелив с поворотной ручкой и крышкой сливного отверстия",
      "product_mpn": "150.520.21.1",
      "manufacturer_name": "GEBERIT",
      "product_seria": "GEBERIT",
      "product_status": "Спеццена",
      "exchangeRate_product_source_price": [],
      "exchangeRate_product_price_online": [],
      "product_price": "894",
      "product_currency": "UAH",
      "product_price_online": "858",
      "sourcePrice": "670.50",
      "sourceCurrency": "UAH",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_038540_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_038540_1.jpg"
      ],
      "description": "Слив-перелив с поворотной ручкой и крышкой сливного отверстия. Полуавтомат, серый, диаметр 70*50 мм, длина 390 мм, пластик, с переливом",
      parameters: [
        {
          "parameter_id": "38540_000000006",
          "product_sku": "38540",
          "parameter_name": "Диаметр (мм)",
          "parameter_value": "70"
        },
        {
          "parameter_id": "38540_000000007",
          "product_sku": "38540",
          "parameter_name": "Диаметр 2 (мм)",
          "parameter_value": "50"
        },
        {
          "parameter_id": "38540_000000013",
          "product_sku": "38540",
          "parameter_name": "Материал",
          "parameter_value": "Пластик"
        },
        {
          "parameter_id": "38540_000000015",
          "product_sku": "38540",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "390"
        },
        {
          "parameter_id": "38540_000000018",
          "product_sku": "38540",
          "parameter_name": "Форма",
          "parameter_value": "Трубная"
        },
        {
          "parameter_id": "38540_000000022",
          "product_sku": "38540",
          "parameter_name": "Тип управления",
          "parameter_value": "Полуавтомат"
        },
        {
          "parameter_id": "38540_000000025",
          "product_sku": "38540",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Серый"
        },
        {
          "parameter_id": "38540_000000026",
          "product_sku": "38540",
          "parameter_name": "Страна производитель",
          "parameter_value": "Швейцария"
        },
        {
          "parameter_id": "38540_000000029",
          "product_sku": "38540",
          "parameter_name": "Перелив",
          "parameter_value": "С переливом"
        },
        {
          "parameter_id": "38540_Brand",
          "product_sku": "38540",
          "parameter_name": "Бренд",
          "parameter_value": "GEBERIT"
        },
        {
          "parameter_id": "38540_Series",
          "product_sku": "38540",
          "parameter_name": "Серия",
          "parameter_value": "GEBERIT"
        }
      ]
    },
    {
      "product_sku": "038560",
      "product_categoryId": "400020",
      "product_name": "RAINSHOWER кронштейн душевой",
      "product_mpn": "27709000",
      "manufacturer_name": "GROHE",
      "product_seria": "RAINSHOWER",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "90.47",
      "product_currency": "EUR",
      "product_price_old": "112.0000",
      "product_price_online": "2669",
      "sourcePrice": "62.24",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_038560_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_038560_1.jpg"
      ],
      "description": "Rainshower Кронштейн душевой286 мм, резьбовое соединение 1/2&amp;amp;quot;, хром",
      parameters: [
        {
          "parameter_id": "38560_000000016",
          "product_sku": "38560",
          "parameter_name": "Монтаж",
          "parameter_value": "Встраиваемый в стену"
        },
        {
          "parameter_id": "38560_000000025",
          "product_sku": "38560",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "38560_000000026",
          "product_sku": "38560",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "38560_Brand",
          "product_sku": "38560",
          "parameter_name": "Бренд",
          "parameter_value": "GROHE"
        },
        {
          "parameter_id": "38560_Series",
          "product_sku": "38560",
          "parameter_name": "Серия",
          "parameter_value": "RAINSHOWER"
        }
      ]
    },
    {
      "product_sku": "038572",
      "product_categoryId": "600086",
      "product_name": "EASYSTEP набор деталей для слива и крышка сливного отверстия до 0,6л/с",
      "product_mpn": "215480R91",
      "manufacturer_name": "HUPPE",
      "product_seria": "EASY STEP",
      "product_status": null,
      "product_price": "61.95",
      "product_currency": "EUR",
      "product_price_online": "61.95",
      "sourcePrice": "40.27",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_038572_0.jpg"
      ],
      "description": "EASYSTEP набор деталей для слива и крышка сливного отверстия до 0,6л/с",
      parameters: [
        {
          "parameter_id": "38572_000000026",
          "product_sku": "38572",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "38572_Brand",
          "product_sku": "38572",
          "parameter_name": "Бренд",
          "parameter_value": "HUPPE"
        },
        {
          "parameter_id": "38572_Series",
          "product_sku": "38572",
          "parameter_name": "Серия",
          "parameter_value": "EASY STEP"
        }
      ]
    },
    {
      "product_sku": "038624",
      "product_categoryId": "400068",
      "product_name": "Metris Смеситель для кухни, однорычажный",
      "product_mpn": "14822000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "METRIS",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "317",
      "product_currency": "EUR",
      "product_price_online": "9510",
      "sourcePrice": "206.05",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_038624_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_038624_1.jpg"
      ],
      "description": "Metris Смеситель для кухни, однорычажныйПоворотная область устанавливается в 3 положения: 110°, 150° або 360°, ламинарная струя, подходит для работы с проточным водонагревателем",
      parameters: [
        {
          "parameter_id": "38624_Brand",
          "product_sku": "38624",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "38624_Series",
          "product_sku": "38624",
          "parameter_name": "Серия",
          "parameter_value": "METRIS"
        }
      ]
    },
    {
      "product_sku": "038669",
      "product_categoryId": "400071",
      "product_name": "EUPHORIA Душевой набор, 600мм",
      "product_mpn": "27230001",
      "manufacturer_name": "GROHE",
      "product_seria": "EUPHORIA",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "74.54",
      "product_currency": "EUR",
      "product_price_old": "106.0000",
      "product_price_online": "2199",
      "sourcePrice": "56.26",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_038669_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_038669_1.jpg"
      ],
      "description": "Euphoria Душевой набор, 600мм2 вида струи: Rain / SmartRain, включает в себя: ручной душ Duo, душевая штанга 600 мм, душевой шланг 1750 мм, полочка; с системой SpeedClean против известковых отложений, внутренний охлаждающий канал для продолжительного срока службы, twistfree против перекручивания шланга; хром",
      parameters: [
        {
          "parameter_id": "38669_Brand",
          "product_sku": "38669",
          "parameter_name": "Бренд",
          "parameter_value": "GROHE"
        },
        {
          "parameter_id": "38669_Series",
          "product_sku": "38669",
          "parameter_name": "Серия",
          "parameter_value": "EUPHORIA"
        }
      ]
    },
    {
      "product_sku": "038670",
      "product_categoryId": "400010",
      "product_name": "ROTAFLEX шланг для душа",
      "product_mpn": "28417000",
      "manufacturer_name": "GROHE",
      "product_seria": "Rotaflex",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "26.41",
      "product_currency": "EUR",
      "product_price_old": "37.0000",
      "product_price_online": "779",
      "sourcePrice": "19.43",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_038670_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_038670_1.jpg"
      ],
      "description": "Rotaflex Душевой шлангПоворотный конус для функции Twistfree (против перекручивания шланга), конус с силиконовыми прокладками для избежания вращения лейки в положении бокового душа; металл, 1500 мм",
      parameters: [
        {
          "parameter_id": "38670_000000013",
          "product_sku": "38670",
          "parameter_name": "Материал",
          "parameter_value": "Металл"
        },
        {
          "parameter_id": "38670_000000015",
          "product_sku": "38670",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "1 500"
        },
        {
          "parameter_id": "38670_000000025",
          "product_sku": "38670",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "38670_000000026",
          "product_sku": "38670",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "38670_Brand",
          "product_sku": "38670",
          "parameter_name": "Бренд",
          "parameter_value": "GROHE"
        },
        {
          "parameter_id": "38670_Series",
          "product_sku": "38670",
          "parameter_name": "Серия",
          "parameter_value": "Rotaflex"
        }
      ]
    },
    {
      "product_sku": "042312",
      "product_categoryId": "18000102",
      "product_name": "NOVA PRO сиденье с крышкой твердое прямоугольное, из материала Duroplast, с микролифтом (пол.)",
      "product_mpn": "M30116000",
      "manufacturer_name": "KOLO Польша",
      "product_seria": "NOVA PRO",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042312_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042312_1.jpg"
      ],
      "description": "Сидение с крышкой прямоугольное, soft-close, из материала Duroplast, металлические петлиГлубина 440 мм, ширина 345 мм",
      parameters: [
        {
          "parameter_id": "42312_000000018",
          "product_sku": "42312",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "42312_000000026",
          "product_sku": "42312",
          "parameter_name": "Страна производитель",
          "parameter_value": "Польша"
        },
        {
          "parameter_id": "42312_000000027",
          "product_sku": "42312",
          "parameter_name": "Тип сидения",
          "parameter_value": "Дюропласт"
        },
        {
          "parameter_id": "42312_Brand",
          "product_sku": "42312",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Польша"
        },
        {
          "parameter_id": "42312_Series",
          "product_sku": "42312",
          "parameter_name": "Серия",
          "parameter_value": "NOVA PRO"
        }
      ]
    },
    {
      "product_sku": "042313",
      "product_categoryId": "800063",
      "product_name": "NOVA PRO умывальник 60см прямоугольный, со шкафчиком для умывальника, белый глянец",
      "product_mpn": "M39006000",
      "manufacturer_name": "KOLO Польша",
      "product_seria": "NOVA PRO",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042313_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042313_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042313_2.jpg"
      ],
      "description": "NOVA PRO комплект: умывальник 60 cm прямоугольный + шкафчик для умывальника, цвет белый глянец, умывальник с переливом, с отверстием под смеситель, материал шкафчика ДСП, 600х400х557 мм",
      parameters: [
        {
          "parameter_id": "42313_000000001",
          "product_sku": "42313",
          "parameter_name": "Ширина",
          "parameter_value": "600"
        },
        {
          "parameter_id": "42313_000000009",
          "product_sku": "42313",
          "parameter_name": "Комплектация",
          "parameter_value": "Тумба+раковина"
        },
        {
          "parameter_id": "42313_000000010",
          "product_sku": "42313",
          "parameter_name": "Тип дверей",
          "parameter_value": "Распашные"
        },
        {
          "parameter_id": "42313_000000013",
          "product_sku": "42313",
          "parameter_name": "Материал",
          "parameter_value": "ДСП"
        },
        {
          "parameter_id": "42313_000000014",
          "product_sku": "42313",
          "parameter_name": "Глубина",
          "parameter_value": "400"
        },
        {
          "parameter_id": "42313_000000015",
          "product_sku": "42313",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "557"
        },
        {
          "parameter_id": "42313_000000016",
          "product_sku": "42313",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "42313_000000018",
          "product_sku": "42313",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "42313_000000023",
          "product_sku": "42313",
          "parameter_name": "Тип установки смесителя",
          "parameter_value": "1 отверстие"
        },
        {
          "parameter_id": "42313_000000025",
          "product_sku": "42313",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Белый глянец"
        },
        {
          "parameter_id": "42313_000000026",
          "product_sku": "42313",
          "parameter_name": "Страна производитель",
          "parameter_value": "Украина"
        },
        {
          "parameter_id": "42313_000000029",
          "product_sku": "42313",
          "parameter_name": "Перелив",
          "parameter_value": "С переливом"
        },
        {
          "parameter_id": "42313_Brand",
          "product_sku": "42313",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Польша"
        },
        {
          "parameter_id": "42313_Series",
          "product_sku": "42313",
          "parameter_name": "Серия",
          "parameter_value": "NOVA PRO"
        }
      ]
    },
    {
      "product_sku": "042315",
      "product_categoryId": "1800081",
      "product_name": "NOVA PRO боковая панель для умывальника 60cm, белый глянец",
      "product_mpn": "88449000",
      "manufacturer_name": "KOLO Польша",
      "product_seria": "NOVA PRO",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042315_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042315_1.jpg"
      ],
      "description": "Защитная боковая панель для умывальника, белый глянец, ширина 60 см, высота 30 см",
      parameters: [
        {
          "parameter_id": "42315_000000026",
          "product_sku": "42315",
          "parameter_name": "Страна производитель",
          "parameter_value": "Польша"
        },
        {
          "parameter_id": "42315_Brand",
          "product_sku": "42315",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Польша"
        },
        {
          "parameter_id": "42315_Series",
          "product_sku": "42315",
          "parameter_name": "Серия",
          "parameter_value": "NOVA PRO"
        }
      ]
    },
    {
      "product_sku": "042316",
      "product_categoryId": "200031",
      "product_name": "NOVA PRO панель для стеллажа, белый глянец",
      "product_mpn": "88434-000",
      "manufacturer_name": "KOLO Польша",
      "product_seria": "NOVA PRO",
      "product_status": "Распродажа",
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042316_0.jpg"
      ],
      "description": "Панель для стеллажа, белый глянец",
      parameters: [
        {
          "parameter_id": "42316_000000026",
          "product_sku": "42316",
          "parameter_name": "Страна производитель",
          "parameter_value": "Польша"
        },
        {
          "parameter_id": "42316_Brand",
          "product_sku": "42316",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Польша"
        },
        {
          "parameter_id": "42316_Series",
          "product_sku": "42316",
          "parameter_name": "Серия",
          "parameter_value": "NOVA PRO"
        }
      ]
    },
    {
      "product_sku": "042336",
      "product_categoryId": "40003",
      "product_name": "Logis 70 Смеситель для умывальника, однорычажный",
      "product_mpn": "71070000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "LOGIS",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042336_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042336_1.jpg"
      ],
      "description": "Logis Смеситель для раковины, однорычажный, обычная струя, расход воды: 5 л/мин",
      parameters: [
        {
          "parameter_id": "42336_000000117",
          "product_sku": "42336",
          "parameter_name": "Длина излива",
          "parameter_value": "107"
        },
        {
          "parameter_id": "42336_000000118",
          "product_sku": "42336",
          "parameter_name": "Высота излива",
          "parameter_value": "67"
        },
        {
          "parameter_id": "42336_000000119",
          "product_sku": "42336",
          "parameter_name": "Высота смесителя",
          "parameter_value": "138"
        },
        {
          "parameter_id": "42336_000000120",
          "product_sku": "42336",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной"
        },
        {
          "parameter_id": "42336_000000121",
          "product_sku": "42336",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "42336_000000122",
          "product_sku": "42336",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "42336_000000123",
          "product_sku": "42336",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "42336_000000124",
          "product_sku": "42336",
          "parameter_name": "Наличие донного клапана",
          "parameter_value": "Да"
        },
        {
          "parameter_id": "42336_000000125",
          "product_sku": "42336",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "1"
        },
        {
          "parameter_id": "42336_Brand",
          "product_sku": "42336",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "42336_Series",
          "product_sku": "42336",
          "parameter_name": "Серия",
          "parameter_value": "LOGIS"
        }
      ]
    },
    {
      "product_sku": "042341",
      "product_categoryId": "400042",
      "product_name": "Logis Смеситель для ванны, однорычажный",
      "product_mpn": "71400000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "LOGIS",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042341_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042341_1.jpg"
      ],
      "description": "Logis Смеситель для ванны, однорычажный",
      parameters: [
        {
          "parameter_id": "42341_000000093",
          "product_sku": "42341",
          "parameter_name": "Длина излива",
          "parameter_value": "194"
        },
        {
          "parameter_id": "42341_000000094",
          "product_sku": "42341",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "42341_000000095",
          "product_sku": "42341",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "42341_000000096",
          "product_sku": "42341",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "42341_000000097",
          "product_sku": "42341",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "42341_000000098",
          "product_sku": "42341",
          "parameter_name": "Тип переключателя ванна/душ",
          "parameter_value": "Выжимной"
        },
        {
          "parameter_id": "42341_000000099",
          "product_sku": "42341",
          "parameter_name": "Повротный излив",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "42341_000000100",
          "product_sku": "42341",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "2"
        },
        {
          "parameter_id": "42341_000000126",
          "product_sku": "42341",
          "parameter_name": "Кол-во потребителей",
          "parameter_value": "2"
        },
        {
          "parameter_id": "42341_000000128",
          "product_sku": "42341",
          "parameter_name": "Форма накладки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "42341_Brand",
          "product_sku": "42341",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "42341_Series",
          "product_sku": "42341",
          "parameter_name": "Серия",
          "parameter_value": "LOGIS"
        }
      ]
    },
    {
      "product_sku": "042342",
      "product_categoryId": "400053",
      "product_name": "Logis Смеситель для душа, однорычажный",
      "product_mpn": "71600000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "LOGIS",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042342_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042342_1.jpg"
      ],
      "description": "Logis Смеситель для душа, однорычажный Тип соединения: S - соединение, расстояние по центрам: 150 mm ± 12 mm, расход воды: 22 л/мин, клапан обратного движения",
      parameters: [
        {
          "parameter_id": "42342_000000101",
          "product_sku": "42342",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "42342_000000102",
          "product_sku": "42342",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "42342_000000103",
          "product_sku": "42342",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "42342_000000104",
          "product_sku": "42342",
          "parameter_name": "С полочкой",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "42342_000000105",
          "product_sku": "42342",
          "parameter_name": "Положение регулятора",
          "parameter_value": "Спереди по центру"
        },
        {
          "parameter_id": "42342_000000129",
          "product_sku": "42342",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "42342_000000130",
          "product_sku": "42342",
          "parameter_name": "Форма накладки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "42342_Brand",
          "product_sku": "42342",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "42342_Series",
          "product_sku": "42342",
          "parameter_name": "Серия",
          "parameter_value": "LOGIS"
        }
      ]
    },
    {
      "product_sku": "042347",
      "product_categoryId": "18000102",
      "product_name": "VICTORIA сиденье с системой плавного опускания, с пластиковыми креплениями Pure L",
      "product_mpn": "801338N04P",
      "manufacturer_name": "HARO",
      "product_seria": "VICTORIA",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042347_0.jpg"
      ],
      "description": "VICTORIA сиденье slow-closing с пластиковыми креплениями Pure",
      parameters: [
        {
          "parameter_id": "42347_000000018",
          "product_sku": "42347",
          "parameter_name": "Форма",
          "parameter_value": "Округлая"
        },
        {
          "parameter_id": "42347_000000027",
          "product_sku": "42347",
          "parameter_name": "Тип сидения",
          "parameter_value": "Дюропласт"
        },
        {
          "parameter_id": "42347_Brand",
          "product_sku": "42347",
          "parameter_name": "Бренд",
          "parameter_value": "HARO"
        },
        {
          "parameter_id": "42347_Series",
          "product_sku": "42347",
          "parameter_name": "Серия",
          "parameter_value": "VICTORIA"
        }
      ]
    },
    {
      "product_sku": "042469",
      "product_categoryId": "14000121",
      "product_name": "Basic Дренажный канал, монтаж в центре комнаты, 900 мм",
      "product_mpn": "154.412.00.1",
      "manufacturer_name": "GEBERIT",
      "product_seria": "Basic",
      "product_status": "Распродажа",
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042469_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042469_1.jpg"
      ],
      "description": "Дренажный канал скрытый, серый, монтаж в центре комнаты, 900 мм. Диаметр - 50 мм. Линейной формы, жесткий отвод, с гидрозатвором.",
      parameters: [
        {
          "parameter_id": "42469_000000006",
          "product_sku": "42469",
          "parameter_name": "Диаметр (мм)",
          "parameter_value": "50"
        },
        {
          "parameter_id": "42469_000000015",
          "product_sku": "42469",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "900"
        },
        {
          "parameter_id": "42469_000000016",
          "product_sku": "42469",
          "parameter_name": "Монтаж",
          "parameter_value": "Скрытый"
        },
        {
          "parameter_id": "42469_000000017",
          "product_sku": "42469",
          "parameter_name": "Назначение",
          "parameter_value": "Внутреннее водоотведение"
        },
        {
          "parameter_id": "42469_000000018",
          "product_sku": "42469",
          "parameter_name": "Форма",
          "parameter_value": "Линейная"
        },
        {
          "parameter_id": "42469_000000021",
          "product_sku": "42469",
          "parameter_name": "Подключение к канализации",
          "parameter_value": "Жесткий отвод"
        },
        {
          "parameter_id": "42469_000000025",
          "product_sku": "42469",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Серый"
        },
        {
          "parameter_id": "42469_000000026",
          "product_sku": "42469",
          "parameter_name": "Страна производитель",
          "parameter_value": "Швейцария"
        },
        {
          "parameter_id": "42469_Brand",
          "product_sku": "42469",
          "parameter_name": "Бренд",
          "parameter_value": "GEBERIT"
        },
        {
          "parameter_id": "42469_Series",
          "product_sku": "42469",
          "parameter_name": "Серия",
          "parameter_value": "Basic"
        }
      ]
    },
    {
      "product_sku": "042492",
      "product_categoryId": "180004",
      "product_name": "NOVA PRO умывальник 55cм, прямоугольный, с отверстием (пол.)",
      "product_mpn": "M31156000",
      "manufacturer_name": "KOLO Польша",
      "product_seria": "NOVA PRO",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042492_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042492_1.jpg"
      ],
      "description": "Умывальник 55 cм, прямоугольный, с отверстием под смеситель, с переливом",
      parameters: [
        {
          "parameter_id": "42492_000000058",
          "product_sku": "42492",
          "parameter_name": "Ширина",
          "parameter_value": "550"
        },
        {
          "parameter_id": "42492_000000059",
          "product_sku": "42492",
          "parameter_name": "Глубина",
          "parameter_value": "440"
        },
        {
          "parameter_id": "42492_000000060",
          "product_sku": "42492",
          "parameter_name": "Высота",
          "parameter_value": "100"
        },
        {
          "parameter_id": "42492_000000061",
          "product_sku": "42492",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "42492_000000062",
          "product_sku": "42492",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "42492_000000063",
          "product_sku": "42492",
          "parameter_name": "Особенности формы",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "42492_000000064",
          "product_sku": "42492",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "42492_000000065",
          "product_sku": "42492",
          "parameter_name": "Комплектация",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "42492_000000066",
          "product_sku": "42492",
          "parameter_name": "Материал",
          "parameter_value": "Керамика"
        },
        {
          "parameter_id": "42492_000000067",
          "product_sku": "42492",
          "parameter_name": "Перелив",
          "parameter_value": "С переливом"
        },
        {
          "parameter_id": "42492_000000068",
          "product_sku": "42492",
          "parameter_name": "Отверстия под смеситель",
          "parameter_value": "1"
        },
        {
          "parameter_id": "42492_000000069",
          "product_sku": "42492",
          "parameter_name": "Кол-во смесителей",
          "parameter_value": "1"
        },
        {
          "parameter_id": "42492_000000070",
          "product_sku": "42492",
          "parameter_name": "Особенности",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "42492_Brand",
          "product_sku": "42492",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Польша"
        },
        {
          "parameter_id": "42492_Series",
          "product_sku": "42492",
          "parameter_name": "Серия",
          "parameter_value": "NOVA PRO"
        }
      ]
    },
    {
      "product_sku": "042513",
      "product_categoryId": "180005",
      "product_name": "NOVA PRO полупьедестал (пол)",
      "product_mpn": "M37100000",
      "manufacturer_name": "KOLO Польша",
      "product_seria": "NOVA PRO",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042513_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042513_1.jpg"
      ],
      "description": "Полупьедестал, вес 5,6 кг, подходит для комплектации с умывальниками Kolo NOVA PRO М31150, М31155, М31160, М31151, М31156",
      parameters: [
        {
          "parameter_id": "42513_000000026",
          "product_sku": "42513",
          "parameter_name": "Страна производитель",
          "parameter_value": "Польша"
        },
        {
          "parameter_id": "42513_Brand",
          "product_sku": "42513",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Польша"
        },
        {
          "parameter_id": "42513_Series",
          "product_sku": "42513",
          "parameter_name": "Серия",
          "parameter_value": "NOVA PRO"
        }
      ]
    },
    {
      "product_sku": "042522",
      "product_categoryId": "800063",
      "product_name": "NOVA PRO умывальник 55см прямоугольный, со шкафчиком для умывальника, белый глянец (пол)",
      "product_mpn": "M39005000",
      "manufacturer_name": "KOLO Польша",
      "product_seria": "NOVA PRO",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042522_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042522_1.jpg"
      ],
      "description": "NOVA PRO комплект: умывальник 55cm прямоугольный + шкафчик для умывальника, цвет белый глянец, умывальник с переливом, с отверстием под смеситель, материал шкафчика ДСП",
      parameters: [
        {
          "parameter_id": "42522_000000001",
          "product_sku": "42522",
          "parameter_name": "Ширина",
          "parameter_value": "464"
        },
        {
          "parameter_id": "42522_000000009",
          "product_sku": "42522",
          "parameter_name": "Комплектация",
          "parameter_value": "Тумба+раковина"
        },
        {
          "parameter_id": "42522_000000010",
          "product_sku": "42522",
          "parameter_name": "Тип дверей",
          "parameter_value": "Распашные"
        },
        {
          "parameter_id": "42522_000000013",
          "product_sku": "42522",
          "parameter_name": "Материал",
          "parameter_value": "ДСП"
        },
        {
          "parameter_id": "42522_000000014",
          "product_sku": "42522",
          "parameter_name": "Глубина",
          "parameter_value": "381"
        },
        {
          "parameter_id": "42522_000000015",
          "product_sku": "42522",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "557"
        },
        {
          "parameter_id": "42522_000000016",
          "product_sku": "42522",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "42522_000000018",
          "product_sku": "42522",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "42522_000000023",
          "product_sku": "42522",
          "parameter_name": "Тип установки смесителя",
          "parameter_value": "1 отверстие"
        },
        {
          "parameter_id": "42522_000000025",
          "product_sku": "42522",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Белый глянец"
        },
        {
          "parameter_id": "42522_000000026",
          "product_sku": "42522",
          "parameter_name": "Страна производитель",
          "parameter_value": "Польша"
        },
        {
          "parameter_id": "42522_000000029",
          "product_sku": "42522",
          "parameter_name": "Перелив",
          "parameter_value": "С переливом"
        },
        {
          "parameter_id": "42522_Brand",
          "product_sku": "42522",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Польша"
        },
        {
          "parameter_id": "42522_Series",
          "product_sku": "42522",
          "parameter_name": "Серия",
          "parameter_value": "NOVA PRO"
        }
      ]
    },
    {
      "product_sku": "042552",
      "product_categoryId": "400053",
      "product_name": "Eurosmart Cosmopolitan смеситель для душа, однорычажный",
      "product_mpn": "32880000",
      "manufacturer_name": "GROHE",
      "product_seria": "EUROSMART COSMOPOLITAN",
      "product_status": "Акция",
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042552_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042552_1.jpg"
      ],
      "description": "Eurosmart Cosmopolitan Смеситель для душа, однорычажныйДля скрытого монтажа, включает в себя: комплект готового монтажа, корпус встраиваемого смесителя; керамический картридж, хром, регулировка расхода воды, возможность установки мин. расхода 2,5 л/мин, металлический рычаг, уплотнитель розетки и рычага, металлическая розетка, винтовое крепление, дополнительный ограничитель температуры\nВстраиваемая часть входит в комплект.",
      parameters: [
        {
          "parameter_id": "42552_000000101",
          "product_sku": "42552",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "42552_000000102",
          "product_sku": "42552",
          "parameter_name": "Комплектация",
          "parameter_value": "Внутренняя часть"
        },
        {
          "parameter_id": "42552_000000103",
          "product_sku": "42552",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "42552_000000104",
          "product_sku": "42552",
          "parameter_name": "С полочкой",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "42552_000000105",
          "product_sku": "42552",
          "parameter_name": "Положение регулятора",
          "parameter_value": "Спереди по центру"
        },
        {
          "parameter_id": "42552_000000129",
          "product_sku": "42552",
          "parameter_name": "Монтаж",
          "parameter_value": "Скрытый"
        },
        {
          "parameter_id": "42552_000000130",
          "product_sku": "42552",
          "parameter_name": "Форма накладки",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "42552_Brand",
          "product_sku": "42552",
          "parameter_name": "Бренд",
          "parameter_value": "GROHE"
        },
        {
          "parameter_id": "42552_Series",
          "product_sku": "42552",
          "parameter_name": "Серия",
          "parameter_value": "EUROSMART COSMOPOLITAN"
        }
      ]
    },
    {
      "product_sku": "042563",
      "product_categoryId": "600066",
      "product_name": "Поддон 80*80 см, мелкий, без дуг, без ручек, без роликов",
      "product_mpn": "8120N",
      "manufacturer_name": "ELEPHANT",
      "product_seria": "",
      "product_status": "Спеццена",
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042563_0.jpg"
      ],
      "description": "Поддон мелкий, 80*80*15 см, акрил, без дуг, без ручек, без роликов",
      parameters: [
        {
          "parameter_id": "42563_000000001",
          "product_sku": "42563",
          "parameter_name": "Ширина",
          "parameter_value": "800"
        },
        {
          "parameter_id": "42563_000000011",
          "product_sku": "42563",
          "parameter_name": "Тип поддона",
          "parameter_value": "Мелкий"
        },
        {
          "parameter_id": "42563_000000013",
          "product_sku": "42563",
          "parameter_name": "Материал",
          "parameter_value": "Акрил"
        },
        {
          "parameter_id": "42563_000000014",
          "product_sku": "42563",
          "parameter_name": "Глубина",
          "parameter_value": "800"
        },
        {
          "parameter_id": "42563_000000015",
          "product_sku": "42563",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "150"
        },
        {
          "parameter_id": "42563_000000018",
          "product_sku": "42563",
          "parameter_name": "Форма",
          "parameter_value": "Угловая"
        },
        {
          "parameter_id": "42563_Brand",
          "product_sku": "42563",
          "parameter_name": "Бренд",
          "parameter_value": "ELEPHANT"
        },
        {
          "parameter_id": "42563_Series",
          "product_sku": "42563",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "042564",
      "product_categoryId": "600066",
      "product_name": "Поддон 90*90 см, мелкий, без дуг, без ручек, без роликов",
      "product_mpn": "8120N",
      "manufacturer_name": "ELEPHANT",
      "product_seria": "",
      "product_status": "Спеццена",
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042564_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042564_1.jpg"
      ],
      "description": "Поддон мелкий, 90*90*15 см, акрил, без дуг, без ручек, без роликов",
      parameters: [
        {
          "parameter_id": "42564_000000001",
          "product_sku": "42564",
          "parameter_name": "Ширина",
          "parameter_value": "900"
        },
        {
          "parameter_id": "42564_000000011",
          "product_sku": "42564",
          "parameter_name": "Тип поддона",
          "parameter_value": "Мелкий"
        },
        {
          "parameter_id": "42564_000000013",
          "product_sku": "42564",
          "parameter_name": "Материал",
          "parameter_value": "Акрил"
        },
        {
          "parameter_id": "42564_000000014",
          "product_sku": "42564",
          "parameter_name": "Глубина",
          "parameter_value": "900"
        },
        {
          "parameter_id": "42564_000000015",
          "product_sku": "42564",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "150"
        },
        {
          "parameter_id": "42564_000000018",
          "product_sku": "42564",
          "parameter_name": "Форма",
          "parameter_value": "Угловая"
        },
        {
          "parameter_id": "42564_Brand",
          "product_sku": "42564",
          "parameter_name": "Бренд",
          "parameter_value": "ELEPHANT"
        },
        {
          "parameter_id": "42564_Series",
          "product_sku": "42564",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "042584",
      "product_categoryId": "600066",
      "product_name": "Поддон SMC 80*80*3,5см квадратный",
      "product_mpn": "599-8080S",
      "manufacturer_name": "EGER",
      "product_seria": "",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042584_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042584_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042584_2.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042584_3.jpg"
      ],
      "description": "SMC расшифровывается как Sheet Molding Compound. Процесс формовки происходит под давлением 2000 тонн и температуре 160℃. Таким образом размеры, линии, углы и формы каждого поддона идеально повторяются.¶Обратная сторона поддона имеет ячеистую структуру, что придает ему дополнительную прочность.",
      parameters: [
        {
          "parameter_id": "42584_000000001",
          "product_sku": "42584",
          "parameter_name": "Ширина",
          "parameter_value": "800"
        },
        {
          "parameter_id": "42584_000000011",
          "product_sku": "42584",
          "parameter_name": "Тип поддона",
          "parameter_value": "Мелкий"
        },
        {
          "parameter_id": "42584_000000013",
          "product_sku": "42584",
          "parameter_name": "Материал",
          "parameter_value": "Композит (SMC)"
        },
        {
          "parameter_id": "42584_000000014",
          "product_sku": "42584",
          "parameter_name": "Глубина",
          "parameter_value": "800"
        },
        {
          "parameter_id": "42584_000000015",
          "product_sku": "42584",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "35"
        },
        {
          "parameter_id": "42584_000000018",
          "product_sku": "42584",
          "parameter_name": "Форма",
          "parameter_value": "Квадратная"
        },
        {
          "parameter_id": "42584_000000026",
          "product_sku": "42584",
          "parameter_name": "Страна производитель",
          "parameter_value": "Венгрия"
        },
        {
          "parameter_id": "42584_Brand",
          "product_sku": "42584",
          "parameter_name": "Бренд",
          "parameter_value": "EGER"
        },
        {
          "parameter_id": "42584_Series",
          "product_sku": "42584",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "042585",
      "product_categoryId": "600066",
      "product_name": "Поддон SMC 100*100*3,5см квадратный",
      "product_mpn": "599-1010S",
      "manufacturer_name": "EGER",
      "product_seria": "",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042585_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042585_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042585_2.jpg"
      ],
      "description": "SMC расшифровывается как Sheet Molding Compound. Процесс формовки происходит под давлением 2000 тонн и температуре 160℃. Таким образом размеры, линии, углы и формы каждого поддона идеально повторяются.¶Обратная сторона поддона имеет ячеистую структуру, что придает ему дополнительную прочность.",
      parameters: [
        {
          "parameter_id": "42585_000000001",
          "product_sku": "42585",
          "parameter_name": "Ширина",
          "parameter_value": "1 000"
        },
        {
          "parameter_id": "42585_000000011",
          "product_sku": "42585",
          "parameter_name": "Тип поддона",
          "parameter_value": "Мелкий"
        },
        {
          "parameter_id": "42585_000000013",
          "product_sku": "42585",
          "parameter_name": "Материал",
          "parameter_value": "Композит (SMC)"
        },
        {
          "parameter_id": "42585_000000014",
          "product_sku": "42585",
          "parameter_name": "Глубина",
          "parameter_value": "1 000"
        },
        {
          "parameter_id": "42585_000000015",
          "product_sku": "42585",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "35"
        },
        {
          "parameter_id": "42585_000000018",
          "product_sku": "42585",
          "parameter_name": "Форма",
          "parameter_value": "Квадратная"
        },
        {
          "parameter_id": "42585_000000026",
          "product_sku": "42585",
          "parameter_name": "Страна производитель",
          "parameter_value": "Венгрия"
        },
        {
          "parameter_id": "42585_Brand",
          "product_sku": "42585",
          "parameter_name": "Бренд",
          "parameter_value": "EGER"
        },
        {
          "parameter_id": "42585_Series",
          "product_sku": "42585",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "042588",
      "product_categoryId": "600066",
      "product_name": "Поддон SMC 80*80*3,5см полукруглый",
      "product_mpn": "599-8080R",
      "manufacturer_name": "EGER",
      "product_seria": "",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042588_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042588_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042588_2.jpg"
      ],
      "description": "SMC расшифровывается как Sheet Molding Compound. Процесс формовки происходит под давлением 2000 тонн и температуре 160℃. Таким образом размеры, линии, углы и формы каждого поддона идеально повторяются.¶Обратная сторона поддона имеет ячеистую структуру, что придает ему дополнительную прочность.",
      parameters: [
        {
          "parameter_id": "42588_000000001",
          "product_sku": "42588",
          "parameter_name": "Ширина",
          "parameter_value": "800"
        },
        {
          "parameter_id": "42588_000000011",
          "product_sku": "42588",
          "parameter_name": "Тип поддона",
          "parameter_value": "Мелкий"
        },
        {
          "parameter_id": "42588_000000013",
          "product_sku": "42588",
          "parameter_name": "Материал",
          "parameter_value": "Композит (SMC)"
        },
        {
          "parameter_id": "42588_000000014",
          "product_sku": "42588",
          "parameter_name": "Глубина",
          "parameter_value": "800"
        },
        {
          "parameter_id": "42588_000000015",
          "product_sku": "42588",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "35"
        },
        {
          "parameter_id": "42588_000000018",
          "product_sku": "42588",
          "parameter_name": "Форма",
          "parameter_value": "Угловая"
        },
        {
          "parameter_id": "42588_000000026",
          "product_sku": "42588",
          "parameter_name": "Страна производитель",
          "parameter_value": "Венгрия"
        },
        {
          "parameter_id": "42588_Brand",
          "product_sku": "42588",
          "parameter_name": "Бренд",
          "parameter_value": "EGER"
        },
        {
          "parameter_id": "42588_Series",
          "product_sku": "42588",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "042589",
      "product_categoryId": "600066",
      "product_name": "Поддон SMC 100*100*3,5см полукруглый",
      "product_mpn": "599-1010R",
      "manufacturer_name": "EGER",
      "product_seria": "",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042589_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042589_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042589_2.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042589_3.jpg"
      ],
      "description": "SMC расшифровывается как Sheet Molding Compound. Процесс формовки происходит под давлением 2000 тонн и температуре 160℃. Таким образом размеры, линии, углы и формы каждого поддона идеально повторяются.¶Обратная сторона поддона имеет ячеистую структуру, что придает ему дополнительную прочность.",
      parameters: [
        {
          "parameter_id": "42589_000000001",
          "product_sku": "42589",
          "parameter_name": "Ширина",
          "parameter_value": "1 000"
        },
        {
          "parameter_id": "42589_000000011",
          "product_sku": "42589",
          "parameter_name": "Тип поддона",
          "parameter_value": "Мелкий"
        },
        {
          "parameter_id": "42589_000000013",
          "product_sku": "42589",
          "parameter_name": "Материал",
          "parameter_value": "Композит (SMC)"
        },
        {
          "parameter_id": "42589_000000014",
          "product_sku": "42589",
          "parameter_name": "Глубина",
          "parameter_value": "1 000"
        },
        {
          "parameter_id": "42589_000000015",
          "product_sku": "42589",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "35"
        },
        {
          "parameter_id": "42589_000000018",
          "product_sku": "42589",
          "parameter_name": "Форма",
          "parameter_value": "Угловая"
        },
        {
          "parameter_id": "42589_000000026",
          "product_sku": "42589",
          "parameter_name": "Страна производитель",
          "parameter_value": "Венгрия"
        },
        {
          "parameter_id": "42589_Brand",
          "product_sku": "42589",
          "parameter_name": "Бренд",
          "parameter_value": "EGER"
        },
        {
          "parameter_id": "42589_Series",
          "product_sku": "42589",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "042590",
      "product_categoryId": "600086",
      "product_name": "Панель для поддона 599-8080S (2 части)",
      "product_mpn": "PAN-8080S",
      "manufacturer_name": "EGER",
      "product_seria": "",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042590_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042590_1.jpg"
      ],
      "description": "Панель для поддона 599-8080S (2 части)",
      parameters: [
        {
          "parameter_id": "42590_000000026",
          "product_sku": "42590",
          "parameter_name": "Страна производитель",
          "parameter_value": "Венгрия"
        },
        {
          "parameter_id": "42590_Brand",
          "product_sku": "42590",
          "parameter_name": "Бренд",
          "parameter_value": "EGER"
        },
        {
          "parameter_id": "42590_Series",
          "product_sku": "42590",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "042596",
      "product_categoryId": "600086",
      "product_name": "Панель для поддона 599-1010R",
      "product_mpn": "PAN-100R",
      "manufacturer_name": "EGER",
      "product_seria": "",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042596_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042596_1.jpg"
      ],
      "description": "Панель для поддона 599-1010R\nВысота поддона с панелью 15 см",
      parameters: [
        {
          "parameter_id": "42596_000000026",
          "product_sku": "42596",
          "parameter_name": "Страна производитель",
          "parameter_value": "Венгрия"
        },
        {
          "parameter_id": "42596_Brand",
          "product_sku": "42596",
          "parameter_name": "Бренд",
          "parameter_value": "EGER"
        },
        {
          "parameter_id": "42596_Series",
          "product_sku": "42596",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "042598",
      "product_categoryId": "600086",
      "product_name": "Сифон с выходом Ф90мм c прямым выпуском",
      "product_mpn": "599-drain-90",
      "manufacturer_name": "EGER",
      "product_seria": "",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042598_0.jpg"
      ],
      "description": "Сифон с выходом Ф90мм c прямым выпуском",
      parameters: [
        {
          "parameter_id": "42598_000000006",
          "product_sku": "42598",
          "parameter_name": "Диаметр (мм)",
          "parameter_value": "90"
        },
        {
          "parameter_id": "42598_000000013",
          "product_sku": "42598",
          "parameter_name": "Материал",
          "parameter_value": "Пластик"
        },
        {
          "parameter_id": "42598_000000018",
          "product_sku": "42598",
          "parameter_name": "Форма",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "42598_000000025",
          "product_sku": "42598",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Серый"
        },
        {
          "parameter_id": "42598_000000026",
          "product_sku": "42598",
          "parameter_name": "Страна производитель",
          "parameter_value": "Венгрия"
        },
        {
          "parameter_id": "42598_Brand",
          "product_sku": "42598",
          "parameter_name": "Бренд",
          "parameter_value": "EGER"
        },
        {
          "parameter_id": "42598_Series",
          "product_sku": "42598",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "042599",
      "product_categoryId": "600086",
      "product_name": "Сифон с выходом Ф90мм c косым выпуском",
      "product_mpn": "599-drain E",
      "manufacturer_name": "EGER",
      "product_seria": "",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042599_0.jpg"
      ],
      "description": "Сифон с выходом Ф90мм c косым выпуском, полуавтомат",
      parameters: [
        {
          "parameter_id": "42599_000000006",
          "product_sku": "42599",
          "parameter_name": "Диаметр (мм)",
          "parameter_value": "90"
        },
        {
          "parameter_id": "42599_000000013",
          "product_sku": "42599",
          "parameter_name": "Материал",
          "parameter_value": "Пластик"
        },
        {
          "parameter_id": "42599_000000018",
          "product_sku": "42599",
          "parameter_name": "Форма",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "42599_000000025",
          "product_sku": "42599",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "42599_000000026",
          "product_sku": "42599",
          "parameter_name": "Страна производитель",
          "parameter_value": "Венгрия"
        },
        {
          "parameter_id": "42599_Brand",
          "product_sku": "42599",
          "parameter_name": "Бренд",
          "parameter_value": "EGER"
        },
        {
          "parameter_id": "42599_Series",
          "product_sku": "42599",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "042614",
      "product_categoryId": "400053",
      "product_name": "DANIELLA смеситель скрытого монтажа для душа",
      "product_mpn": "15163200",
      "manufacturer_name": "VOLLE",
      "product_seria": "DANIELLA",
      "product_status": "Спеццена",
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042614_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042614_1.jpg"
      ],
      "description": "Смеситель для душа скрытого монтажа Volle Daniella 15163200\nХарактеристики:\n•\tТип управления - однорычажный\n•\tТип монтажа - встраиваемый в стену\n•\tМатериал корпуса– латунь\n•\tМатериал накладки - латунь\n•\tПокрытие - хром\n•\tКерамический картридж Sedal Ø 35 мм\nКомплектация\n•\tВнешняя часть смесителя\n•\tДекоративная латунная накладка для скрытия монтажного соединения\n•\tСкрытая часть\nДизайн изделия отвечает современным тенденциям в области интерьеров ванных комнат и основным требованиям эргономичности. Смеситель спроектирован в соответствии с концепцией ТМ Volle и потому великолепно сочетается с большинством коллекций сантехники.\nИспользование в качестве материала смесителя латуни гарантирует многолетнюю беспроблемную работу, а надёжный керамический картридж способствует удобной регулировке температуры и экономии воды. Аэратор легко снимается без использования специальных инструментов.\nГарантия: \n•\tКорпус смесителя - 5 лет\n•\tПодвижные и неметаллические комплектующие - 2 года\nВ случае использования продукции в общественной или промышленной сферах гарантийный срок составляет 6 месяцев",
      parameters: [
        {
          "parameter_id": "42614_000000101",
          "product_sku": "42614",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "42614_000000102",
          "product_sku": "42614",
          "parameter_name": "Комплектация",
          "parameter_value": "Внутренняя часть"
        },
        {
          "parameter_id": "42614_000000103",
          "product_sku": "42614",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "42614_000000104",
          "product_sku": "42614",
          "parameter_name": "С полочкой",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "42614_000000105",
          "product_sku": "42614",
          "parameter_name": "Положение регулятора",
          "parameter_value": "Спереди по центру"
        },
        {
          "parameter_id": "42614_000000129",
          "product_sku": "42614",
          "parameter_name": "Монтаж",
          "parameter_value": "Скрытый"
        },
        {
          "parameter_id": "42614_000000130",
          "product_sku": "42614",
          "parameter_name": "Форма накладки",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "42614_Brand",
          "product_sku": "42614",
          "parameter_name": "Бренд",
          "parameter_value": "VOLLE"
        },
        {
          "parameter_id": "42614_Series",
          "product_sku": "42614",
          "parameter_name": "Серия",
          "parameter_value": "DANIELLA"
        }
      ]
    },
    {
      "product_sku": "042616",
      "product_categoryId": "400072",
      "product_name": "Система душевая без смесителя (верхний и ручной душ 3 режима, шланг 1,5 м)",
      "product_mpn": "T-15084",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": "Акция",
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042616_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042616_1.jpg"
      ],
      "description": "Душевая колонна, длина: 1340 мм, диаметр трубки: 20 мм, поверхность: хром, диаметр верхнего душа 203 мм, форма: круглая, диаметр ручного душа: 84 мм, 3 функции: ливень, массаж, туман, шланг: гибкий двойной оплетки, 150 cм; без смесителя",
      parameters: [
        {
          "parameter_id": "42616_000000156",
          "product_sku": "42616",
          "parameter_name": "Ширина лейки верхнего душа, мм",
          "parameter_value": "194"
        },
        {
          "parameter_id": "42616_000000157",
          "product_sku": "42616",
          "parameter_name": "Длина лейки верхнего душа, мм",
          "parameter_value": "194"
        },
        {
          "parameter_id": "42616_000000158",
          "product_sku": "42616",
          "parameter_name": "Длина кронштейна (от стены), мм",
          "parameter_value": "404"
        },
        {
          "parameter_id": "42616_000000160",
          "product_sku": "42616",
          "parameter_name": "Мин. Высота, мм",
          "parameter_value": "1 100"
        },
        {
          "parameter_id": "42616_000000161",
          "product_sku": "42616",
          "parameter_name": "Регулируемая высота стойки",
          "parameter_value": "Да"
        },
        {
          "parameter_id": "42616_000000162",
          "product_sku": "42616",
          "parameter_name": "Форма лейки верхнего душа",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "42616_000000163",
          "product_sku": "42616",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "42616_000000164",
          "product_sku": "42616",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "42616_000000165",
          "product_sku": "42616",
          "parameter_name": "Тип управления",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "42616_000000166",
          "product_sku": "42616",
          "parameter_name": "Смеситель",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "42616_000000167",
          "product_sku": "42616",
          "parameter_name": "Кол-во режимов ручного душа",
          "parameter_value": "3"
        },
        {
          "parameter_id": "42616_000000168",
          "product_sku": "42616",
          "parameter_name": "Кол-во режимов верхнего душа",
          "parameter_value": "1"
        },
        {
          "parameter_id": "42616_Brand",
          "product_sku": "42616",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "42616_Series",
          "product_sku": "42616",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "042618",
      "product_categoryId": "",
      "product_name": "Клапан донный Pop-up, хром",
      "product_mpn": "PP280stribro",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042618_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042618_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042618_2.jpg"
      ],
      "description": "Клапан донный IMPRESE PP280stribro",
      parameters: [
        {
          "parameter_id": "42618_000000025",
          "product_sku": "42618",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "42618_000000026",
          "product_sku": "42618",
          "parameter_name": "Страна производитель",
          "parameter_value": "Чехия"
        },
        {
          "parameter_id": "42618_Brand",
          "product_sku": "42618",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "42618_Series",
          "product_sku": "42618",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "042619",
      "product_categoryId": "",
      "product_name": "Клапан донный Pop-up, бронза",
      "product_mpn": "PP280antiqua",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042619_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042619_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042619_2.jpg"
      ],
      "description": "Клапан донный Pop-up, бронза",
      parameters: [
        {
          "parameter_id": "42619_000000025",
          "product_sku": "42619",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Бронза"
        },
        {
          "parameter_id": "42619_000000026",
          "product_sku": "42619",
          "parameter_name": "Страна производитель",
          "parameter_value": "Чехия"
        },
        {
          "parameter_id": "42619_Brand",
          "product_sku": "42619",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "42619_Series",
          "product_sku": "42619",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "042621",
      "product_categoryId": "",
      "product_name": "Клапан донный Pop-up, золото",
      "product_mpn": "PP280zlato",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042621_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042621_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042621_2.jpg"
      ],
      "description": "Клапан донный Pop-up, золото",
      parameters: [
        {
          "parameter_id": "42621_000000025",
          "product_sku": "42621",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Золото"
        },
        {
          "parameter_id": "42621_000000026",
          "product_sku": "42621",
          "parameter_name": "Страна производитель",
          "parameter_value": "Чехия"
        },
        {
          "parameter_id": "42621_Brand",
          "product_sku": "42621",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "42621_Series",
          "product_sku": "42621",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "042647",
      "product_categoryId": "180001",
      "product_name": "FREJA унитаз для компакта L79200 (укр)",
      "product_mpn": "L73200000",
      "manufacturer_name": "KOLO Украина",
      "product_seria": "FREJA",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      parameters: [
        {
          "parameter_id": "42647_Brand",
          "product_sku": "42647",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Украина"
        },
        {
          "parameter_id": "42647_Series",
          "product_sku": "42647",
          "parameter_name": "Серия",
          "parameter_value": "FREJA"
        }
      ]
    },
    {
      "product_sku": "042716",
      "product_categoryId": "180004",
      "product_name": "NOVA PRO умывальник 45см прямоугольный, правое отверстие (пол.)",
      "product_mpn": "M32247000",
      "manufacturer_name": "KOLO Польша",
      "product_seria": "NOVA PRO",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042716_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042716_1.jpg"
      ],
      "description": "Умывальник 45 см прямоугольный, правое отверстие, с отверстием под смеситель, с переливом, вес 8 кг",
      parameters: [
        {
          "parameter_id": "42716_000000058",
          "product_sku": "42716",
          "parameter_name": "Ширина",
          "parameter_value": "450"
        },
        {
          "parameter_id": "42716_000000059",
          "product_sku": "42716",
          "parameter_name": "Глубина",
          "parameter_value": "250"
        },
        {
          "parameter_id": "42716_000000060",
          "product_sku": "42716",
          "parameter_name": "Высота",
          "parameter_value": "150"
        },
        {
          "parameter_id": "42716_000000061",
          "product_sku": "42716",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "42716_000000062",
          "product_sku": "42716",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "42716_000000063",
          "product_sku": "42716",
          "parameter_name": "Особенности формы",
          "parameter_value": "Правосторонняя"
        },
        {
          "parameter_id": "42716_000000064",
          "product_sku": "42716",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "42716_000000065",
          "product_sku": "42716",
          "parameter_name": "Комплектация",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "42716_000000066",
          "product_sku": "42716",
          "parameter_name": "Материал",
          "parameter_value": "Керамика"
        },
        {
          "parameter_id": "42716_000000067",
          "product_sku": "42716",
          "parameter_name": "Перелив",
          "parameter_value": "С переливом"
        },
        {
          "parameter_id": "42716_000000068",
          "product_sku": "42716",
          "parameter_name": "Отверстия под смеситель",
          "parameter_value": "1"
        },
        {
          "parameter_id": "42716_000000069",
          "product_sku": "42716",
          "parameter_name": "Кол-во смесителей",
          "parameter_value": "1"
        },
        {
          "parameter_id": "42716_000000070",
          "product_sku": "42716",
          "parameter_name": "Особенности",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "42716_Brand",
          "product_sku": "42716",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Польша"
        },
        {
          "parameter_id": "42716_Series",
          "product_sku": "42716",
          "parameter_name": "Серия",
          "parameter_value": "NOVA PRO"
        }
      ]
    },
    {
      "product_sku": "042729",
      "product_categoryId": "1800054",
      "product_name": "ORLANDO биде 52*35,5*40см напольное",
      "product_mpn": "13-35-072",
      "manufacturer_name": "VOLLE",
      "product_seria": "ORLANDO",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042729_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042729_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042729_2.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042729_3.jpg"
      ],
      "description": "Напольное биде с переливом Volle Orlando 13-35-072.\nВ комплект входят крепления к полу. \nИзделие спроектировано в соответствии с концепцией VoClean: анатомичный дизайн, плавные формы и отсутствие острых углов - всё это обеспечивает эффективную эксплуатацию и облегчает очистку. Поверхность покрывается глазурью, на которую перед обжигом наносится специальное покрытие СeraPro. Благодаря этому она становится максимально гладкой и менее подверженной загрязнению.\nМожно комплектовать смесителем Volle Orlando 15185100, Benita 15171200, Nemo 15141200\nГарантия: 25 лет\nВ случае использования продукции в общественной или промышленной сферах гарантийный срок составляет 6 месяцев",
      parameters: [
        {
          "parameter_id": "42729_000000013",
          "product_sku": "42729",
          "parameter_name": "Материал",
          "parameter_value": "Санфаянс"
        },
        {
          "parameter_id": "42729_000000014",
          "product_sku": "42729",
          "parameter_name": "Глубина",
          "parameter_value": "520"
        },
        {
          "parameter_id": "42729_000000016",
          "product_sku": "42729",
          "parameter_name": "Монтаж",
          "parameter_value": "Отдельностоящий/напольный"
        },
        {
          "parameter_id": "42729_000000018",
          "product_sku": "42729",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "42729_000000023",
          "product_sku": "42729",
          "parameter_name": "Тип установки смесителя",
          "parameter_value": "1 отверстие"
        },
        {
          "parameter_id": "42729_000000026",
          "product_sku": "42729",
          "parameter_name": "Страна производитель",
          "parameter_value": "Испания"
        },
        {
          "parameter_id": "42729_000000029",
          "product_sku": "42729",
          "parameter_name": "Перелив",
          "parameter_value": "С переливом"
        },
        {
          "parameter_id": "42729_Brand",
          "product_sku": "42729",
          "parameter_name": "Бренд",
          "parameter_value": "VOLLE"
        },
        {
          "parameter_id": "42729_Series",
          "product_sku": "42729",
          "parameter_name": "Серия",
          "parameter_value": "ORLANDO"
        }
      ]
    },
    {
      "product_sku": "042730",
      "product_categoryId": "1800054",
      "product_name": "ORLANDO биде подвесное 520*355*400мм",
      "product_mpn": "13-35-014",
      "manufacturer_name": "VOLLE",
      "product_seria": "ORLANDO",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042730_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042730_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042730_2.jpg"
      ],
      "description": "Подвесное биде с переливом Volle Orlando 13-35-014.\nВ комплект входят скрытые крепления к стене. \nИзделие спроектировано в соответствии с концепцией VoClean: анатомичный дизайн, плавные формы и отсутствие острых углов - всё это обеспечивает эффективную эксплуатацию и облегчает очистку. Поверхность покрывается глазурью, на которую перед обжигом наносится специальное покрытие СeraPro. Благодаря этому она становится максимально гладкой и менее подверженной загрязнению.\nМожно комплектовать инсталляцией Volle Master 131115 или 131050.\nТакже можно комплектовать смесителем Volle Orlando 15185100, Benita 15171200, Nemo 15141200\nГарантия: 25 лет\nВ случае использования продукции в общественной или промышленной сферах гарантийный срок составляет 6 месяцев",
      parameters: [
        {
          "parameter_id": "42730_000000013",
          "product_sku": "42730",
          "parameter_name": "Материал",
          "parameter_value": "Санфаянс"
        },
        {
          "parameter_id": "42730_000000014",
          "product_sku": "42730",
          "parameter_name": "Глубина",
          "parameter_value": "500"
        },
        {
          "parameter_id": "42730_000000016",
          "product_sku": "42730",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "42730_000000018",
          "product_sku": "42730",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "42730_000000023",
          "product_sku": "42730",
          "parameter_name": "Тип установки смесителя",
          "parameter_value": "1 отверстие"
        },
        {
          "parameter_id": "42730_000000026",
          "product_sku": "42730",
          "parameter_name": "Страна производитель",
          "parameter_value": "Испания"
        },
        {
          "parameter_id": "42730_000000029",
          "product_sku": "42730",
          "parameter_name": "Перелив",
          "parameter_value": "С переливом"
        },
        {
          "parameter_id": "42730_Brand",
          "product_sku": "42730",
          "parameter_name": "Бренд",
          "parameter_value": "VOLLE"
        },
        {
          "parameter_id": "42730_Series",
          "product_sku": "42730",
          "parameter_name": "Серия",
          "parameter_value": "ORLANDO"
        }
      ]
    },
    {
      "product_sku": "042738",
      "product_categoryId": "40003",
      "product_name": "Logis 190 Смеситель для умывальника, однорычажный",
      "product_mpn": "71090000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "LOGIS",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042738_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042738_1.jpg"
      ],
      "description": "Logis Смеситель для раковины, однорычажный Выступ 166 mm, обычная струя, расход воды: 5 л/мин, подходит для работы с проточным водонагревателем",
      parameters: [
        {
          "parameter_id": "42738_000000117",
          "product_sku": "42738",
          "parameter_name": "Длина излива",
          "parameter_value": "166"
        },
        {
          "parameter_id": "42738_000000118",
          "product_sku": "42738",
          "parameter_name": "Высота излива",
          "parameter_value": "195"
        },
        {
          "parameter_id": "42738_000000119",
          "product_sku": "42738",
          "parameter_name": "Высота смесителя",
          "parameter_value": "266"
        },
        {
          "parameter_id": "42738_000000120",
          "product_sku": "42738",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной"
        },
        {
          "parameter_id": "42738_000000121",
          "product_sku": "42738",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "42738_000000122",
          "product_sku": "42738",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "42738_000000123",
          "product_sku": "42738",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "42738_000000124",
          "product_sku": "42738",
          "parameter_name": "Наличие донного клапана",
          "parameter_value": "Да"
        },
        {
          "parameter_id": "42738_000000125",
          "product_sku": "42738",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "1"
        },
        {
          "parameter_id": "42738_Brand",
          "product_sku": "42738",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "42738_Series",
          "product_sku": "42738",
          "parameter_name": "Серия",
          "parameter_value": "LOGIS"
        }
      ]
    },
    {
      "product_sku": "042740",
      "product_categoryId": "400042",
      "product_name": "Logis Смеситель для ванны, однорычажный, скрытый монтаж",
      "product_mpn": "71405000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "LOGIS",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042740_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042740_1.jpg"
      ],
      "description": "Logis Смеситель для ванны, однорычажный\nВстраиваемая часть в комплект не входит. Необходимо комплектовать 01800180",
      parameters: [
        {
          "parameter_id": "42740_000000093",
          "product_sku": "42740",
          "parameter_name": "Длина излива",
          "parameter_value": "0"
        },
        {
          "parameter_id": "42740_000000094",
          "product_sku": "42740",
          "parameter_name": "Монтаж",
          "parameter_value": "Скрытый"
        },
        {
          "parameter_id": "42740_000000095",
          "product_sku": "42740",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "42740_000000096",
          "product_sku": "42740",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "42740_000000097",
          "product_sku": "42740",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "42740_000000098",
          "product_sku": "42740",
          "parameter_name": "Тип переключателя ванна/душ",
          "parameter_value": "Выжимной"
        },
        {
          "parameter_id": "42740_000000099",
          "product_sku": "42740",
          "parameter_name": "Повротный излив",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "42740_000000100",
          "product_sku": "42740",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "1"
        },
        {
          "parameter_id": "42740_000000126",
          "product_sku": "42740",
          "parameter_name": "Кол-во потребителей",
          "parameter_value": "2"
        },
        {
          "parameter_id": "42740_000000128",
          "product_sku": "42740",
          "parameter_name": "Форма накладки",
          "parameter_value": "Квадратная"
        },
        {
          "parameter_id": "42740_Brand",
          "product_sku": "42740",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "42740_Series",
          "product_sku": "42740",
          "parameter_name": "Серия",
          "parameter_value": "LOGIS"
        }
      ]
    },
    {
      "product_sku": "042748",
      "product_categoryId": "180004",
      "product_name": "JOYCE умывальник 80*49см",
      "product_mpn": "41078101",
      "manufacturer_name": "VILLEROY & BOCH",
      "product_seria": "JOYCE",
      "product_status": "Распродажа",
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042748_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042748_1.jpg"
      ],
      "description": "Умывальник с наличием одного отверстия под смеситель, с переливом, включает клапан с керамической крышкой",
      parameters: [
        {
          "parameter_id": "42748_000000001",
          "product_sku": "42748",
          "parameter_name": "Ширина",
          "parameter_value": "800"
        },
        {
          "parameter_id": "42748_000000013",
          "product_sku": "42748",
          "parameter_name": "Материал",
          "parameter_value": "Санфаянс"
        },
        {
          "parameter_id": "42748_000000014",
          "product_sku": "42748",
          "parameter_name": "Глубина",
          "parameter_value": "490"
        },
        {
          "parameter_id": "42748_000000016",
          "product_sku": "42748",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "42748_000000018",
          "product_sku": "42748",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "42748_000000023",
          "product_sku": "42748",
          "parameter_name": "Тип установки смесителя",
          "parameter_value": "1 отверстие"
        },
        {
          "parameter_id": "42748_000000026",
          "product_sku": "42748",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "42748_000000029",
          "product_sku": "42748",
          "parameter_name": "Перелив",
          "parameter_value": "С переливом"
        },
        {
          "parameter_id": "42748_Brand",
          "product_sku": "42748",
          "parameter_name": "Бренд",
          "parameter_value": "VILLEROY & BOCH"
        },
        {
          "parameter_id": "42748_Series",
          "product_sku": "42748",
          "parameter_name": "Серия",
          "parameter_value": "JOYCE"
        }
      ]
    },
    {
      "product_sku": "042810",
      "product_categoryId": "800063",
      "product_name": "NOVA PRO умывальник 36см прямоугольный, со шкафчиком для умывальника, белый глянец (пол)",
      "product_mpn": "M39001000",
      "manufacturer_name": "KOLO Польша",
      "product_seria": "NOVA PRO",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042810_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042810_1.jpg"
      ],
      "description": "NOVA PRO комплект: умывальник 36cm прямоугольный + шкафчик для умывальника, цвет белый глянец, умывальник с переливом и отверстием под смеситель, материал шкафчика ДСП, 360х280х649 мм",
      parameters: [
        {
          "parameter_id": "42810_000000001",
          "product_sku": "42810",
          "parameter_name": "Ширина",
          "parameter_value": "360"
        },
        {
          "parameter_id": "42810_000000009",
          "product_sku": "42810",
          "parameter_name": "Комплектация",
          "parameter_value": "Тумба+раковина"
        },
        {
          "parameter_id": "42810_000000010",
          "product_sku": "42810",
          "parameter_name": "Тип дверей",
          "parameter_value": "Распашные"
        },
        {
          "parameter_id": "42810_000000013",
          "product_sku": "42810",
          "parameter_name": "Материал",
          "parameter_value": "ДСП"
        },
        {
          "parameter_id": "42810_000000014",
          "product_sku": "42810",
          "parameter_name": "Глубина",
          "parameter_value": "280"
        },
        {
          "parameter_id": "42810_000000015",
          "product_sku": "42810",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "649"
        },
        {
          "parameter_id": "42810_000000016",
          "product_sku": "42810",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "42810_000000018",
          "product_sku": "42810",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "42810_000000023",
          "product_sku": "42810",
          "parameter_name": "Тип установки смесителя",
          "parameter_value": "1 отверстие"
        },
        {
          "parameter_id": "42810_000000025",
          "product_sku": "42810",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Белый глянец"
        },
        {
          "parameter_id": "42810_000000026",
          "product_sku": "42810",
          "parameter_name": "Страна производитель",
          "parameter_value": "Польша"
        },
        {
          "parameter_id": "42810_000000029",
          "product_sku": "42810",
          "parameter_name": "Перелив",
          "parameter_value": "С переливом"
        },
        {
          "parameter_id": "42810_Brand",
          "product_sku": "42810",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Польша"
        },
        {
          "parameter_id": "42810_Series",
          "product_sku": "42810",
          "parameter_name": "Серия",
          "parameter_value": "NOVA PRO"
        }
      ]
    },
    {
      "product_sku": "042814",
      "product_categoryId": "800063",
      "product_name": "NOVA PRO умывальник 45см прямоугольный, левое отверстие, со шкафчиком для умывальника, белый глянец (пол)",
      "product_mpn": "M39002000",
      "manufacturer_name": "KOLO Польша",
      "product_seria": "NOVA PRO",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042814_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042814_1.jpg"
      ],
      "description": "NOVA PRO комплект: умывальник 45cm прямоугольный, левое отверстие + шкафчик для умывальника, цвет белый глянец, умывальник с переливом и отверстием под смеситель, материал шкафчика ДСП, 450х250х649 мм",
      parameters: [
        {
          "parameter_id": "42814_000000001",
          "product_sku": "42814",
          "parameter_name": "Ширина",
          "parameter_value": "450"
        },
        {
          "parameter_id": "42814_000000009",
          "product_sku": "42814",
          "parameter_name": "Комплектация",
          "parameter_value": "Тумба+раковина"
        },
        {
          "parameter_id": "42814_000000010",
          "product_sku": "42814",
          "parameter_name": "Тип дверей",
          "parameter_value": "Распашные"
        },
        {
          "parameter_id": "42814_000000013",
          "product_sku": "42814",
          "parameter_name": "Материал",
          "parameter_value": "ДСП"
        },
        {
          "parameter_id": "42814_000000014",
          "product_sku": "42814",
          "parameter_name": "Глубина",
          "parameter_value": "250"
        },
        {
          "parameter_id": "42814_000000015",
          "product_sku": "42814",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "649"
        },
        {
          "parameter_id": "42814_000000016",
          "product_sku": "42814",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "42814_000000018",
          "product_sku": "42814",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "42814_000000023",
          "product_sku": "42814",
          "parameter_name": "Тип установки смесителя",
          "parameter_value": "1 отверстие"
        },
        {
          "parameter_id": "42814_000000025",
          "product_sku": "42814",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Белый глянец"
        },
        {
          "parameter_id": "42814_000000026",
          "product_sku": "42814",
          "parameter_name": "Страна производитель",
          "parameter_value": "Польша"
        },
        {
          "parameter_id": "42814_000000029",
          "product_sku": "42814",
          "parameter_name": "Перелив",
          "parameter_value": "С переливом"
        },
        {
          "parameter_id": "42814_Brand",
          "product_sku": "42814",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Польша"
        },
        {
          "parameter_id": "42814_Series",
          "product_sku": "42814",
          "parameter_name": "Серия",
          "parameter_value": "NOVA PRO"
        }
      ]
    },
    {
      "product_sku": "042840",
      "product_categoryId": "600059",
      "product_name": "REKORD душевая кабина 90см, квадратная",
      "product_mpn": "PKDK90222003",
      "manufacturer_name": "KOLO Польша",
      "product_seria": "REKORD",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042840_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042840_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042840_2.jpg"
      ],
      "description": "Квадратная душевая кабина, двери раздвижные, размеры 90*185 см. \nПрозрачное стекло, цвет профиля: хром. \nШирина входа: 500 мм.\nТолщина стекла : двери, неподвижная часть – 4мм",
      parameters: [
        {
          "parameter_id": "42840_000000012",
          "product_sku": "42840",
          "parameter_name": "Цвет профиля",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "42840_000000131",
          "product_sku": "42840",
          "parameter_name": "Длина",
          "parameter_value": "900"
        },
        {
          "parameter_id": "42840_000000132",
          "product_sku": "42840",
          "parameter_name": "Ширина",
          "parameter_value": "900"
        },
        {
          "parameter_id": "42840_000000133",
          "product_sku": "42840",
          "parameter_name": "Высота",
          "parameter_value": "1 850"
        },
        {
          "parameter_id": "42840_000000135",
          "product_sku": "42840",
          "parameter_name": "Тип двери",
          "parameter_value": "Раздвижная"
        },
        {
          "parameter_id": "42840_000000136",
          "product_sku": "42840",
          "parameter_name": "Форма кабины",
          "parameter_value": "Квадратная"
        },
        {
          "parameter_id": "42840_000000137",
          "product_sku": "42840",
          "parameter_name": "Расположение",
          "parameter_value": "универсальное"
        },
        {
          "parameter_id": "42840_000000138",
          "product_sku": "42840",
          "parameter_name": "Цвет стекла",
          "parameter_value": "Прозрачный"
        },
        {
          "parameter_id": "42840_000000139",
          "product_sku": "42840",
          "parameter_name": "Высота поддона",
          "parameter_value": "Мелкий"
        },
        {
          "parameter_id": "42840_000000140",
          "product_sku": "42840",
          "parameter_name": "Наличие поддона",
          "parameter_value": "Без поддона"
        },
        {
          "parameter_id": "42840_000000141",
          "product_sku": "42840",
          "parameter_name": "Толщина стекла",
          "parameter_value": "4 мм"
        },
        {
          "parameter_id": "42840_000000181",
          "product_sku": "42840",
          "parameter_name": "Наличие сифона",
          "parameter_value": "Без сифона"
        },
        {
          "parameter_id": "42840_Brand",
          "product_sku": "42840",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Польша"
        },
        {
          "parameter_id": "42840_Series",
          "product_sku": "42840",
          "parameter_name": "Серия",
          "parameter_value": "REKORD"
        }
      ]
    },
    {
      "product_sku": "042873",
      "product_categoryId": "400070",
      "product_name": "Axor Lamp Shower Душ верхний с лампой (шлифованный никель)",
      "product_mpn": "26031000 (brushed nickel)",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "Axor Lamp Shower",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_042873_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_042873_1.jpg"
      ],
      "description": "Axor Lamp Shower Душ верхний с лампой (шлифованный никель)Размер душевого диска: 275 mm, тип струи: Rain, расход воды при режиме Rain: 13 л/мин, поверхность душевого диска: хром, длина  держателя для душа: 380 mm, материал душевого диска: металл, душевой диск может сниматься для очистки, монтаж стена, со встроенным освещением",
      parameters: [
        {
          "parameter_id": "42873_Brand",
          "product_sku": "42873",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "42873_Series",
          "product_sku": "42873",
          "parameter_name": "Серия",
          "parameter_value": "Axor Lamp Shower"
        }
      ]
    },
    {
      "product_sku": "043014",
      "product_categoryId": "",
      "product_name": "Шторка на ванну 120*138см, профиль белый",
      "product_mpn": "599-121W",
      "manufacturer_name": "EGER",
      "product_seria": "",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_043014_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_043014_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_043014_2.jpg"
      ],
      "description": "Шторка на ванну 120*138 см, цвет профиля белый",
      parameters: [
        {
          "parameter_id": "43014_000000001",
          "product_sku": "43014",
          "parameter_name": "Ширина",
          "parameter_value": "1 200"
        },
        {
          "parameter_id": "43014_000000010",
          "product_sku": "43014",
          "parameter_name": "Тип дверей",
          "parameter_value": "Распашные"
        },
        {
          "parameter_id": "43014_000000012",
          "product_sku": "43014",
          "parameter_name": "Цвет профиля",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "43014_000000013",
          "product_sku": "43014",
          "parameter_name": "Материал",
          "parameter_value": "Стекло"
        },
        {
          "parameter_id": "43014_000000015",
          "product_sku": "43014",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "1 380"
        },
        {
          "parameter_id": "43014_000000018",
          "product_sku": "43014",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "43014_000000025",
          "product_sku": "43014",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Прозрачный"
        },
        {
          "parameter_id": "43014_000000026",
          "product_sku": "43014",
          "parameter_name": "Страна производитель",
          "parameter_value": "Венгрия"
        },
        {
          "parameter_id": "43014_Brand",
          "product_sku": "43014",
          "parameter_name": "Бренд",
          "parameter_value": "EGER"
        },
        {
          "parameter_id": "43014_Series",
          "product_sku": "43014",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "043034",
      "product_categoryId": "11000111",
      "product_name": "Axor Carlton Термостат с запорным вентилем (цв. Белый)",
      "product_mpn": "17700000 (weiss)",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "AXOR CARLTON",
      "product_status": "Распродажа",
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_043034_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_043034_1.jpg"
      ],
      "description": "Axor Carlton Термостат с запорным вентилем Предохранительный стопор при 38°C, расход воды: 26 л/мин",
      parameters: [
        {
          "parameter_id": "43034_000000016",
          "product_sku": "43034",
          "parameter_name": "Монтаж",
          "parameter_value": "Встраиваемый в стену"
        },
        {
          "parameter_id": "43034_000000022",
          "product_sku": "43034",
          "parameter_name": "Тип управления",
          "parameter_value": "Термостат"
        },
        {
          "parameter_id": "43034_000000025",
          "product_sku": "43034",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "43034_000000026",
          "product_sku": "43034",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "43034_Brand",
          "product_sku": "43034",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "43034_Series",
          "product_sku": "43034",
          "parameter_name": "Серия",
          "parameter_value": "AXOR CARLTON"
        }
      ]
    },
    {
      "product_sku": "043109",
      "product_categoryId": "500095",
      "product_name": "UNI4 панель фронтальная универсальная к прямоугольным ваннам 160 см, в комплекте с элементами крепления",
      "product_mpn": "PWP4460000",
      "manufacturer_name": "KOLO Украина",
      "product_seria": "UNI4",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_043109_0.jpg"
      ],
      "description": "Панель фронтальная для прямоугольных ванн Коло-Дымер, 160 см, с элементами крепления",
      parameters: [
        {
          "parameter_id": "43109_000000026",
          "product_sku": "43109",
          "parameter_name": "Страна производитель",
          "parameter_value": "Украина"
        },
        {
          "parameter_id": "43109_Brand",
          "product_sku": "43109",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Украина"
        },
        {
          "parameter_id": "43109_Series",
          "product_sku": "43109",
          "parameter_name": "Серия",
          "parameter_value": "UNI4"
        }
      ]
    },
    {
      "product_sku": "043115",
      "product_categoryId": "10000123",
      "product_name": "ADVANTIX VARIO соединительный элемент прямой",
      "product_mpn": "708917",
      "manufacturer_name": "VIEGA",
      "product_seria": "Advantix Vario",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_043115_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_043115_1.jpg"
      ],
      "description": "Соединительный элемент, для соединения двух душевых лотков, высококачественный пластик, комплектация: разделительное уплотнение, аксессуары для монтажа",
      parameters: [
        {
          "parameter_id": "43115_000000026",
          "product_sku": "43115",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "43115_Brand",
          "product_sku": "43115",
          "parameter_name": "Бренд",
          "parameter_value": "VIEGA"
        },
        {
          "parameter_id": "43115_Series",
          "product_sku": "43115",
          "parameter_name": "Серия",
          "parameter_value": "Advantix Vario"
        }
      ]
    },
    {
      "product_sku": "043120",
      "product_categoryId": "4000113",
      "product_name": "Logis Скрытая часть на три отверстия для установки смесителя на край ванны",
      "product_mpn": "13439180",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "LOGIS",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_043120_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_043120_1.jpg"
      ],
      "description": "комплект поставки: скрытая часть, керамический картридж, держатель для душа на край ванны; необходимо сервисное отверстие",
      parameters: [
        {
          "parameter_id": "43120_000000016",
          "product_sku": "43120",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной в ванну"
        },
        {
          "parameter_id": "43120_000000026",
          "product_sku": "43120",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "43120_Brand",
          "product_sku": "43120",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "43120_Series",
          "product_sku": "43120",
          "parameter_name": "Серия",
          "parameter_value": "LOGIS"
        }
      ]
    },
    {
      "product_sku": "043128",
      "product_categoryId": "",
      "product_name": "NOVA PRO  панель боковая для умывальника 50cm, белый глянец (пол)",
      "product_mpn": "88447000",
      "manufacturer_name": "KOLO Польша",
      "product_seria": "NOVA PRO",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_043128_0.jpg"
      ],
      "description": "Боковая панель для умывальника 50 см, цвет : белый",
      parameters: [
        {
          "parameter_id": "43128_000000026",
          "product_sku": "43128",
          "parameter_name": "Страна производитель",
          "parameter_value": "Польша"
        },
        {
          "parameter_id": "43128_Brand",
          "product_sku": "43128",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Польша"
        },
        {
          "parameter_id": "43128_Series",
          "product_sku": "43128",
          "parameter_name": "Серия",
          "parameter_value": "NOVA PRO"
        }
      ]
    },
    {
      "product_sku": "043129",
      "product_categoryId": "",
      "product_name": "NOVA PRO  панель боковая для умывальника 55cm, белый глянец (пол)",
      "product_mpn": "88448000",
      "manufacturer_name": "KOLO Польша",
      "product_seria": "NOVA PRO",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_043129_0.jpg"
      ],
      "description": "Боковая панель для умывальника 55 см, цвет : белый",
      parameters: [
        {
          "parameter_id": "43129_000000026",
          "product_sku": "43129",
          "parameter_name": "Страна производитель",
          "parameter_value": "Польша"
        },
        {
          "parameter_id": "43129_Brand",
          "product_sku": "43129",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Польша"
        },
        {
          "parameter_id": "43129_Series",
          "product_sku": "43129",
          "parameter_name": "Серия",
          "parameter_value": "NOVA PRO"
        }
      ]
    },
    {
      "product_sku": "043131",
      "product_categoryId": "900089",
      "product_name": "NOVA PRO вешалка для полотенца (пол)",
      "product_mpn": "99427000",
      "manufacturer_name": "KOLO Польша",
      "product_seria": "NOVA PRO",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_043131_0.jpg"
      ],
      "description": "Вешалка для полотенца, стальная",
      parameters: [
        {
          "parameter_id": "43131_000000013",
          "product_sku": "43131",
          "parameter_name": "Материал",
          "parameter_value": "Сталь"
        },
        {
          "parameter_id": "43131_000000016",
          "product_sku": "43131",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "43131_000000025",
          "product_sku": "43131",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "43131_000000026",
          "product_sku": "43131",
          "parameter_name": "Страна производитель",
          "parameter_value": "Польша"
        },
        {
          "parameter_id": "43131_Brand",
          "product_sku": "43131",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Польша"
        },
        {
          "parameter_id": "43131_Series",
          "product_sku": "43131",
          "parameter_name": "Серия",
          "parameter_value": "NOVA PRO"
        }
      ]
    },
    {
      "product_sku": "043135",
      "product_categoryId": "",
      "product_name": "NOVA PRO ножки для мебели (пол)",
      "product_mpn": "99439-000",
      "manufacturer_name": "KOLO Польша",
      "product_seria": "NOVA PRO",
      "product_status": "Распродажа",
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_043135_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_043135_1.jpg"
      ],
      "description": "Ножки для мебели, металл",
      parameters: [
        {
          "parameter_id": "43135_000000013",
          "product_sku": "43135",
          "parameter_name": "Материал",
          "parameter_value": "Металл"
        },
        {
          "parameter_id": "43135_000000026",
          "product_sku": "43135",
          "parameter_name": "Страна производитель",
          "parameter_value": "Польша"
        },
        {
          "parameter_id": "43135_Brand",
          "product_sku": "43135",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Польша"
        },
        {
          "parameter_id": "43135_Series",
          "product_sku": "43135",
          "parameter_name": "Серия",
          "parameter_value": "NOVA PRO"
        }
      ]
    },
    {
      "product_sku": "043152",
      "product_categoryId": "400070",
      "product_name": "Axor Lamp Shower Душ верхний с лампой (цв.белый)",
      "product_mpn": "26031000 (weiss)",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "Axor Lamp Shower",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_043152_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_043152_1.jpg"
      ],
      "description": "Axor Lamp Shower Душ верхний с лампой (цв.белый)Размер душевого диска: 275 mm, тип струи: Rain, расход воды при режиме Rain: 13 л/мин, поверхность душевого диска: хром, длина  держателя для душа: 380 mm, материал душевого диска: металл, душевой диск может сниматься для очистки, монтаж стена, со встроенным освещением",
      parameters: [
        {
          "parameter_id": "43152_Brand",
          "product_sku": "43152",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "43152_Series",
          "product_sku": "43152",
          "parameter_name": "Серия",
          "parameter_value": "Axor Lamp Shower"
        }
      ]
    },
    {
      "product_sku": "043168",
      "product_categoryId": "",
      "product_name": "GEBERIT декоративная накладка для душевого элемента, комплект, пластик, хром глянц",
      "product_mpn": "154.335.21.1",
      "manufacturer_name": "GEBERIT",
      "product_seria": "GEBERIT",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_043168_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_043168_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_043168_2.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_043168_3.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_043168_4.jpg"
      ],
      "description": "Декоративная накладка для душевого элемента, комплект, пластик, хром глянцевый",
      parameters: [
        {
          "parameter_id": "43168_000000026",
          "product_sku": "43168",
          "parameter_name": "Страна производитель",
          "parameter_value": "Швейцария"
        },
        {
          "parameter_id": "43168_Brand",
          "product_sku": "43168",
          "parameter_name": "Бренд",
          "parameter_value": "GEBERIT"
        },
        {
          "parameter_id": "43168_Series",
          "product_sku": "43168",
          "parameter_name": "Серия",
          "parameter_value": "GEBERIT"
        }
      ]
    },
    {
      "product_sku": "043177",
      "product_categoryId": "18000102",
      "product_name": "SOLO сидение с крышкой для унитаза полипропилен с металлическими креплениями (укр)",
      "product_mpn": "70117",
      "manufacturer_name": "KOLO Украина",
      "product_seria": "SOLO",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_043177_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_043177_1.jpg"
      ],
      "description": "Cидение с крышкой для унитаза полипропилен с металлическими креплениями",
      parameters: [
        {
          "parameter_id": "43177_000000018",
          "product_sku": "43177",
          "parameter_name": "Форма",
          "parameter_value": "Округлая"
        },
        {
          "parameter_id": "43177_000000026",
          "product_sku": "43177",
          "parameter_name": "Страна производитель",
          "parameter_value": "Польша"
        },
        {
          "parameter_id": "43177_000000027",
          "product_sku": "43177",
          "parameter_name": "Тип сидения",
          "parameter_value": "Полипропилен"
        },
        {
          "parameter_id": "43177_Brand",
          "product_sku": "43177",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Украина"
        },
        {
          "parameter_id": "43177_Series",
          "product_sku": "43177",
          "parameter_name": "Серия",
          "parameter_value": "SOLO"
        }
      ]
    },
    {
      "product_sku": "043179",
      "product_categoryId": "180001",
      "product_name": "NOVA PRO унитаз напольный Rimfree с горизонтальным выпуском",
      "product_mpn": "M33220000",
      "manufacturer_name": "KOLO Польша",
      "product_seria": "NOVA PRO",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_043179_0.jpg"
      ],
      "description": "Унитаз напольный Rimfree с горизонтальным выпуском",
      parameters: [
        {
          "parameter_id": "43179_Brand",
          "product_sku": "43179",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Польша"
        },
        {
          "parameter_id": "43179_Series",
          "product_sku": "43179",
          "parameter_name": "Серия",
          "parameter_value": "NOVA PRO"
        }
      ]
    },
    {
      "product_sku": "043181",
      "product_categoryId": "18000102",
      "product_name": "NOVA PRO сиденье с крышкой твердое, овальное, из материала Duroplast, с микролифтом (пол.)",
      "product_mpn": "M30112000",
      "manufacturer_name": "KOLO Польша",
      "product_seria": "NOVA PRO",
      "product_status": "Акция",
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_043181_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_043181_1.jpg"
      ],
      "description": "Сиденье с крышкой твердое, из материала Duroplast Soft Close (медленное закрывание), металлические петли",
      parameters: [
        {
          "parameter_id": "43181_000000018",
          "product_sku": "43181",
          "parameter_name": "Форма",
          "parameter_value": "Округлая"
        },
        {
          "parameter_id": "43181_000000026",
          "product_sku": "43181",
          "parameter_name": "Страна производитель",
          "parameter_value": "Польша"
        },
        {
          "parameter_id": "43181_000000027",
          "product_sku": "43181",
          "parameter_name": "Тип сидения",
          "parameter_value": "Дюропласт"
        },
        {
          "parameter_id": "43181_Brand",
          "product_sku": "43181",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Польша"
        },
        {
          "parameter_id": "43181_Series",
          "product_sku": "43181",
          "parameter_name": "Серия",
          "parameter_value": "NOVA PRO"
        }
      ]
    },
    {
      "product_sku": "043211",
      "product_categoryId": "",
      "product_name": "LAUFEN PRO ножки хром",
      "product_mpn": "H4830910950041",
      "manufacturer_name": "LAUFEN",
      "product_seria": "PRO",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_043211_0.jpg"
      ],
      "description": "Ножки металлические, хром",
      parameters: [
        {
          "parameter_id": "43211_000000013",
          "product_sku": "43211",
          "parameter_name": "Материал",
          "parameter_value": "Металл"
        },
        {
          "parameter_id": "43211_000000026",
          "product_sku": "43211",
          "parameter_name": "Страна производитель",
          "parameter_value": "Швейцария"
        },
        {
          "parameter_id": "43211_Brand",
          "product_sku": "43211",
          "parameter_name": "Бренд",
          "parameter_value": "LAUFEN"
        },
        {
          "parameter_id": "43211_Series",
          "product_sku": "43211",
          "parameter_name": "Серия",
          "parameter_value": "PRO"
        }
      ]
    },
    {
      "product_sku": "043214",
      "product_categoryId": "400071",
      "product_name": "Axor Uno2 Душевой набор 1,60м",
      "product_mpn": "27987000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "AXOR UNO2",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_043214_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_043214_1.jpg"
      ],
      "description": "Axor Uno2 Душевой набор 1,60м Размер душевого диска: 120 mm, тип струи: RainAir (дождевая струя с подмешиванием воздуха), Rain, WhirlAir, комфортное переключение типа струи при помощи кнопки выбора, настенная штанга 0,9 м, максимальный расход воды: 16 л/мин",
      parameters: [
        {
          "parameter_id": "43214_Brand",
          "product_sku": "43214",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "43214_Series",
          "product_sku": "43214",
          "parameter_name": "Серия",
          "parameter_value": "AXOR UNO2"
        }
      ]
    },
    {
      "product_sku": "043217",
      "product_categoryId": "14000121",
      "product_name": "Комплект: ADVANTIX  VARIO лоток + дизайн-вставка Visign SR2 глянцевая",
      "product_mpn": "704360",
      "manufacturer_name": "VIEGA",
      "product_seria": "496521",
      "product_status": "Спеццена",
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_043217_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_043217_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_043217_2.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_043217_3.jpg"
      ],
      "description": "Комплект: лоток Advantix Vario, дизайн-вставка Visign SR2 глянцевая; для монтажа с использованием обмазочной гидроизоляции (душевые поддоны в строительном исполнении), герметизация примыкающих поверхностей лотка к строительным конструкциям осуществляется при помощи герметика и гидроизоляционного полотна; высококачественный пластик, комплектация: монтажные опоры, концевые заглушки, самоочищающаяся конструкция сифона, регулируемое по высоте крепление для дизайн-вставки, компенсатор высоты, фронтальная поверхность для нанесения/закрепления гидроизоляции, набор уплотнений, шаблон для обрезания",
      parameters: [
        {
          "parameter_id": "43217_000000006",
          "product_sku": "43217",
          "parameter_name": "Диаметр (мм)",
          "parameter_value": "95"
        },
        {
          "parameter_id": "43217_000000015",
          "product_sku": "43217",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "1 200"
        },
        {
          "parameter_id": "43217_000000016",
          "product_sku": "43217",
          "parameter_name": "Монтаж",
          "parameter_value": "Скрытый"
        },
        {
          "parameter_id": "43217_000000017",
          "product_sku": "43217",
          "parameter_name": "Назначение",
          "parameter_value": "Внутреннее водоотведение"
        },
        {
          "parameter_id": "43217_000000018",
          "product_sku": "43217",
          "parameter_name": "Форма",
          "parameter_value": "Линейная"
        },
        {
          "parameter_id": "43217_000000021",
          "product_sku": "43217",
          "parameter_name": "Подключение к канализации",
          "parameter_value": "Шарнирный отвод"
        },
        {
          "parameter_id": "43217_000000025",
          "product_sku": "43217",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Черный"
        },
        {
          "parameter_id": "43217_000000026",
          "product_sku": "43217",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "43217_Brand",
          "product_sku": "43217",
          "parameter_name": "Бренд",
          "parameter_value": "VIEGA"
        },
        {
          "parameter_id": "43217_Series",
          "product_sku": "43217",
          "parameter_name": "Серия",
          "parameter_value": "496521"
        }
      ]
    },
    {
      "product_sku": "043228",
      "product_categoryId": "500040",
      "product_name": "MODO ванна 170*75см прямоугольная, боковой слив, с ножками SN7",
      "product_mpn": "XWP1170000",
      "manufacturer_name": "KOLO Польша",
      "product_seria": "MODO",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_043228_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_043228_1.jpg"
      ],
      "description": "Ванна прямоугольная, 1700*750*450 мм, пристенная, акриловая.",
      parameters: [
        {
          "parameter_id": "43228_000000071",
          "product_sku": "43228",
          "parameter_name": "Длина",
          "parameter_value": "1 700"
        },
        {
          "parameter_id": "43228_000000072",
          "product_sku": "43228",
          "parameter_name": "Ширина",
          "parameter_value": "750"
        },
        {
          "parameter_id": "43228_000000073",
          "product_sku": "43228",
          "parameter_name": "Высота",
          "parameter_value": "450"
        },
        {
          "parameter_id": "43228_000000074",
          "product_sku": "43228",
          "parameter_name": "Материал",
          "parameter_value": "Акрил"
        },
        {
          "parameter_id": "43228_000000075",
          "product_sku": "43228",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "43228_000000076",
          "product_sku": "43228",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "43228_000000077",
          "product_sku": "43228",
          "parameter_name": "Ориентация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "43228_000000078",
          "product_sku": "43228",
          "parameter_name": "Монтаж",
          "parameter_value": "Пристенный"
        },
        {
          "parameter_id": "43228_000000079",
          "product_sku": "43228",
          "parameter_name": "Особенности",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "43228_000000080",
          "product_sku": "43228",
          "parameter_name": "Опора",
          "parameter_value": "Ножки"
        },
        {
          "parameter_id": "43228_000000081",
          "product_sku": "43228",
          "parameter_name": "Панель",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "43228_000000082",
          "product_sku": "43228",
          "parameter_name": "Сифон",
          "parameter_value": "Есть"
        },
        {
          "parameter_id": "43228_000000083",
          "product_sku": "43228",
          "parameter_name": "Смеситель",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "43228_000000084",
          "product_sku": "43228",
          "parameter_name": "Гидромассаж",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "43228_000000085",
          "product_sku": "43228",
          "parameter_name": "Тип управления",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "43228_000000182",
          "product_sku": "43228",
          "parameter_name": "Тип поверхности",
          "parameter_value": "Глянцевая"
        },
        {
          "parameter_id": "43228_Brand",
          "product_sku": "43228",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Польша"
        },
        {
          "parameter_id": "43228_Series",
          "product_sku": "43228",
          "parameter_name": "Серия",
          "parameter_value": "MODO"
        }
      ]
    },
    {
      "product_sku": "044227",
      "product_categoryId": "500082",
      "product_name": "SWING комплект ножек для ванны",
      "product_mpn": "A291030000",
      "manufacturer_name": "ROCA",
      "product_seria": "SWING",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "36.21",
      "product_currency": "EUR",
      "product_price_online": "1068",
      "sourcePrice": "25.35",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_044227_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_044227_1.jpg"
      ],
      "description": "Комплект ножек",
      parameters: [
        {
          "parameter_id": "44227_000000026",
          "product_sku": "44227",
          "parameter_name": "Страна производитель",
          "parameter_value": "Испания"
        },
        {
          "parameter_id": "44227_Brand",
          "product_sku": "44227",
          "parameter_name": "Бренд",
          "parameter_value": "ROCA"
        },
        {
          "parameter_id": "44227_Series",
          "product_sku": "44227",
          "parameter_name": "Серия",
          "parameter_value": "SWING"
        }
      ]
    },
    {
      "product_sku": "044236",
      "product_categoryId": "200043",
      "product_name": "Комплект: PRO инсталляция для унитаза + клавиша смыва",
      "product_mpn": "A890090020+A890096001",
      "manufacturer_name": "ROCA",
      "product_seria": "PRO",
      "product_status": "Спеццена",
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "209.71",
      "product_currency": "EUR",
      "product_price_online": "6186",
      "sourcePrice": "157.28",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_044236_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_044236_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_044236_2.jpg"
      ],
      "description": "Инсталляционная система для подвесного унитаза. В комплект входит: инсталляция для унитаза с бачком двойного смыва, кнопка спуска хромированная, крепление. Минимальное расстояние крепления от стены 140 мм. Рама покрыта специальным составом от коррозии, регулируется по высоте",
      parameters: [
        {
          "parameter_id": "44236_000000009",
          "product_sku": "44236",
          "parameter_name": "Комплектация",
          "parameter_value": "Инсталляция+крепление+клавиша"
        },
        {
          "parameter_id": "44236_000000026",
          "product_sku": "44236",
          "parameter_name": "Страна производитель",
          "parameter_value": "Испания"
        },
        {
          "parameter_id": "44236_Brand",
          "product_sku": "44236",
          "parameter_name": "Бренд",
          "parameter_value": "ROCA"
        },
        {
          "parameter_id": "44236_Series",
          "product_sku": "44236",
          "parameter_name": "Серия",
          "parameter_value": "PRO"
        }
      ]
    },
    {
      "product_sku": "044250",
      "product_categoryId": "1400065",
      "product_name": "ALESSI DOT сифон гибкий",
      "product_mpn": "H8949750000001",
      "manufacturer_name": "LAUFEN",
      "product_seria": "ALESSI DOT",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 31
      },
      "exchangeRate_product_price_online": {
        "EUR": 31
      },
      "product_price": "19.76",
      "product_currency": "EUR",
      "product_price_online": "613",
      "sourcePrice": "13.83",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_044250_0.jpg"
      ],
      "description": "ALESSI DOT сифон гибкий для умывальника",
      parameters: [
        {
          "parameter_id": "44250_000000003",
          "product_sku": "44250",
          "parameter_name": "Диаметр (дюймы)",
          "parameter_value": "11,4"
        },
        {
          "parameter_id": "44250_000000007",
          "product_sku": "44250",
          "parameter_name": "Диаметр 2 (мм)",
          "parameter_value": "40"
        },
        {
          "parameter_id": "44250_000000013",
          "product_sku": "44250",
          "parameter_name": "Материал",
          "parameter_value": "Пластик"
        },
        {
          "parameter_id": "44250_000000015",
          "product_sku": "44250",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "130"
        },
        {
          "parameter_id": "44250_000000016",
          "product_sku": "44250",
          "parameter_name": "Монтаж",
          "parameter_value": "Наружный без выпуска"
        },
        {
          "parameter_id": "44250_000000018",
          "product_sku": "44250",
          "parameter_name": "Форма",
          "parameter_value": "Трубная"
        },
        {
          "parameter_id": "44250_000000022",
          "product_sku": "44250",
          "parameter_name": "Тип управления",
          "parameter_value": "Ручной"
        },
        {
          "parameter_id": "44250_000000025",
          "product_sku": "44250",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "44250_000000026",
          "product_sku": "44250",
          "parameter_name": "Страна производитель",
          "parameter_value": "Швейцария"
        },
        {
          "parameter_id": "44250_000000029",
          "product_sku": "44250",
          "parameter_name": "Перелив",
          "parameter_value": "Без перелива"
        },
        {
          "parameter_id": "44250_Brand",
          "product_sku": "44250",
          "parameter_name": "Бренд",
          "parameter_value": "LAUFEN"
        },
        {
          "parameter_id": "44250_Series",
          "product_sku": "44250",
          "parameter_name": "Серия",
          "parameter_value": "ALESSI DOT"
        }
      ]
    },
    {
      "product_sku": "044285",
      "product_categoryId": "1800054",
      "product_name": "DEBBA биде напольное",
      "product_mpn": "A355994000",
      "manufacturer_name": "ROCA",
      "product_seria": "DEBBA",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "92.67",
      "product_currency": "EUR",
      "product_price_online": "2734",
      "sourcePrice": "69.50",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_044285_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_044285_1.jpg"
      ],
      "description": "DEBBA биде напольное, с отверстием под смеситель, с переливом\nРекомендуется крышка A8069D2004, A8069D0004",
      parameters: [
        {
          "parameter_id": "44285_000000013",
          "product_sku": "44285",
          "parameter_name": "Материал",
          "parameter_value": "Санфаянс"
        },
        {
          "parameter_id": "44285_000000016",
          "product_sku": "44285",
          "parameter_name": "Монтаж",
          "parameter_value": "Отдельностоящий/напольный"
        },
        {
          "parameter_id": "44285_000000018",
          "product_sku": "44285",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "44285_000000023",
          "product_sku": "44285",
          "parameter_name": "Тип установки смесителя",
          "parameter_value": "1 отверстие"
        },
        {
          "parameter_id": "44285_000000026",
          "product_sku": "44285",
          "parameter_name": "Страна производитель",
          "parameter_value": "Испания"
        },
        {
          "parameter_id": "44285_000000029",
          "product_sku": "44285",
          "parameter_name": "Перелив",
          "parameter_value": "С переливом"
        },
        {
          "parameter_id": "44285_Brand",
          "product_sku": "44285",
          "parameter_name": "Бренд",
          "parameter_value": "ROCA"
        },
        {
          "parameter_id": "44285_Series",
          "product_sku": "44285",
          "parameter_name": "Серия",
          "parameter_value": "DEBBA"
        }
      ]
    },
    {
      "product_sku": "044288",
      "product_categoryId": "180005",
      "product_name": "DEBBA полупьедестал",
      "product_mpn": "A337991000",
      "manufacturer_name": "ROCA",
      "product_seria": "DEBBA",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "41.66",
      "product_currency": "EUR",
      "product_price_online": "1229",
      "sourcePrice": "31.25",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_044288_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_044288_1.jpg"
      ],
      "description": "DEBBA полупьедестал",
      parameters: [
        {
          "parameter_id": "44288_000000026",
          "product_sku": "44288",
          "parameter_name": "Страна производитель",
          "parameter_value": "Испания"
        },
        {
          "parameter_id": "44288_Brand",
          "product_sku": "44288",
          "parameter_name": "Бренд",
          "parameter_value": "ROCA"
        },
        {
          "parameter_id": "44288_Series",
          "product_sku": "44288",
          "parameter_name": "Серия",
          "parameter_value": "DEBBA"
        }
      ]
    },
    {
      "product_sku": "044290",
      "product_categoryId": "800035",
      "product_name": "DEBBA пенал 150см, серый антрацит",
      "product_mpn": "A856844153",
      "manufacturer_name": "ROCA",
      "product_seria": "DEBBA",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "340.15",
      "product_currency": "EUR",
      "product_price_online": "10034",
      "sourcePrice": "255.11",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_044290_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_044290_1.jpg"
      ],
      "description": "Пенал подвесной, 346*250*1500 мм, МДФ, распашные двери",
      parameters: [
        {
          "parameter_id": "44290_000000001",
          "product_sku": "44290",
          "parameter_name": "Ширина",
          "parameter_value": "346"
        },
        {
          "parameter_id": "44290_000000002",
          "product_sku": "44290",
          "parameter_name": "Конструкция",
          "parameter_value": "Пенал"
        },
        {
          "parameter_id": "44290_000000010",
          "product_sku": "44290",
          "parameter_name": "Тип дверей",
          "parameter_value": "Распашные"
        },
        {
          "parameter_id": "44290_000000013",
          "product_sku": "44290",
          "parameter_name": "Материал",
          "parameter_value": "МДФ"
        },
        {
          "parameter_id": "44290_000000014",
          "product_sku": "44290",
          "parameter_name": "Глубина",
          "parameter_value": "250"
        },
        {
          "parameter_id": "44290_000000015",
          "product_sku": "44290",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "1 500"
        },
        {
          "parameter_id": "44290_000000016",
          "product_sku": "44290",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "44290_000000025",
          "product_sku": "44290",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Другие цвета"
        },
        {
          "parameter_id": "44290_000000026",
          "product_sku": "44290",
          "parameter_name": "Страна производитель",
          "parameter_value": "Испания"
        },
        {
          "parameter_id": "44290_Brand",
          "product_sku": "44290",
          "parameter_name": "Бренд",
          "parameter_value": "ROCA"
        },
        {
          "parameter_id": "44290_Series",
          "product_sku": "44290",
          "parameter_name": "Серия",
          "parameter_value": "DEBBA"
        }
      ]
    },
    {
      "product_sku": "044292",
      "product_categoryId": "800063",
      "product_name": "DEBBA шкафчик 80см, с 2мя ящиками, с умывальником, в комплекте с сифоном, серый антрацит",
      "product_mpn": "A855907153",
      "manufacturer_name": "ROCA",
      "product_seria": "DEBBA",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "388.69",
      "product_currency": "EUR",
      "product_price_online": "11466",
      "sourcePrice": "291.52",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_044292_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_044292_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_044292_2.jpg"
      ],
      "description": "Комплект мебели: тумба, раковина, сифон. Подвесная, МДФ, 805*360*720 мм, прямоугольная, выдвижные ящики, серый антрацит. Умывальник на 1 отверстие, прямоугольный, с переливом.",
      parameters: [
        {
          "parameter_id": "44292_000000001",
          "product_sku": "44292",
          "parameter_name": "Ширина",
          "parameter_value": "805"
        },
        {
          "parameter_id": "44292_000000009",
          "product_sku": "44292",
          "parameter_name": "Комплектация",
          "parameter_value": "Тумба+раковина+сифон"
        },
        {
          "parameter_id": "44292_000000010",
          "product_sku": "44292",
          "parameter_name": "Тип дверей",
          "parameter_value": "Выдвижные"
        },
        {
          "parameter_id": "44292_000000013",
          "product_sku": "44292",
          "parameter_name": "Материал",
          "parameter_value": "МДФ"
        },
        {
          "parameter_id": "44292_000000014",
          "product_sku": "44292",
          "parameter_name": "Глубина",
          "parameter_value": "360"
        },
        {
          "parameter_id": "44292_000000015",
          "product_sku": "44292",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "720"
        },
        {
          "parameter_id": "44292_000000016",
          "product_sku": "44292",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "44292_000000018",
          "product_sku": "44292",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "44292_000000023",
          "product_sku": "44292",
          "parameter_name": "Тип установки смесителя",
          "parameter_value": "1 отверстие"
        },
        {
          "parameter_id": "44292_000000025",
          "product_sku": "44292",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Другие цвета"
        },
        {
          "parameter_id": "44292_000000026",
          "product_sku": "44292",
          "parameter_name": "Страна производитель",
          "parameter_value": "Испания"
        },
        {
          "parameter_id": "44292_000000029",
          "product_sku": "44292",
          "parameter_name": "Перелив",
          "parameter_value": "С переливом"
        },
        {
          "parameter_id": "44292_Brand",
          "product_sku": "44292",
          "parameter_name": "Бренд",
          "parameter_value": "ROCA"
        },
        {
          "parameter_id": "44292_Series",
          "product_sku": "44292",
          "parameter_name": "Серия",
          "parameter_value": "DEBBA"
        }
      ]
    },
    {
      "product_sku": "044336",
      "product_categoryId": "400071",
      "product_name": "RAINDANCE Select E 120 /Porter S душевой набор со шлангом 1,60м, хром",
      "product_mpn": "26720000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "Raindance Select E",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "116.90",
      "product_currency": "EUR",
      "product_price_online": "3507",
      "sourcePrice": "75.99",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_044336_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_044336_1.jpg"
      ],
      "description": "Тип струи: RainAir, Rain, Massage spray, удобный выбор режимов лейки через кнопку, максимальный расход (при 0,3 МПа): 16 л / мин, состоящий из: держатель душа я Porter’S  (no.28331000), Raindance Select E 120 3jet ручной душ (no.26520000), Isiflex душевой шланг 1,60 м (no.28276000)",
      parameters: [
        {
          "parameter_id": "44336_000000150",
          "product_sku": "44336",
          "parameter_name": "Высота, мм",
          "parameter_value": "0"
        },
        {
          "parameter_id": "44336_000000151",
          "product_sku": "44336",
          "parameter_name": "Тип держателя",
          "parameter_value": "Держатель"
        },
        {
          "parameter_id": "44336_000000152",
          "product_sku": "44336",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "44336_000000153",
          "product_sku": "44336",
          "parameter_name": "Форма лейки ручного душа",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "44336_000000154",
          "product_sku": "44336",
          "parameter_name": "Мыльница",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "44336_000000155",
          "product_sku": "44336",
          "parameter_name": "Кол-во режимов ручного душа",
          "parameter_value": "3"
        },
        {
          "parameter_id": "44336_000000175",
          "product_sku": "44336",
          "parameter_name": "Диаметр/Диагональ, мм",
          "parameter_value": "120"
        },
        {
          "parameter_id": "44336_000000176",
          "product_sku": "44336",
          "parameter_name": "Способ переключения режимов",
          "parameter_value": "Кнопка"
        },
        {
          "parameter_id": "44336_000000177",
          "product_sku": "44336",
          "parameter_name": "Цвет диска ручного душа",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "44336_Brand",
          "product_sku": "44336",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "44336_Series",
          "product_sku": "44336",
          "parameter_name": "Серия",
          "parameter_value": "Raindance Select E"
        }
      ]
    },
    {
      "product_sku": "044374",
      "product_categoryId": "4000119",
      "product_name": "PORTER Reno держатель для душа",
      "product_mpn": "28335000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "PORTER",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "33.90",
      "product_currency": "EUR",
      "product_price_online": "1017",
      "sourcePrice": "22.04",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_044374_0.jpg"
      ],
      "description": "Porter Reno Держатель для душа",
      parameters: [
        {
          "parameter_id": "44374_000000016",
          "product_sku": "44374",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "44374_000000025",
          "product_sku": "44374",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "44374_000000026",
          "product_sku": "44374",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "44374_Brand",
          "product_sku": "44374",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "44374_Series",
          "product_sku": "44374",
          "parameter_name": "Серия",
          "parameter_value": "PORTER"
        }
      ]
    },
    {
      "product_sku": "044403",
      "product_categoryId": "500036",
      "product_name": "SQUARO EDGE 12 ванна 170*75 см с ножками, со сливом-переливом",
      "product_mpn": "UBQ170SQE2DV-01",
      "manufacturer_name": "VILLEROY & BOCH",
      "product_seria": "SQUARO EDGE 12",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29
      },
      "exchangeRate_product_price_online": {
        "EUR": 29
      },
      "product_price": "864",
      "product_currency": "EUR",
      "product_price_old": "1390.0000",
      "product_price_online": "25056",
      "sourcePrice": "973",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_044403_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_044403_1.jpg"
      ],
      "description": "SQUARO EDGE 12 ванна 170*75 см",
      parameters: [
        {
          "parameter_id": "44403_000000071",
          "product_sku": "44403",
          "parameter_name": "Длина",
          "parameter_value": "1 700"
        },
        {
          "parameter_id": "44403_000000072",
          "product_sku": "44403",
          "parameter_name": "Ширина",
          "parameter_value": "750"
        },
        {
          "parameter_id": "44403_000000073",
          "product_sku": "44403",
          "parameter_name": "Высота",
          "parameter_value": "607"
        },
        {
          "parameter_id": "44403_000000074",
          "product_sku": "44403",
          "parameter_name": "Материал",
          "parameter_value": "Искуственный камень"
        },
        {
          "parameter_id": "44403_000000075",
          "product_sku": "44403",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый глянец"
        },
        {
          "parameter_id": "44403_000000076",
          "product_sku": "44403",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "44403_000000077",
          "product_sku": "44403",
          "parameter_name": "Ориентация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "44403_000000078",
          "product_sku": "44403",
          "parameter_name": "Монтаж",
          "parameter_value": "Пристенный"
        },
        {
          "parameter_id": "44403_000000080",
          "product_sku": "44403",
          "parameter_name": "Опора",
          "parameter_value": "Ножки"
        },
        {
          "parameter_id": "44403_000000081",
          "product_sku": "44403",
          "parameter_name": "Панель",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "44403_000000082",
          "product_sku": "44403",
          "parameter_name": "Сифон",
          "parameter_value": "Есть"
        },
        {
          "parameter_id": "44403_Brand",
          "product_sku": "44403",
          "parameter_name": "Бренд",
          "parameter_value": "VILLEROY & BOCH"
        },
        {
          "parameter_id": "44403_Series",
          "product_sku": "44403",
          "parameter_name": "Серия",
          "parameter_value": "SQUARO EDGE 12"
        }
      ]
    },
    {
      "product_sku": "044492",
      "product_categoryId": "400071",
      "product_name": "Crometta 100 Vario Душевой набор 0,65м цв. белый хром",
      "product_mpn": "26651400",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "CROMETTA 100",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "76.80",
      "product_currency": "EUR",
      "product_price_online": "2304",
      "sourcePrice": "49.92",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_044492_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_044492_1.jpg"
      ],
      "description": "Душевой набор, 4 типа струи. Переключение режимов струи - поворотом душевой лейки. Форсунки QuickClean против известковых отложений",
      parameters: [
        {
          "parameter_id": "44492_Brand",
          "product_sku": "44492",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "44492_Series",
          "product_sku": "44492",
          "parameter_name": "Серия",
          "parameter_value": "CROMETTA 100"
        }
      ]
    },
    {
      "product_sku": "044534",
      "product_categoryId": "400072",
      "product_name": "CROMETTA 160 Showerpipe душевая система с термостатом",
      "product_mpn": "27264400",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "CROMETTA 160",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "403.50",
      "product_currency": "EUR",
      "product_price_online": "12105",
      "sourcePrice": "262.28",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_044534_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_044534_1.jpg"
      ],
      "description": "Душевая система с термостатом, форсунки QuickClean против известковых отложений",
      parameters: [
        {
          "parameter_id": "44534_000000156",
          "product_sku": "44534",
          "parameter_name": "Ширина лейки верхнего душа, мм",
          "parameter_value": "180"
        },
        {
          "parameter_id": "44534_000000157",
          "product_sku": "44534",
          "parameter_name": "Длина лейки верхнего душа, мм",
          "parameter_value": "180"
        },
        {
          "parameter_id": "44534_000000158",
          "product_sku": "44534",
          "parameter_name": "Длина кронштейна (от стены), мм",
          "parameter_value": "353"
        },
        {
          "parameter_id": "44534_000000160",
          "product_sku": "44534",
          "parameter_name": "Мин. Высота, мм",
          "parameter_value": "1 099"
        },
        {
          "parameter_id": "44534_000000161",
          "product_sku": "44534",
          "parameter_name": "Регулируемая высота стойки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "44534_000000162",
          "product_sku": "44534",
          "parameter_name": "Форма лейки верхнего душа",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "44534_000000163",
          "product_sku": "44534",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "44534_000000164",
          "product_sku": "44534",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "44534_000000165",
          "product_sku": "44534",
          "parameter_name": "Тип управления",
          "parameter_value": "Термостат"
        },
        {
          "parameter_id": "44534_000000166",
          "product_sku": "44534",
          "parameter_name": "Смеситель",
          "parameter_value": "Для душа"
        },
        {
          "parameter_id": "44534_000000167",
          "product_sku": "44534",
          "parameter_name": "Кол-во режимов ручного душа",
          "parameter_value": "1"
        },
        {
          "parameter_id": "44534_000000168",
          "product_sku": "44534",
          "parameter_name": "Кол-во режимов верхнего душа",
          "parameter_value": "1"
        },
        {
          "parameter_id": "44534_Brand",
          "product_sku": "44534",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "44534_Series",
          "product_sku": "44534",
          "parameter_name": "Серия",
          "parameter_value": "CROMETTA 160"
        }
      ]
    },
    {
      "product_sku": "044536",
      "product_categoryId": "400071",
      "product_name": "CROMA Select E Multi душевой набор 0,65м, белый/хром",
      "product_mpn": "26580400",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "CROMA SELECT E",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "117.60",
      "product_currency": "EUR",
      "product_price_online": "3528",
      "sourcePrice": "76.44",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_044536_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_044536_1.jpg"
      ],
      "description": "Тип струи: SoftRain, IntenseRain, массажная; удобное переключение типов струи с помощью кнопки Select; размер душевого диска: 110 мм; со стороны душа упорный подшипник, предотвращающий перекручивание душевого шланга; максимальный расход воды (при 3 бар): 16 л / мин; хромированные настенные крепления из пластика",
      parameters: [
        {
          "parameter_id": "44536_000000150",
          "product_sku": "44536",
          "parameter_name": "Высота, мм",
          "parameter_value": "669"
        },
        {
          "parameter_id": "44536_000000151",
          "product_sku": "44536",
          "parameter_name": "Тип держателя",
          "parameter_value": "Штанга"
        },
        {
          "parameter_id": "44536_000000152",
          "product_sku": "44536",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "44536_000000153",
          "product_sku": "44536",
          "parameter_name": "Форма лейки ручного душа",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "44536_000000154",
          "product_sku": "44536",
          "parameter_name": "Мыльница",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "44536_000000155",
          "product_sku": "44536",
          "parameter_name": "Кол-во режимов ручного душа",
          "parameter_value": "3"
        },
        {
          "parameter_id": "44536_000000175",
          "product_sku": "44536",
          "parameter_name": "Диаметр/Диагональ, мм",
          "parameter_value": "110"
        },
        {
          "parameter_id": "44536_000000176",
          "product_sku": "44536",
          "parameter_name": "Способ переключения режимов",
          "parameter_value": "Кнопка"
        },
        {
          "parameter_id": "44536_000000177",
          "product_sku": "44536",
          "parameter_name": "Цвет диска ручного душа",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "44536_Brand",
          "product_sku": "44536",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "44536_Series",
          "product_sku": "44536",
          "parameter_name": "Серия",
          "parameter_value": "CROMA SELECT E"
        }
      ]
    },
    {
      "product_sku": "044572",
      "product_categoryId": "400027",
      "product_name": "Ondus Переключатель на 5 положений з/ч",
      "product_mpn": "19448000",
      "manufacturer_name": "GROHE",
      "product_seria": "ONDUS",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "269",
      "product_currency": "EUR",
      "product_price_old": "293.0000",
      "product_price_online": "7936",
      "sourcePrice": "175.80",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_044572_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_044572_1.jpg"
      ],
      "description": "Переключатель на 3 положения, необходим комплект встраиваемой части (29033000), без встраиваемого механизма, завинчивающаяся розетка, плавная регулировка глубины монтажа 66 - 113 мм, использовать только с встраиваемым механизмом.",
      parameters: [
        {
          "parameter_id": "44572_000000016",
          "product_sku": "44572",
          "parameter_name": "Монтаж",
          "parameter_value": "Встраиваемый в стену"
        },
        {
          "parameter_id": "44572_000000025",
          "product_sku": "44572",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "44572_000000026",
          "product_sku": "44572",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "44572_Brand",
          "product_sku": "44572",
          "parameter_name": "Бренд",
          "parameter_value": "GROHE"
        },
        {
          "parameter_id": "44572_Series",
          "product_sku": "44572",
          "parameter_name": "Серия",
          "parameter_value": "ONDUS"
        }
      ]
    },
    {
      "product_sku": "044593",
      "product_categoryId": "40003",
      "product_name": "BILOVEC смеситель для умывальника, хром, 35 мм",
      "product_mpn": "05255",
      "manufacturer_name": "IMPRESE",
      "product_seria": "BILOVEC",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "62",
      "product_currency": "EUR",
      "product_price_online": "1829",
      "sourcePrice": "43.40",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_044593_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_044593_1.jpg"
      ],
      "description": "Смеситель для умывальника, однорычажный, керамический узел смешивания, расход воды до 7 л/мин, аэратор, подходит для проточных нагревателей, хром",
      parameters: [
        {
          "parameter_id": "44593_000000117",
          "product_sku": "44593",
          "parameter_name": "Длина излива",
          "parameter_value": "127"
        },
        {
          "parameter_id": "44593_000000118",
          "product_sku": "44593",
          "parameter_name": "Высота излива",
          "parameter_value": "111"
        },
        {
          "parameter_id": "44593_000000119",
          "product_sku": "44593",
          "parameter_name": "Высота смесителя",
          "parameter_value": "168"
        },
        {
          "parameter_id": "44593_000000120",
          "product_sku": "44593",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной"
        },
        {
          "parameter_id": "44593_000000121",
          "product_sku": "44593",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "44593_000000122",
          "product_sku": "44593",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "44593_000000123",
          "product_sku": "44593",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "44593_000000124",
          "product_sku": "44593",
          "parameter_name": "Наличие донного клапана",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "44593_000000125",
          "product_sku": "44593",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "1"
        },
        {
          "parameter_id": "44593_Brand",
          "product_sku": "44593",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "44593_Series",
          "product_sku": "44593",
          "parameter_name": "Серия",
          "parameter_value": "BILOVEC"
        }
      ]
    },
    {
      "product_sku": "044595",
      "product_categoryId": "400042",
      "product_name": "BILOVEC смеситель для ванны, хром, 35 мм",
      "product_mpn": "10255",
      "manufacturer_name": "IMPRESE",
      "product_seria": "BILOVEC",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "85",
      "product_currency": "EUR",
      "product_price_online": "2508",
      "sourcePrice": "59.50",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_044595_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_044595_1.jpg"
      ],
      "description": "Смеситель для ванны, однорычажный, керамический узел смешивания, расход воды до 22 л/мин, аэратор, подходит для проточных нагревателей, хром\nМодель установленного картриджа Sedal EN- 35 С/D",
      parameters: [
        {
          "parameter_id": "44595_000000093",
          "product_sku": "44595",
          "parameter_name": "Длина излива",
          "parameter_value": "159"
        },
        {
          "parameter_id": "44595_000000094",
          "product_sku": "44595",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "44595_000000095",
          "product_sku": "44595",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "44595_000000096",
          "product_sku": "44595",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "44595_000000097",
          "product_sku": "44595",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "44595_000000098",
          "product_sku": "44595",
          "parameter_name": "Тип переключателя ванна/душ",
          "parameter_value": "Выжимной"
        },
        {
          "parameter_id": "44595_000000099",
          "product_sku": "44595",
          "parameter_name": "Повротный излив",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "44595_000000100",
          "product_sku": "44595",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "2"
        },
        {
          "parameter_id": "44595_000000126",
          "product_sku": "44595",
          "parameter_name": "Кол-во потребителей",
          "parameter_value": "2"
        },
        {
          "parameter_id": "44595_000000128",
          "product_sku": "44595",
          "parameter_name": "Форма накладки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "44595_Brand",
          "product_sku": "44595",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "44595_Series",
          "product_sku": "44595",
          "parameter_name": "Серия",
          "parameter_value": "BILOVEC"
        }
      ]
    },
    {
      "product_sku": "044597",
      "product_categoryId": "400053",
      "product_name": "BILOVEC смеситель для душа, хром, 35 мм",
      "product_mpn": "15255",
      "manufacturer_name": "IMPRESE",
      "product_seria": "BILOVEC",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "60",
      "product_currency": "EUR",
      "product_price_online": "1770",
      "sourcePrice": "42",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_044597_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_044597_1.jpg"
      ],
      "description": "Смеситель для душа, однорычажный, керамический узел смешивания, расход воды до 22 л/мин, аэратор, подходит для проточных нагревателей, хром\nМодель установленного картриджа Sedal EN- 35 S/D AZ",
      parameters: [
        {
          "parameter_id": "44597_000000101",
          "product_sku": "44597",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "44597_000000102",
          "product_sku": "44597",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "44597_000000103",
          "product_sku": "44597",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "44597_000000104",
          "product_sku": "44597",
          "parameter_name": "С полочкой",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "44597_000000105",
          "product_sku": "44597",
          "parameter_name": "Положение регулятора",
          "parameter_value": "Спереди по центру"
        },
        {
          "parameter_id": "44597_000000129",
          "product_sku": "44597",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "44597_000000130",
          "product_sku": "44597",
          "parameter_name": "Форма накладки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "44597_Brand",
          "product_sku": "44597",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "44597_Series",
          "product_sku": "44597",
          "parameter_name": "Серия",
          "parameter_value": "BILOVEC"
        }
      ]
    },
    {
      "product_sku": "044598",
      "product_categoryId": "400068",
      "product_name": "BILOVEC смеситель для кухни, хром, 35 мм",
      "product_mpn": "55255",
      "manufacturer_name": "IMPRESE",
      "product_seria": "BILOVEC",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "99",
      "product_currency": "EUR",
      "product_price_online": "2921",
      "sourcePrice": "69.30",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_044598_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_044598_1.jpg"
      ],
      "description": "Смеситель для кухни, однорычажный, керамический узел смешивания, расход воды до 7 л/мин, аэратор, подходит для проточных нагревателей, хром\nМодель установленного картриджа Sedal EN- 35 S/D AZ",
      parameters: [
        {
          "parameter_id": "44598_000000106",
          "product_sku": "44598",
          "parameter_name": "Длина излива",
          "parameter_value": "191"
        },
        {
          "parameter_id": "44598_000000107",
          "product_sku": "44598",
          "parameter_name": "Высота излива",
          "parameter_value": "259"
        },
        {
          "parameter_id": "44598_000000108",
          "product_sku": "44598",
          "parameter_name": "Высота смесителя",
          "parameter_value": "285"
        },
        {
          "parameter_id": "44598_000000109",
          "product_sku": "44598",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной"
        },
        {
          "parameter_id": "44598_000000110",
          "product_sku": "44598",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "44598_000000111",
          "product_sku": "44598",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "44598_000000112",
          "product_sku": "44598",
          "parameter_name": "Тип излива",
          "parameter_value": "Г-образный"
        },
        {
          "parameter_id": "44598_000000113",
          "product_sku": "44598",
          "parameter_name": "Выдвижной излив",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "44598_000000114",
          "product_sku": "44598",
          "parameter_name": "Вывод для фильтрованной в",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "44598_000000115",
          "product_sku": "44598",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "44598_000000116",
          "product_sku": "44598",
          "parameter_name": "Особенности",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "44598_Brand",
          "product_sku": "44598",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "44598_Series",
          "product_sku": "44598",
          "parameter_name": "Серия",
          "parameter_value": "BILOVEC"
        }
      ]
    },
    {
      "product_sku": "045714",
      "product_categoryId": "500040",
      "product_name": "MIRRA ванна 170*110см асимметричная левая, с ножками SN8 и элементами крепления",
      "product_mpn": "XWA3371000",
      "manufacturer_name": "KOLO Украина",
      "product_seria": "MIRRA",
      "product_status": null,
      "exchangeRate_product_source_price": [],
      "exchangeRate_product_price_online": [],
      "product_price": "6945",
      "product_currency": "UAH",
      "product_price_online": "6597",
      "sourcePrice": "4930.95",
      "sourceCurrency": "UAH",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_045714_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_045714_1.jpg"
      ],
      "description": "Ванна ассиметричная, левая Коло-Дымер, с ножками и элементами крепления. Длина 1700 мм, ширина 1100 мм, глубина 420 мм, объём 285 л. Для пристенного монтажа",
      parameters: [
        {
          "parameter_id": "45714_000000071",
          "product_sku": "45714",
          "parameter_name": "Длина",
          "parameter_value": "1 700"
        },
        {
          "parameter_id": "45714_000000072",
          "product_sku": "45714",
          "parameter_name": "Ширина",
          "parameter_value": "1 100"
        },
        {
          "parameter_id": "45714_000000073",
          "product_sku": "45714",
          "parameter_name": "Высота",
          "parameter_value": "420"
        },
        {
          "parameter_id": "45714_000000074",
          "product_sku": "45714",
          "parameter_name": "Материал",
          "parameter_value": "Акрил"
        },
        {
          "parameter_id": "45714_000000075",
          "product_sku": "45714",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "45714_000000076",
          "product_sku": "45714",
          "parameter_name": "Форма",
          "parameter_value": "Угловая"
        },
        {
          "parameter_id": "45714_000000077",
          "product_sku": "45714",
          "parameter_name": "Ориентация",
          "parameter_value": "Левосторонняя"
        },
        {
          "parameter_id": "45714_000000078",
          "product_sku": "45714",
          "parameter_name": "Монтаж",
          "parameter_value": "Пристенный"
        },
        {
          "parameter_id": "45714_000000079",
          "product_sku": "45714",
          "parameter_name": "Особенности",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "45714_000000080",
          "product_sku": "45714",
          "parameter_name": "Опора",
          "parameter_value": "Ножки"
        },
        {
          "parameter_id": "45714_000000081",
          "product_sku": "45714",
          "parameter_name": "Панель",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "45714_000000082",
          "product_sku": "45714",
          "parameter_name": "Сифон",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "45714_000000083",
          "product_sku": "45714",
          "parameter_name": "Смеситель",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "45714_000000084",
          "product_sku": "45714",
          "parameter_name": "Гидромассаж",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "45714_000000085",
          "product_sku": "45714",
          "parameter_name": "Тип управления",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "45714_000000182",
          "product_sku": "45714",
          "parameter_name": "Тип поверхности",
          "parameter_value": "Глянцевая"
        },
        {
          "parameter_id": "45714_Brand",
          "product_sku": "45714",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Украина"
        },
        {
          "parameter_id": "45714_Series",
          "product_sku": "45714",
          "parameter_name": "Серия",
          "parameter_value": "MIRRA"
        }
      ]
    },
    {
      "product_sku": "045766",
      "product_categoryId": "400013",
      "product_name": "Hansgrohe Вставка для держателя ручного душа з/ч",
      "product_mpn": "96942000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "HANSGROHE",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "7.10",
      "product_currency": "EUR",
      "product_price_online": "213",
      "sourcePrice": "4.62",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_045766_0.jpg"
      ],
      "description": "Вставка для держателя ручного душа з/ч",
      parameters: [
        {
          "parameter_id": "45766_000000026",
          "product_sku": "45766",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "45766_Brand",
          "product_sku": "45766",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "45766_Series",
          "product_sku": "45766",
          "parameter_name": "Серия",
          "parameter_value": "HANSGROHE"
        }
      ]
    },
    {
      "product_sku": "045767",
      "product_categoryId": "400013",
      "product_name": "Hansgrohe Накладка для держателя ручного душа з/ч",
      "product_mpn": "95753000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "HANSGROHE",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "43.90",
      "product_currency": "EUR",
      "product_price_online": "1317",
      "sourcePrice": "28.54",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      "description": "Накладка для держателя ручного душа з/ч",
      parameters: [
        {
          "parameter_id": "45767_000000026",
          "product_sku": "45767",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "45767_Brand",
          "product_sku": "45767",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "45767_Series",
          "product_sku": "45767",
          "parameter_name": "Серия",
          "parameter_value": "HANSGROHE"
        }
      ]
    },
    {
      "product_sku": "045768",
      "product_categoryId": "400013",
      "product_name": "Hansgrohe Гайка з/ч",
      "product_mpn": "97149000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "HANSGROHE",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "7.10",
      "product_currency": "EUR",
      "product_price_online": "213",
      "sourcePrice": "4.62",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      "description": "Гайка з/ч",
      parameters: [
        {
          "parameter_id": "45768_000000026",
          "product_sku": "45768",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "45768_Brand",
          "product_sku": "45768",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "45768_Series",
          "product_sku": "45768",
          "parameter_name": "Серия",
          "parameter_value": "HANSGROHE"
        }
      ]
    },
    {
      "product_sku": "045769",
      "product_categoryId": "180004",
      "product_name": "ARCHITECTURA умывальник 60*40см для установки на столешницу",
      "product_mpn": "41266001",
      "manufacturer_name": "VILLEROY & BOCH",
      "product_seria": "ARCHITECTURA",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29
      },
      "exchangeRate_product_price_online": {
        "EUR": 29
      },
      "product_price": "165",
      "product_currency": "EUR",
      "product_price_old": "293.0000",
      "product_price_online": "4785",
      "sourcePrice": "181.66",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_045769_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_045769_1.jpg"
      ],
      "description": "ARCHITECTURA умывальник для установки на столешницу 60*40 см, без отверстия под смеситель, скрытый перелив",
      parameters: [
        {
          "parameter_id": "45769_000000058",
          "product_sku": "45769",
          "parameter_name": "Ширина",
          "parameter_value": "600"
        },
        {
          "parameter_id": "45769_000000059",
          "product_sku": "45769",
          "parameter_name": "Глубина",
          "parameter_value": "400"
        },
        {
          "parameter_id": "45769_000000060",
          "product_sku": "45769",
          "parameter_name": "Высота",
          "parameter_value": "170"
        },
        {
          "parameter_id": "45769_000000061",
          "product_sku": "45769",
          "parameter_name": "Монтаж",
          "parameter_value": "На столешницу"
        },
        {
          "parameter_id": "45769_000000062",
          "product_sku": "45769",
          "parameter_name": "Форма",
          "parameter_value": "Овальная"
        },
        {
          "parameter_id": "45769_000000063",
          "product_sku": "45769",
          "parameter_name": "Особенности формы",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "45769_000000064",
          "product_sku": "45769",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "45769_000000065",
          "product_sku": "45769",
          "parameter_name": "Комплектация",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "45769_000000066",
          "product_sku": "45769",
          "parameter_name": "Материал",
          "parameter_value": "Керамика"
        },
        {
          "parameter_id": "45769_000000067",
          "product_sku": "45769",
          "parameter_name": "Перелив",
          "parameter_value": "Без перелива"
        },
        {
          "parameter_id": "45769_000000068",
          "product_sku": "45769",
          "parameter_name": "Отверстия под смеситель",
          "parameter_value": "Без отверстия"
        },
        {
          "parameter_id": "45769_000000069",
          "product_sku": "45769",
          "parameter_name": "Кол-во смесителей",
          "parameter_value": "Без отверстия"
        },
        {
          "parameter_id": "45769_000000070",
          "product_sku": "45769",
          "parameter_name": "Особенности",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "45769_Brand",
          "product_sku": "45769",
          "parameter_name": "Бренд",
          "parameter_value": "VILLEROY & BOCH"
        },
        {
          "parameter_id": "45769_Series",
          "product_sku": "45769",
          "parameter_name": "Серия",
          "parameter_value": "ARCHITECTURA"
        }
      ]
    },
    {
      "product_sku": "045770",
      "product_categoryId": "400013",
      "product_name": "Hansgrohe Ограничитель шланга з/ч",
      "product_mpn": "98656000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "HANSGROHE",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "11.30",
      "product_currency": "EUR",
      "product_price_online": "339",
      "sourcePrice": "7.35",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_045770_0.jpg"
      ],
      "description": "Ограничитель шланга з/ч",
      parameters: [
        {
          "parameter_id": "45770_000000026",
          "product_sku": "45770",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "45770_Brand",
          "product_sku": "45770",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "45770_Series",
          "product_sku": "45770",
          "parameter_name": "Серия",
          "parameter_value": "HANSGROHE"
        }
      ]
    },
    {
      "product_sku": "045773",
      "product_categoryId": "400013",
      "product_name": "Hansgrohe Крепление для Secuflex з/ч",
      "product_mpn": "96072000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "HANSGROHE",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "43.90",
      "product_currency": "EUR",
      "product_price_online": "1317",
      "sourcePrice": "28.54",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_045773_0.jpg"
      ],
      "description": "Крепление для Secuflex",
      parameters: [
        {
          "parameter_id": "45773_000000026",
          "product_sku": "45773",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "45773_Brand",
          "product_sku": "45773",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "45773_Series",
          "product_sku": "45773",
          "parameter_name": "Серия",
          "parameter_value": "HANSGROHE"
        }
      ]
    },
    {
      "product_sku": "045774",
      "product_categoryId": "400013",
      "product_name": "Hansgrohe Направляющая трубка з/ч",
      "product_mpn": "98807000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "HANSGROHE",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "3.20",
      "product_currency": "EUR",
      "product_price_online": "96",
      "sourcePrice": "2.08",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      "description": "Направляющая трубка з/ч",
      parameters: [
        {
          "parameter_id": "45774_000000026",
          "product_sku": "45774",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "45774_Brand",
          "product_sku": "45774",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "45774_Series",
          "product_sku": "45774",
          "parameter_name": "Серия",
          "parameter_value": "HANSGROHE"
        }
      ]
    },
    {
      "product_sku": "045878",
      "product_categoryId": "200043",
      "product_name": "RAPID SL 3в1 инсталяционная  система для подвесного унитаза (аналог-38775001), без прокладки",
      "product_mpn": "38772001",
      "manufacturer_name": "GROHE",
      "product_seria": "RAPID SL",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "135.56",
      "product_currency": "EUR",
      "product_price_old": "236.0000",
      "product_price_online": "3999",
      "sourcePrice": "115",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_045878_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_045878_1.jpg"
      ],
      "description": "Инсталляционная система для подвесного унитаза, режим смыва двойной экономичный/обычный, система смыва пневматическая. Монтаж для стены",
      parameters: [
        {
          "parameter_id": "45878_000000009",
          "product_sku": "45878",
          "parameter_name": "Комплектация",
          "parameter_value": "Инсталляция+крепление+клавиша"
        },
        {
          "parameter_id": "45878_000000026",
          "product_sku": "45878",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "45878_Brand",
          "product_sku": "45878",
          "parameter_name": "Бренд",
          "parameter_value": "GROHE"
        },
        {
          "parameter_id": "45878_Series",
          "product_sku": "45878",
          "parameter_name": "Серия",
          "parameter_value": "RAPID SL"
        }
      ]
    },
    {
      "product_sku": "045886",
      "product_categoryId": "14000121",
      "product_name": "ADVANTIX VARIO душевой лоток высота 70мм, 300-1200мм",
      "product_mpn": "721671",
      "manufacturer_name": "VIEGA",
      "product_seria": "4966.10",
      "product_status": "Спеццена",
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "260",
      "product_currency": "EUR",
      "product_price_old": "329.2800",
      "product_price_online": "7670",
      "sourcePrice": "210.74",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_045886_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_045886_1.jpg"
      ],
      "description": "Advantix Vario Трап плоская модель, длина, мм: 300-1200, монтажная высота, мм: 70-95, пропускная способность (DC), л/с: 0.55-0.6, высота столба жидкости гидрозатвора: 25 мм, материал: высококачественный пластик, корпус: произвольно укачивающий.Данный лоток можно доукомплектовать вставками: арт.686284 , арт.686291.",
      parameters: [
        {
          "parameter_id": "45886_000000006",
          "product_sku": "45886",
          "parameter_name": "Диаметр (мм)",
          "parameter_value": "50"
        },
        {
          "parameter_id": "45886_000000015",
          "product_sku": "45886",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "70"
        },
        {
          "parameter_id": "45886_000000016",
          "product_sku": "45886",
          "parameter_name": "Монтаж",
          "parameter_value": "Скрытый"
        },
        {
          "parameter_id": "45886_000000017",
          "product_sku": "45886",
          "parameter_name": "Назначение",
          "parameter_value": "Внутреннее водоотведение"
        },
        {
          "parameter_id": "45886_000000018",
          "product_sku": "45886",
          "parameter_name": "Форма",
          "parameter_value": "Линейная"
        },
        {
          "parameter_id": "45886_000000021",
          "product_sku": "45886",
          "parameter_name": "Подключение к канализации",
          "parameter_value": "Горизонтальное"
        },
        {
          "parameter_id": "45886_000000025",
          "product_sku": "45886",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Серый"
        },
        {
          "parameter_id": "45886_000000026",
          "product_sku": "45886",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "45886_Brand",
          "product_sku": "45886",
          "parameter_name": "Бренд",
          "parameter_value": "VIEGA"
        },
        {
          "parameter_id": "45886_Series",
          "product_sku": "45886",
          "parameter_name": "Серия",
          "parameter_value": "4966.10"
        }
      ]
    },
    {
      "product_sku": "047528",
      "product_categoryId": "400053",
      "product_name": "EURODISC Joy смеситель для душа, однорычажный, цвет белый",
      "product_mpn": "23430LS0",
      "manufacturer_name": "GROHE",
      "product_seria": "EURODISC JOY",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "281.32",
      "product_currency": "EUR",
      "product_price_old": "399.0000",
      "product_price_online": "8299",
      "sourcePrice": "195",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_047528_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_047528_1.jpg"
      ],
      "description": "Смеситель для душа, однорычажный. Цвет белый. Металический рычаг. Управление - джойстик. Картридж керамический. Встроенный обратный клапан для защиты от обратного потока. Способ монтажа: настенный.",
      parameters: [
        {
          "parameter_id": "47528_000000101",
          "product_sku": "47528",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "47528_000000102",
          "product_sku": "47528",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "47528_000000103",
          "product_sku": "47528",
          "parameter_name": "Тип управления",
          "parameter_value": "Джойстик"
        },
        {
          "parameter_id": "47528_000000104",
          "product_sku": "47528",
          "parameter_name": "С полочкой",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "47528_000000105",
          "product_sku": "47528",
          "parameter_name": "Положение регулятора",
          "parameter_value": "Сверху"
        },
        {
          "parameter_id": "47528_000000129",
          "product_sku": "47528",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "47528_000000130",
          "product_sku": "47528",
          "parameter_name": "Форма накладки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "47528_Brand",
          "product_sku": "47528",
          "parameter_name": "Бренд",
          "parameter_value": "GROHE"
        },
        {
          "parameter_id": "47528_Series",
          "product_sku": "47528",
          "parameter_name": "Серия",
          "parameter_value": "EURODISC JOY"
        }
      ]
    },
    {
      "product_sku": "047553",
      "product_categoryId": "10000123",
      "product_name": "ADVANTIX VARIO заглушка декоративная прямая, мат",
      "product_mpn": "711795",
      "manufacturer_name": "VIEGA",
      "product_seria": "Advantix Vario",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "76.55",
      "product_currency": "EUR",
      "product_price_online": "2258",
      "sourcePrice": "48.99",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_047553_0.jpg"
      ],
      "description": "Набор комплектующих",
      parameters: [
        {
          "parameter_id": "47553_000000026",
          "product_sku": "47553",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "47553_Brand",
          "product_sku": "47553",
          "parameter_name": "Бренд",
          "parameter_value": "VIEGA"
        },
        {
          "parameter_id": "47553_Series",
          "product_sku": "47553",
          "parameter_name": "Серия",
          "parameter_value": "Advantix Vario"
        }
      ]
    },
    {
      "product_sku": "047555",
      "product_categoryId": "10000123",
      "product_name": "ADVANTIX VARIO заглушка декоративная угловая, мат",
      "product_mpn": "711788",
      "manufacturer_name": "VIEGA",
      "product_seria": "Advantix Vario",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "76.55",
      "product_currency": "EUR",
      "product_price_online": "2258",
      "sourcePrice": "48.99",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_047555_0.jpg"
      ],
      "description": "Набор комплектующих",
      parameters: [
        {
          "parameter_id": "47555_000000026",
          "product_sku": "47555",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "47555_Brand",
          "product_sku": "47555",
          "parameter_name": "Бренд",
          "parameter_value": "VIEGA"
        },
        {
          "parameter_id": "47555_Series",
          "product_sku": "47555",
          "parameter_name": "Серия",
          "parameter_value": "Advantix Vario"
        }
      ]
    },
    {
      "product_sku": "047556",
      "product_categoryId": "10000123",
      "product_name": "SK Advantix Vario монтажный комплект, матовый (711832)",
      "product_mpn": "711832",
      "manufacturer_name": "VIEGA",
      "product_seria": "Advantix Vario",
      "product_status": "Спеццена",
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "121.16",
      "product_currency": "EUR",
      "product_price_online": "3574",
      "sourcePrice": "77.54",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_047556_0.jpg"
      ],
      "description": "Монтажный комплект",
      parameters: [
        {
          "parameter_id": "47556_000000026",
          "product_sku": "47556",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "47556_Brand",
          "product_sku": "47556",
          "parameter_name": "Бренд",
          "parameter_value": "VIEGA"
        },
        {
          "parameter_id": "47556_Series",
          "product_sku": "47556",
          "parameter_name": "Серия",
          "parameter_value": "Advantix Vario"
        }
      ]
    },
    {
      "product_sku": "047586",
      "product_categoryId": "600066",
      "product_name": "Поддон 80*80 см,мелкий,  квадратный, высота 15 см",
      "product_mpn": "R-501",
      "manufacturer_name": "ELEPHANT",
      "product_seria": "",
      "product_status": "Спеццена",
      "product_price": "52",
      "product_currency": "USD",
      "product_price_old": "60.0000",
      "product_price_online": "52",
      "sourcePrice": "40",
      "sourceCurrency": "USD",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_047586_0.jpg"
      ],
      "description": "Поддон мелкий  80*80 см, квадратный (высота 15 см), акрил, с формованной лицевой панелью, сифон с гофрой в комплекте",
      parameters: [
        {
          "parameter_id": "47586_000000001",
          "product_sku": "47586",
          "parameter_name": "Ширина",
          "parameter_value": "800"
        },
        {
          "parameter_id": "47586_000000011",
          "product_sku": "47586",
          "parameter_name": "Тип поддона",
          "parameter_value": "Мелкий"
        },
        {
          "parameter_id": "47586_000000013",
          "product_sku": "47586",
          "parameter_name": "Материал",
          "parameter_value": "Акрил"
        },
        {
          "parameter_id": "47586_000000014",
          "product_sku": "47586",
          "parameter_name": "Глубина",
          "parameter_value": "800"
        },
        {
          "parameter_id": "47586_000000015",
          "product_sku": "47586",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "150"
        },
        {
          "parameter_id": "47586_000000018",
          "product_sku": "47586",
          "parameter_name": "Форма",
          "parameter_value": "Квадратная"
        },
        {
          "parameter_id": "47586_Brand",
          "product_sku": "47586",
          "parameter_name": "Бренд",
          "parameter_value": "ELEPHANT"
        },
        {
          "parameter_id": "47586_Series",
          "product_sku": "47586",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "047589",
      "product_categoryId": "1800074",
      "product_name": "O.NOVO унитаз подвесной DirectFlush, с крышкой для унитаза, с функцией Soft Closing",
      "product_mpn": "5660HR01",
      "manufacturer_name": "VILLEROY & BOCH",
      "product_seria": "O.NOVO",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29
      },
      "exchangeRate_product_price_online": {
        "EUR": 29
      },
      "product_price": "144",
      "product_currency": "EUR",
      "product_price_old": "326.0000",
      "product_price_online": "4176",
      "sourcePrice": "202.12",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_047589_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_047589_1.jpg"
      ],
      "description": "Унитаз, модель подвесная, без ободка. Сиденье с крышкой для унитаза, с функцией Soft Closing, из Duroplast. Крепления из нержавеющей стали. Слив: 4,5 l, размер: 560*360*400 мм, вес: 18 кг.",
      parameters: [
        {
          "parameter_id": "47589_000000041",
          "product_sku": "47589",
          "parameter_name": "Длина",
          "parameter_value": "560"
        },
        {
          "parameter_id": "47589_000000042",
          "product_sku": "47589",
          "parameter_name": "Ширина",
          "parameter_value": "360"
        },
        {
          "parameter_id": "47589_000000043",
          "product_sku": "47589",
          "parameter_name": "Высота",
          "parameter_value": "350"
        },
        {
          "parameter_id": "47589_000000044",
          "product_sku": "47589",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "47589_000000045",
          "product_sku": "47589",
          "parameter_name": "Подключение к канализации",
          "parameter_value": "Горизонтальное"
        },
        {
          "parameter_id": "47589_000000046",
          "product_sku": "47589",
          "parameter_name": "Безободковый",
          "parameter_value": "Да"
        },
        {
          "parameter_id": "47589_000000047",
          "product_sku": "47589",
          "parameter_name": "Форма",
          "parameter_value": "Округлая"
        },
        {
          "parameter_id": "47589_000000048",
          "product_sku": "47589",
          "parameter_name": "Тип изделия",
          "parameter_value": "Унитаз подвесной"
        },
        {
          "parameter_id": "47589_000000049",
          "product_sku": "47589",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "47589_000000050",
          "product_sku": "47589",
          "parameter_name": "Комплектация",
          "parameter_value": "Без бачка"
        },
        {
          "parameter_id": "47589_000000051",
          "product_sku": "47589",
          "parameter_name": "Тип слива бачка",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "47589_000000052",
          "product_sku": "47589",
          "parameter_name": "Подвод воды",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "47589_000000053",
          "product_sku": "47589",
          "parameter_name": "Сиденье, крышка",
          "parameter_value": "Сиденье для унитаза Soft-close"
        },
        {
          "parameter_id": "47589_000000054",
          "product_sku": "47589",
          "parameter_name": "Материал сиденья",
          "parameter_value": "Дюропласт"
        },
        {
          "parameter_id": "47589_000000055",
          "product_sku": "47589",
          "parameter_name": "Унитаз с функцией биде",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "47589_Brand",
          "product_sku": "47589",
          "parameter_name": "Бренд",
          "parameter_value": "VILLEROY & BOCH"
        },
        {
          "parameter_id": "47589_Series",
          "product_sku": "47589",
          "parameter_name": "Серия",
          "parameter_value": "O.NOVO"
        }
      ]
    },
    {
      "product_sku": "047640",
      "product_categoryId": "400042",
      "product_name": "VERSOSTAT² термостат для ванны, наружная часть",
      "product_mpn": "15348000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "VERSOSTAT",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "234.50",
      "product_currency": "EUR",
      "product_price_online": "7035",
      "sourcePrice": "152.43",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_047640_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_047640_1.jpg"
      ],
      "description": "Термостат для ванны настенный, с термостатом, хром",
      parameters: [
        {
          "parameter_id": "47640_000000093",
          "product_sku": "47640",
          "parameter_name": "Длина излива",
          "parameter_value": "194"
        },
        {
          "parameter_id": "47640_000000094",
          "product_sku": "47640",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "47640_000000095",
          "product_sku": "47640",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "47640_000000096",
          "product_sku": "47640",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "47640_000000097",
          "product_sku": "47640",
          "parameter_name": "Тип управления",
          "parameter_value": "Термостат"
        },
        {
          "parameter_id": "47640_000000098",
          "product_sku": "47640",
          "parameter_name": "Тип переключателя ванна/душ",
          "parameter_value": "Поворотный"
        },
        {
          "parameter_id": "47640_000000099",
          "product_sku": "47640",
          "parameter_name": "Повротный излив",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "47640_000000100",
          "product_sku": "47640",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "2"
        },
        {
          "parameter_id": "47640_000000126",
          "product_sku": "47640",
          "parameter_name": "Кол-во потребителей",
          "parameter_value": "2"
        },
        {
          "parameter_id": "47640_000000128",
          "product_sku": "47640",
          "parameter_name": "Форма накладки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "47640_Brand",
          "product_sku": "47640",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "47640_Series",
          "product_sku": "47640",
          "parameter_name": "Серия",
          "parameter_value": "VERSOSTAT"
        }
      ]
    },
    {
      "product_sku": "047718",
      "product_categoryId": "400073",
      "product_name": "Душ ручной 120 мм, 3 режима, блистер",
      "product_mpn": "W120T3",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "14",
      "product_currency": "EUR",
      "product_price_online": "413",
      "sourcePrice": "9.80",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_047718_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_047718_1.jpg"
      ],
      "description": "Душ ручной 120 мм, 3 режима (Rain, Massage, Fog), блистер, хром, пластик.",
      parameters: [
        {
          "parameter_id": "47718_000000170",
          "product_sku": "47718",
          "parameter_name": "Диаметр/Диагональ, мм",
          "parameter_value": "120"
        },
        {
          "parameter_id": "47718_000000171",
          "product_sku": "47718",
          "parameter_name": "Форма лейки ручного душа",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "47718_000000172",
          "product_sku": "47718",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "47718_000000173",
          "product_sku": "47718",
          "parameter_name": "Кол-во режимов ручного душа",
          "parameter_value": "3"
        },
        {
          "parameter_id": "47718_000000174",
          "product_sku": "47718",
          "parameter_name": "Способ переключения режимов",
          "parameter_value": "Кнопка"
        },
        {
          "parameter_id": "47718_Brand",
          "product_sku": "47718",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "47718_Series",
          "product_sku": "47718",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "047719",
      "product_categoryId": "400073",
      "product_name": "Душ ручной 100 мм, 3 режима, блистер",
      "product_mpn": "W100T3",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "13",
      "product_currency": "EUR",
      "product_price_online": "384",
      "sourcePrice": "9.10",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_047719_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_047719_1.jpg"
      ],
      "description": "Душ ручной 100 мм, 3 режима (Rain, Massage, Fog), блистер, хром, пластик ABS.",
      parameters: [
        {
          "parameter_id": "47719_000000170",
          "product_sku": "47719",
          "parameter_name": "Диаметр/Диагональ, мм",
          "parameter_value": "100"
        },
        {
          "parameter_id": "47719_000000171",
          "product_sku": "47719",
          "parameter_name": "Форма лейки ручного душа",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "47719_000000172",
          "product_sku": "47719",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "47719_000000173",
          "product_sku": "47719",
          "parameter_name": "Кол-во режимов ручного душа",
          "parameter_value": "3"
        },
        {
          "parameter_id": "47719_000000174",
          "product_sku": "47719",
          "parameter_name": "Способ переключения режимов",
          "parameter_value": "Кнопка"
        },
        {
          "parameter_id": "47719_Brand",
          "product_sku": "47719",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "47719_Series",
          "product_sku": "47719",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "047721",
      "product_categoryId": "400073",
      "product_name": "Душ ручной 70 мм, 3 режима",
      "product_mpn": "W070SQT3",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "11",
      "product_currency": "EUR",
      "product_price_online": "325",
      "sourcePrice": "7.70",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_047721_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_047721_1.jpg"
      ],
      "description": "Душ ручной 70 мм, 3 режима, блистер, хром, пластик ABS.",
      parameters: [
        {
          "parameter_id": "47721_000000170",
          "product_sku": "47721",
          "parameter_name": "Диаметр/Диагональ, мм",
          "parameter_value": "70"
        },
        {
          "parameter_id": "47721_000000171",
          "product_sku": "47721",
          "parameter_name": "Форма лейки ручного душа",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "47721_000000172",
          "product_sku": "47721",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром/белый"
        },
        {
          "parameter_id": "47721_000000173",
          "product_sku": "47721",
          "parameter_name": "Кол-во режимов ручного душа",
          "parameter_value": "3"
        },
        {
          "parameter_id": "47721_000000174",
          "product_sku": "47721",
          "parameter_name": "Способ переключения режимов",
          "parameter_value": "Кнопка"
        },
        {
          "parameter_id": "47721_Brand",
          "product_sku": "47721",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "47721_Series",
          "product_sku": "47721",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "047722",
      "product_categoryId": "400071",
      "product_name": "Штанга душевая L-80 см, ручной душ 120 мм, 3 реж, шланг",
      "product_mpn": "8012003",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "45",
      "product_currency": "EUR",
      "product_price_online": "1328",
      "sourcePrice": "31.50",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_047722_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_047722_1.jpg"
      ],
      "description": "Душевой набор, ручной душ с 3-мя режимами струи, диаметр - 120 мм, душевая штанга 800 мм, шланг 1500 мм, цвет хром.\nматериал штанги: нержавеющая сталь",
      parameters: [
        {
          "parameter_id": "47722_000000150",
          "product_sku": "47722",
          "parameter_name": "Высота, мм",
          "parameter_value": "800"
        },
        {
          "parameter_id": "47722_000000151",
          "product_sku": "47722",
          "parameter_name": "Тип держателя",
          "parameter_value": "Штанга"
        },
        {
          "parameter_id": "47722_000000152",
          "product_sku": "47722",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "47722_000000153",
          "product_sku": "47722",
          "parameter_name": "Форма лейки ручного душа",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "47722_000000154",
          "product_sku": "47722",
          "parameter_name": "Мыльница",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "47722_000000155",
          "product_sku": "47722",
          "parameter_name": "Кол-во режимов ручного душа",
          "parameter_value": "3"
        },
        {
          "parameter_id": "47722_000000175",
          "product_sku": "47722",
          "parameter_name": "Диаметр/Диагональ, мм",
          "parameter_value": "120"
        },
        {
          "parameter_id": "47722_000000176",
          "product_sku": "47722",
          "parameter_name": "Способ переключения режимов",
          "parameter_value": "Кнопка"
        },
        {
          "parameter_id": "47722_000000177",
          "product_sku": "47722",
          "parameter_name": "Цвет диска ручного душа",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "47722_Brand",
          "product_sku": "47722",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "47722_Series",
          "product_sku": "47722",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "047723",
      "product_categoryId": "",
      "product_name": "Штанга душевая L-80 см",
      "product_mpn": "8000000",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "29",
      "product_currency": "EUR",
      "product_price_online": "856",
      "sourcePrice": "20.30",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_047723_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_047723_1.jpg"
      ],
      "description": "Душевая штанга 800 мм с держателем ручного душа, блистер, цвет хром.\nматериал штанги: нержавеющая сталь",
      parameters: [
        {
          "parameter_id": "47723_000000016",
          "product_sku": "47723",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "47723_000000025",
          "product_sku": "47723",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "47723_000000026",
          "product_sku": "47723",
          "parameter_name": "Страна производитель",
          "parameter_value": "Чехия"
        },
        {
          "parameter_id": "47723_Brand",
          "product_sku": "47723",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "47723_Series",
          "product_sku": "47723",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "047725",
      "product_categoryId": "",
      "product_name": "Штанга душевая L-60 см",
      "product_mpn": "6000000",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "20",
      "product_currency": "EUR",
      "product_price_online": "590",
      "sourcePrice": "14",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_047725_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_047725_1.jpg"
      ],
      "description": "Штанга душевая L-60 см, блистер, настенная, хром. Длина: 600 мм.\nматериал штанги: нержавеющая сталь",
      parameters: [
        {
          "parameter_id": "47725_000000015",
          "product_sku": "47725",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "600"
        },
        {
          "parameter_id": "47725_000000016",
          "product_sku": "47725",
          "parameter_name": "Монтаж",
          "parameter_value": ""
        },
        {
          "parameter_id": "47725_000000025",
          "product_sku": "47725",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "47725_000000026",
          "product_sku": "47725",
          "parameter_name": "Страна производитель",
          "parameter_value": "Чехия"
        },
        {
          "parameter_id": "47725_Brand",
          "product_sku": "47725",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "47725_Series",
          "product_sku": "47725",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "047729",
      "product_categoryId": "400071",
      "product_name": "Штанга душевая L-60 см, ручной душ, шланг",
      "product_mpn": "6008501",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "29",
      "product_currency": "EUR",
      "product_price_online": "856",
      "sourcePrice": "20.30",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_047729_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_047729_1.jpg"
      ],
      "description": "Душевой набор, ручной душ с одним режимом струи, \nдушевая штанга 600 мм, материал штанги: нержавеющая сталь\nшланг 1500 мм, цвет хром.",
      parameters: [
        {
          "parameter_id": "47729_000000150",
          "product_sku": "47729",
          "parameter_name": "Высота, мм",
          "parameter_value": "600"
        },
        {
          "parameter_id": "47729_000000151",
          "product_sku": "47729",
          "parameter_name": "Тип держателя",
          "parameter_value": "Штанга"
        },
        {
          "parameter_id": "47729_000000152",
          "product_sku": "47729",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "47729_000000153",
          "product_sku": "47729",
          "parameter_name": "Форма лейки ручного душа",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "47729_000000154",
          "product_sku": "47729",
          "parameter_name": "Мыльница",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "47729_000000155",
          "product_sku": "47729",
          "parameter_name": "Кол-во режимов ручного душа",
          "parameter_value": "1"
        },
        {
          "parameter_id": "47729_000000175",
          "product_sku": "47729",
          "parameter_name": "Диаметр/Диагональ, мм",
          "parameter_value": "85"
        },
        {
          "parameter_id": "47729_000000176",
          "product_sku": "47729",
          "parameter_name": "Способ переключения режимов",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "47729_000000177",
          "product_sku": "47729",
          "parameter_name": "Цвет диска ручного душа",
          "parameter_value": "Серый"
        },
        {
          "parameter_id": "47729_Brand",
          "product_sku": "47729",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "47729_Series",
          "product_sku": "47729",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "047775",
      "product_categoryId": "180004",
      "product_name": "ARCHITECTURA умывальник 61,5*41,5см овальный,  для установки на столешницу",
      "product_mpn": "41666001",
      "manufacturer_name": "VILLEROY & BOCH",
      "product_seria": "ARCHITECTURA",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29
      },
      "exchangeRate_product_price_online": {
        "EUR": 29
      },
      "product_price": "145",
      "product_currency": "EUR",
      "product_price_old": "287.0000",
      "product_price_online": "4205",
      "sourcePrice": "177.94",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_047775_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_047775_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_047775_2.jpg"
      ],
      "description": "Умывальник для установки на столешницу,  615*415 мм, овальный, санфаянс, с переливом. Без отверстия для смесителя.",
      parameters: [
        {
          "parameter_id": "47775_000000058",
          "product_sku": "47775",
          "parameter_name": "Ширина",
          "parameter_value": "615"
        },
        {
          "parameter_id": "47775_000000059",
          "product_sku": "47775",
          "parameter_name": "Глубина",
          "parameter_value": "415"
        },
        {
          "parameter_id": "47775_000000060",
          "product_sku": "47775",
          "parameter_name": "Высота",
          "parameter_value": "190"
        },
        {
          "parameter_id": "47775_000000061",
          "product_sku": "47775",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной в столешницу"
        },
        {
          "parameter_id": "47775_000000062",
          "product_sku": "47775",
          "parameter_name": "Форма",
          "parameter_value": "Овальная"
        },
        {
          "parameter_id": "47775_000000063",
          "product_sku": "47775",
          "parameter_name": "Особенности формы",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "47775_000000064",
          "product_sku": "47775",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "47775_000000065",
          "product_sku": "47775",
          "parameter_name": "Комплектация",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "47775_000000066",
          "product_sku": "47775",
          "parameter_name": "Материал",
          "parameter_value": "Керамика"
        },
        {
          "parameter_id": "47775_000000067",
          "product_sku": "47775",
          "parameter_name": "Перелив",
          "parameter_value": "Без перелива"
        },
        {
          "parameter_id": "47775_000000068",
          "product_sku": "47775",
          "parameter_name": "Отверстия под смеситель",
          "parameter_value": "Без отверстия"
        },
        {
          "parameter_id": "47775_000000069",
          "product_sku": "47775",
          "parameter_name": "Кол-во смесителей",
          "parameter_value": "Без отверстия"
        },
        {
          "parameter_id": "47775_000000070",
          "product_sku": "47775",
          "parameter_name": "Особенности",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "47775_Brand",
          "product_sku": "47775",
          "parameter_name": "Бренд",
          "parameter_value": "VILLEROY & BOCH"
        },
        {
          "parameter_id": "47775_Series",
          "product_sku": "47775",
          "parameter_name": "Серия",
          "parameter_value": "ARCHITECTURA"
        }
      ]
    },
    {
      "product_sku": "047828",
      "product_categoryId": "180004",
      "product_name": "ARCHITECTURA умывальник 61,5*41,5см прямоугольный,  для установки на столешницу",
      "product_mpn": "41676001",
      "manufacturer_name": "VILLEROY & BOCH",
      "product_seria": "ARCHITECTURA",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29
      },
      "exchangeRate_product_price_online": {
        "EUR": 29
      },
      "product_price": "170",
      "product_currency": "EUR",
      "product_price_old": "287.0000",
      "product_price_online": "4930",
      "sourcePrice": "177.94",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_047828_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_047828_1.jpg"
      ],
      "description": "Умывальник для установки на столешницу, прямоугольная модель. Размер: 615*415мм. С переливом. Материал Санфарфор. Без предусмотренного для смесителя отверстия.",
      parameters: [
        {
          "parameter_id": "47828_000000058",
          "product_sku": "47828",
          "parameter_name": "Ширина",
          "parameter_value": "615"
        },
        {
          "parameter_id": "47828_000000059",
          "product_sku": "47828",
          "parameter_name": "Глубина",
          "parameter_value": "415"
        },
        {
          "parameter_id": "47828_000000060",
          "product_sku": "47828",
          "parameter_name": "Высота",
          "parameter_value": "190"
        },
        {
          "parameter_id": "47828_000000061",
          "product_sku": "47828",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной в столешницу"
        },
        {
          "parameter_id": "47828_000000062",
          "product_sku": "47828",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "47828_000000063",
          "product_sku": "47828",
          "parameter_name": "Особенности формы",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "47828_000000064",
          "product_sku": "47828",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "47828_000000065",
          "product_sku": "47828",
          "parameter_name": "Комплектация",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "47828_000000066",
          "product_sku": "47828",
          "parameter_name": "Материал",
          "parameter_value": "Керамика"
        },
        {
          "parameter_id": "47828_000000067",
          "product_sku": "47828",
          "parameter_name": "Перелив",
          "parameter_value": "Без перелива"
        },
        {
          "parameter_id": "47828_000000068",
          "product_sku": "47828",
          "parameter_name": "Отверстия под смеситель",
          "parameter_value": "Без отверстия"
        },
        {
          "parameter_id": "47828_000000069",
          "product_sku": "47828",
          "parameter_name": "Кол-во смесителей",
          "parameter_value": "Без отверстия"
        },
        {
          "parameter_id": "47828_000000070",
          "product_sku": "47828",
          "parameter_name": "Особенности",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "47828_Brand",
          "product_sku": "47828",
          "parameter_name": "Бренд",
          "parameter_value": "VILLEROY & BOCH"
        },
        {
          "parameter_id": "47828_Series",
          "product_sku": "47828",
          "parameter_name": "Серия",
          "parameter_value": "ARCHITECTURA"
        }
      ]
    },
    {
      "product_sku": "047831",
      "product_categoryId": "600086",
      "product_name": "Сифон к поддону 10-22-1010",
      "product_mpn": "10-22-drain",
      "manufacturer_name": "VOLLE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "20",
      "product_currency": "EUR",
      "product_price_online": "590",
      "sourcePrice": "13",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_047831_0.jpg"
      ],
      "description": "Пластиковый сифон для душевого поддона 10-22-1010, круглая форма, цвет белый.",
      parameters: [
        {
          "parameter_id": "47831_000000006",
          "product_sku": "47831",
          "parameter_name": "Диаметр (мм)",
          "parameter_value": "90"
        },
        {
          "parameter_id": "47831_000000013",
          "product_sku": "47831",
          "parameter_name": "Материал",
          "parameter_value": "Пластик"
        },
        {
          "parameter_id": "47831_000000015",
          "product_sku": "47831",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "0"
        },
        {
          "parameter_id": "47831_000000018",
          "product_sku": "47831",
          "parameter_name": "Форма",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "47831_000000025",
          "product_sku": "47831",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "47831_Brand",
          "product_sku": "47831",
          "parameter_name": "Бренд",
          "parameter_value": "VOLLE"
        },
        {
          "parameter_id": "47831_Series",
          "product_sku": "47831",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "047832",
      "product_categoryId": "40003",
      "product_name": "PRAHA new смеситель для умывальника с донным клапаном, хром, 35 мм",
      "product_mpn": "05030PP",
      "manufacturer_name": "IMPRESE",
      "product_seria": "PRAHA new",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "44",
      "product_currency": "EUR",
      "product_price_online": "1298",
      "sourcePrice": "30.80",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_047832_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_047832_1.jpg"
      ],
      "description": "Смеситель для раковины с донным клапаном, хром, 35 мм, настольный, однорычажный\nМодель установленного картриджа Sedal EN- 35 С/D",
      parameters: [
        {
          "parameter_id": "47832_000000117",
          "product_sku": "47832",
          "parameter_name": "Длина излива",
          "parameter_value": "106"
        },
        {
          "parameter_id": "47832_000000118",
          "product_sku": "47832",
          "parameter_name": "Высота излива",
          "parameter_value": "108"
        },
        {
          "parameter_id": "47832_000000119",
          "product_sku": "47832",
          "parameter_name": "Высота смесителя",
          "parameter_value": "166"
        },
        {
          "parameter_id": "47832_000000120",
          "product_sku": "47832",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной"
        },
        {
          "parameter_id": "47832_000000121",
          "product_sku": "47832",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "47832_000000122",
          "product_sku": "47832",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "47832_000000123",
          "product_sku": "47832",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "47832_000000124",
          "product_sku": "47832",
          "parameter_name": "Наличие донного клапана",
          "parameter_value": "Да"
        },
        {
          "parameter_id": "47832_000000125",
          "product_sku": "47832",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "1"
        },
        {
          "parameter_id": "47832_Brand",
          "product_sku": "47832",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "47832_Series",
          "product_sku": "47832",
          "parameter_name": "Серия",
          "parameter_value": "PRAHA new"
        }
      ]
    },
    {
      "product_sku": "047842",
      "product_categoryId": "400032",
      "product_name": "VALTICE смеситель для биде, хром, 35 мм",
      "product_mpn": "40320",
      "manufacturer_name": "IMPRESE",
      "product_seria": "VALTICE",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "64",
      "product_currency": "EUR",
      "product_price_online": "1888",
      "sourcePrice": "44.80",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_047842_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_047842_1.jpg"
      ],
      "description": "Смеситель для биде, настольный, однорычажный, хром, 35мм",
      parameters: [
        {
          "parameter_id": "47842_000000087",
          "product_sku": "47842",
          "parameter_name": "Длина излива",
          "parameter_value": "12,1"
        },
        {
          "parameter_id": "47842_000000088",
          "product_sku": "47842",
          "parameter_name": "Высота излива",
          "parameter_value": "14,4"
        },
        {
          "parameter_id": "47842_000000089",
          "product_sku": "47842",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "47842_000000090",
          "product_sku": "47842",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "47842_000000091",
          "product_sku": "47842",
          "parameter_name": "Наличие донного клапана",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "47842_000000092",
          "product_sku": "47842",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "1"
        },
        {
          "parameter_id": "47842_Brand",
          "product_sku": "47842",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "47842_Series",
          "product_sku": "47842",
          "parameter_name": "Серия",
          "parameter_value": "VALTICE"
        }
      ]
    },
    {
      "product_sku": "047876",
      "product_categoryId": "40003",
      "product_name": "Eurodisc Joy смеситель для умывальника, однорычажный",
      "product_mpn": "23425000",
      "manufacturer_name": "GROHE",
      "product_seria": "EURODISC JOY",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "159.29",
      "product_currency": "EUR",
      "product_price_old": "215.0000",
      "product_price_online": "4699",
      "sourcePrice": "111",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_047876_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_047876_1.jpg"
      ],
      "description": "Смеситель для раковины однорычажный, донный клапан 1 1/4 дюйма, аэратор с силиконовыми вставками, фиксированный излив, керамический картридж, подводка воды гибкая 350 мм с накидной гайкой 3/8 дюйма, ограничитель расхода воды в комплекте, система быстрого монтажа",
      parameters: [
        {
          "parameter_id": "47876_000000117",
          "product_sku": "47876",
          "parameter_name": "Длина излива",
          "parameter_value": "116"
        },
        {
          "parameter_id": "47876_000000118",
          "product_sku": "47876",
          "parameter_name": "Высота излива",
          "parameter_value": "88"
        },
        {
          "parameter_id": "47876_000000119",
          "product_sku": "47876",
          "parameter_name": "Высота смесителя",
          "parameter_value": "205"
        },
        {
          "parameter_id": "47876_000000120",
          "product_sku": "47876",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной"
        },
        {
          "parameter_id": "47876_000000121",
          "product_sku": "47876",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "47876_000000122",
          "product_sku": "47876",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "47876_000000123",
          "product_sku": "47876",
          "parameter_name": "Тип управления",
          "parameter_value": "Джойстик"
        },
        {
          "parameter_id": "47876_000000124",
          "product_sku": "47876",
          "parameter_name": "Наличие донного клапана",
          "parameter_value": "Да"
        },
        {
          "parameter_id": "47876_000000125",
          "product_sku": "47876",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "1"
        },
        {
          "parameter_id": "47876_Brand",
          "product_sku": "47876",
          "parameter_name": "Бренд",
          "parameter_value": "GROHE"
        },
        {
          "parameter_id": "47876_Series",
          "product_sku": "47876",
          "parameter_name": "Серия",
          "parameter_value": "EURODISC JOY"
        }
      ]
    },
    {
      "product_sku": "047877",
      "product_categoryId": "40003",
      "product_name": "Eurodisc Joy смеситель для умывальника, однорычажный, цвет белая луна",
      "product_mpn": "23425LS0",
      "manufacturer_name": "GROHE",
      "product_seria": "EURODISC JOY",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "199.97",
      "product_currency": "EUR",
      "product_price_old": "283.0000",
      "product_price_online": "5899",
      "sourcePrice": "139",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_047877_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_047877_1.jpg"
      ],
      "description": "Смеситель для раковины однорычажный, донный клапан 1 1/4 дюйма, аэратор с силиконовыми вставками легко чистится, фиксированный излив, керамический картридж, подводка воды гибкая 350 мм с накидной гайкой 3/8 дюйма, ограничитель расхода воды в комплекте, система быстрого монтажа, цвет - белый.",
      parameters: [
        {
          "parameter_id": "47877_000000117",
          "product_sku": "47877",
          "parameter_name": "Длина излива",
          "parameter_value": "116"
        },
        {
          "parameter_id": "47877_000000118",
          "product_sku": "47877",
          "parameter_name": "Высота излива",
          "parameter_value": "88"
        },
        {
          "parameter_id": "47877_000000119",
          "product_sku": "47877",
          "parameter_name": "Высота смесителя",
          "parameter_value": "205"
        },
        {
          "parameter_id": "47877_000000120",
          "product_sku": "47877",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной"
        },
        {
          "parameter_id": "47877_000000121",
          "product_sku": "47877",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "47877_000000122",
          "product_sku": "47877",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "47877_000000123",
          "product_sku": "47877",
          "parameter_name": "Тип управления",
          "parameter_value": "Джойстик"
        },
        {
          "parameter_id": "47877_000000124",
          "product_sku": "47877",
          "parameter_name": "Наличие донного клапана",
          "parameter_value": "Да"
        },
        {
          "parameter_id": "47877_000000125",
          "product_sku": "47877",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "1"
        },
        {
          "parameter_id": "47877_Brand",
          "product_sku": "47877",
          "parameter_name": "Бренд",
          "parameter_value": "GROHE"
        },
        {
          "parameter_id": "47877_Series",
          "product_sku": "47877",
          "parameter_name": "Серия",
          "parameter_value": "EURODISC JOY"
        }
      ]
    },
    {
      "product_sku": "047880",
      "product_categoryId": "400010",
      "product_name": "Grohe шланг душевой металлический, 1500 мм",
      "product_mpn": "28105000",
      "manufacturer_name": "GROHE",
      "product_seria": "GROHE",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "16.92",
      "product_currency": "EUR",
      "product_price_old": "23.0000",
      "product_price_online": "499",
      "sourcePrice": "11.82",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_047880_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_047880_1.jpg"
      ],
      "description": "Душевой шланг металлический, 1500 мм, 1/2 x 1/2",
      parameters: [
        {
          "parameter_id": "47880_000000013",
          "product_sku": "47880",
          "parameter_name": "Материал",
          "parameter_value": "Металл"
        },
        {
          "parameter_id": "47880_000000015",
          "product_sku": "47880",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "1 500"
        },
        {
          "parameter_id": "47880_000000025",
          "product_sku": "47880",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "47880_000000026",
          "product_sku": "47880",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "47880_Brand",
          "product_sku": "47880",
          "parameter_name": "Бренд",
          "parameter_value": "GROHE"
        },
        {
          "parameter_id": "47880_Series",
          "product_sku": "47880",
          "parameter_name": "Серия",
          "parameter_value": "GROHE"
        }
      ]
    },
    {
      "product_sku": "047884",
      "product_categoryId": "400053",
      "product_name": "PRAHA new смеситель скрытого монтажа для душа",
      "product_mpn": "VR-15030(Z)",
      "manufacturer_name": "IMPRESE",
      "product_seria": "PRAHA new",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "42",
      "product_currency": "EUR",
      "product_price_online": "1239",
      "sourcePrice": "29.40",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_047884_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_047884_1.jpg"
      ],
      "description": "Смеситель для душа, встраиваемый в стену, однорычажный, хром\nМодель установленного картриджа Sedal EN- 35 S/D AZ",
      parameters: [
        {
          "parameter_id": "47884_000000101",
          "product_sku": "47884",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "47884_000000102",
          "product_sku": "47884",
          "parameter_name": "Комплектация",
          "parameter_value": "Внутренняя часть"
        },
        {
          "parameter_id": "47884_000000103",
          "product_sku": "47884",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "47884_000000104",
          "product_sku": "47884",
          "parameter_name": "С полочкой",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "47884_000000105",
          "product_sku": "47884",
          "parameter_name": "Положение регулятора",
          "parameter_value": "Спереди по центру"
        },
        {
          "parameter_id": "47884_000000129",
          "product_sku": "47884",
          "parameter_name": "Монтаж",
          "parameter_value": "Скрытый"
        },
        {
          "parameter_id": "47884_000000130",
          "product_sku": "47884",
          "parameter_name": "Форма накладки",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "47884_Brand",
          "product_sku": "47884",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "47884_Series",
          "product_sku": "47884",
          "parameter_name": "Серия",
          "parameter_value": "PRAHA new"
        }
      ]
    },
    {
      "product_sku": "047888",
      "product_categoryId": "400068",
      "product_name": "Talis Select S Смеситель для кухни 300, однорычажный, с поворотным изливом",
      "product_mpn": "72820000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "TALIS SELECT S",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "364.10",
      "product_currency": "EUR",
      "product_price_online": "10923",
      "sourcePrice": "236.67",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_047888_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_047888_1.jpg"
      ],
      "description": "Смеситель для кухни, однорычажный, поворотный излив, с кнопкой управления",
      parameters: [
        {
          "parameter_id": "47888_000000106",
          "product_sku": "47888",
          "parameter_name": "Длина излива",
          "parameter_value": "208"
        },
        {
          "parameter_id": "47888_000000107",
          "product_sku": "47888",
          "parameter_name": "Высота излива",
          "parameter_value": "288"
        },
        {
          "parameter_id": "47888_000000108",
          "product_sku": "47888",
          "parameter_name": "Высота смесителя",
          "parameter_value": "339"
        },
        {
          "parameter_id": "47888_000000109",
          "product_sku": "47888",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной"
        },
        {
          "parameter_id": "47888_000000110",
          "product_sku": "47888",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "47888_000000111",
          "product_sku": "47888",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "47888_000000112",
          "product_sku": "47888",
          "parameter_name": "Тип излива",
          "parameter_value": "Г-образный"
        },
        {
          "parameter_id": "47888_000000113",
          "product_sku": "47888",
          "parameter_name": "Выдвижной излив",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "47888_000000114",
          "product_sku": "47888",
          "parameter_name": "Вывод для фильтрованной в",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "47888_000000115",
          "product_sku": "47888",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "47888_000000116",
          "product_sku": "47888",
          "parameter_name": "Особенности",
          "parameter_value": "Доп кнопка"
        },
        {
          "parameter_id": "47888_Brand",
          "product_sku": "47888",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "47888_Series",
          "product_sku": "47888",
          "parameter_name": "Серия",
          "parameter_value": "TALIS SELECT S"
        }
      ]
    },
    {
      "product_sku": "047941",
      "product_categoryId": "400013",
      "product_name": "Axor Аэратор з/ч",
      "product_mpn": "95379000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "AXOR",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "22.40",
      "product_currency": "EUR",
      "product_price_online": "638",
      "sourcePrice": "14.56",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_047941_0.jpg"
      ],
      "description": "Аэратор. Регулятор струи для смесителя.",
      parameters: [
        {
          "parameter_id": "47941_000000026",
          "product_sku": "47941",
          "parameter_name": "Страна производитель",
          "parameter_value": "Германия"
        },
        {
          "parameter_id": "47941_Brand",
          "product_sku": "47941",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "47941_Series",
          "product_sku": "47941",
          "parameter_name": "Серия",
          "parameter_value": "AXOR"
        }
      ]
    },
    {
      "product_sku": "048945",
      "product_categoryId": "400042",
      "product_name": "EUROSMART смеситель для ванны, однорычажный",
      "product_mpn": "33300002",
      "manufacturer_name": "GROHE",
      "product_seria": "EUROSMART",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "71.15",
      "product_currency": "EUR",
      "product_price_old": "109.0000",
      "product_price_online": "2099",
      "sourcePrice": "54",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_048945_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_048945_1.jpg"
      ],
      "description": "Однорычажный смеситель для ванны и душа, без душевого набора, переключатель воды ванна/душ рычаг полуавтоматический, расход воды: 13-20 л/мин, подключение для душевого шланга 1/2 дюйма, подводка воды S-крепление с накидной гайкой 1/2 дюйма, аэратор стандартный, излив фиксированный, керамический картридж 35 мм, материал - латунь, цвет - хром",
      parameters: [
        {
          "parameter_id": "48945_000000093",
          "product_sku": "48945",
          "parameter_name": "Длина излива",
          "parameter_value": "126"
        },
        {
          "parameter_id": "48945_000000094",
          "product_sku": "48945",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "48945_000000095",
          "product_sku": "48945",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "48945_000000096",
          "product_sku": "48945",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "48945_000000097",
          "product_sku": "48945",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "48945_000000098",
          "product_sku": "48945",
          "parameter_name": "Тип переключателя ванна/душ",
          "parameter_value": "Выжимной"
        },
        {
          "parameter_id": "48945_000000099",
          "product_sku": "48945",
          "parameter_name": "Повротный излив",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "48945_000000100",
          "product_sku": "48945",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "2"
        },
        {
          "parameter_id": "48945_000000126",
          "product_sku": "48945",
          "parameter_name": "Кол-во потребителей",
          "parameter_value": "2"
        },
        {
          "parameter_id": "48945_000000128",
          "product_sku": "48945",
          "parameter_name": "Форма накладки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "48945_Brand",
          "product_sku": "48945",
          "parameter_name": "Бренд",
          "parameter_value": "GROHE"
        },
        {
          "parameter_id": "48945_Series",
          "product_sku": "48945",
          "parameter_name": "Серия",
          "parameter_value": "EUROSMART"
        }
      ]
    },
    {
      "product_sku": "048946",
      "product_categoryId": "400068",
      "product_name": "EUROSMART New смеситель для кухни, однорычажный",
      "product_mpn": "33202002",
      "manufacturer_name": "GROHE",
      "product_seria": "EUROSMART NEW",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "67.76",
      "product_currency": "EUR",
      "product_price_old": "112.0000",
      "product_price_online": "1999",
      "sourcePrice": "55.20",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_048946_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_048946_1.jpg"
      ],
      "description": "Однорычажный кухонный смеситель, расход воды 12 л/мин, комплект поставки: ограничитель температуры воды, материал - латунь, цвет - хром, поворотный излив.",
      parameters: [
        {
          "parameter_id": "48946_000000106",
          "product_sku": "48946",
          "parameter_name": "Длина излива",
          "parameter_value": "182"
        },
        {
          "parameter_id": "48946_000000107",
          "product_sku": "48946",
          "parameter_name": "Высота излива",
          "parameter_value": "213"
        },
        {
          "parameter_id": "48946_000000108",
          "product_sku": "48946",
          "parameter_name": "Высота смесителя",
          "parameter_value": "338"
        },
        {
          "parameter_id": "48946_000000109",
          "product_sku": "48946",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной"
        },
        {
          "parameter_id": "48946_000000110",
          "product_sku": "48946",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "48946_000000111",
          "product_sku": "48946",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "48946_000000112",
          "product_sku": "48946",
          "parameter_name": "Тип излива",
          "parameter_value": "U-образный"
        },
        {
          "parameter_id": "48946_000000113",
          "product_sku": "48946",
          "parameter_name": "Выдвижной излив",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "48946_000000114",
          "product_sku": "48946",
          "parameter_name": "Вывод для фильтрованной в",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "48946_000000115",
          "product_sku": "48946",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "48946_000000116",
          "product_sku": "48946",
          "parameter_name": "Особенности",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "48946_Brand",
          "product_sku": "48946",
          "parameter_name": "Бренд",
          "parameter_value": "GROHE"
        },
        {
          "parameter_id": "48946_Series",
          "product_sku": "48946",
          "parameter_name": "Серия",
          "parameter_value": "EUROSMART NEW"
        }
      ]
    },
    {
      "product_sku": "048949",
      "product_categoryId": "40003",
      "product_name": "EUROSMART смеситель для умывальника, однорычажный",
      "product_mpn": "33265002",
      "manufacturer_name": "GROHE",
      "product_seria": "EUROSMART",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "54.20",
      "product_currency": "EUR",
      "product_price_old": "90.0000",
      "product_price_online": "1599",
      "sourcePrice": "44",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_048949_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_048949_1.jpg"
      ],
      "description": "Смеситель для раковины, настольный, однорычажный, донный клапан, хром",
      parameters: [
        {
          "parameter_id": "48949_000000117",
          "product_sku": "48949",
          "parameter_name": "Длина излива",
          "parameter_value": "106"
        },
        {
          "parameter_id": "48949_000000118",
          "product_sku": "48949",
          "parameter_name": "Высота излива",
          "parameter_value": "56"
        },
        {
          "parameter_id": "48949_000000119",
          "product_sku": "48949",
          "parameter_name": "Высота смесителя",
          "parameter_value": "146"
        },
        {
          "parameter_id": "48949_000000120",
          "product_sku": "48949",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной"
        },
        {
          "parameter_id": "48949_000000121",
          "product_sku": "48949",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "48949_000000122",
          "product_sku": "48949",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "48949_000000123",
          "product_sku": "48949",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "48949_000000124",
          "product_sku": "48949",
          "parameter_name": "Наличие донного клапана",
          "parameter_value": "Да"
        },
        {
          "parameter_id": "48949_000000125",
          "product_sku": "48949",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "1"
        },
        {
          "parameter_id": "48949_Brand",
          "product_sku": "48949",
          "parameter_name": "Бренд",
          "parameter_value": "GROHE"
        },
        {
          "parameter_id": "48949_Series",
          "product_sku": "48949",
          "parameter_name": "Серия",
          "parameter_value": "EUROSMART"
        }
      ]
    },
    {
      "product_sku": "048972",
      "product_categoryId": "800035",
      "product_name": "CASE шкаф 895*520*230/450 мм, с компактным сифоном, белая",
      "product_mpn": "H4052310754631",
      "manufacturer_name": "LAUFEN",
      "product_seria": "CASE",
      "product_status": "Распродажа",
      "product_price": "465.79",
      "product_currency": "EUR",
      "product_price_online": "465.79",
      "sourcePrice": "265.50",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_048972_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_048972_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_048972_2.jpg"
      ],
      "description": "CASE шкаф 895*520*230/450 мм, с компактным сифоном, белая, материал МДФ",
      parameters: [
        {
          "parameter_id": "48972_000000001",
          "product_sku": "48972",
          "parameter_name": "Ширина",
          "parameter_value": "895"
        },
        {
          "parameter_id": "48972_000000010",
          "product_sku": "48972",
          "parameter_name": "Тип дверей",
          "parameter_value": "Выдвижные"
        },
        {
          "parameter_id": "48972_000000013",
          "product_sku": "48972",
          "parameter_name": "Материал",
          "parameter_value": "МДФ"
        },
        {
          "parameter_id": "48972_000000014",
          "product_sku": "48972",
          "parameter_name": "Глубина",
          "parameter_value": "520"
        },
        {
          "parameter_id": "48972_000000015",
          "product_sku": "48972",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "230"
        },
        {
          "parameter_id": "48972_000000016",
          "product_sku": "48972",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "48972_000000025",
          "product_sku": "48972",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Белый матовый"
        },
        {
          "parameter_id": "48972_000000026",
          "product_sku": "48972",
          "parameter_name": "Страна производитель",
          "parameter_value": "Швейцария"
        },
        {
          "parameter_id": "48972_Brand",
          "product_sku": "48972",
          "parameter_name": "Бренд",
          "parameter_value": "LAUFEN"
        },
        {
          "parameter_id": "48972_Series",
          "product_sku": "48972",
          "parameter_name": "Серия",
          "parameter_value": "CASE"
        }
      ]
    },
    {
      "product_sku": "054111",
      "product_categoryId": "400068",
      "product_name": "LOTTA смеситель для кухни 55402-SS, сталь, 40 мм",
      "product_mpn": "55402-SS",
      "manufacturer_name": "IMPRESE",
      "product_seria": "LOTTA",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "92",
      "product_currency": "EUR",
      "product_price_online": "2714",
      "sourcePrice": "64.40",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054111_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054111_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054111_2.jpg"
      ],
      "description": "Однорычажный смеситель для кухни, высокий нос, сатин, 35 мм; керамический узел смешивания, расход воды до 7 л/мин, аэратор, подходит для проточных нагревателей\nМодель установленного картриджа Sedal D-40AZSD",
      parameters: [
        {
          "parameter_id": "54111_000000106",
          "product_sku": "54111",
          "parameter_name": "Длина излива",
          "parameter_value": "223"
        },
        {
          "parameter_id": "54111_000000107",
          "product_sku": "54111",
          "parameter_name": "Высота излива",
          "parameter_value": "188"
        },
        {
          "parameter_id": "54111_000000108",
          "product_sku": "54111",
          "parameter_name": "Высота смесителя",
          "parameter_value": "257"
        },
        {
          "parameter_id": "54111_000000109",
          "product_sku": "54111",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной"
        },
        {
          "parameter_id": "54111_000000110",
          "product_sku": "54111",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Сатин"
        },
        {
          "parameter_id": "54111_000000111",
          "product_sku": "54111",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "54111_000000112",
          "product_sku": "54111",
          "parameter_name": "Тип излива",
          "parameter_value": "Длинный"
        },
        {
          "parameter_id": "54111_000000113",
          "product_sku": "54111",
          "parameter_name": "Выдвижной излив",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "54111_000000114",
          "product_sku": "54111",
          "parameter_name": "Вывод для фильтрованной в",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "54111_000000115",
          "product_sku": "54111",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "54111_000000116",
          "product_sku": "54111",
          "parameter_name": "Особенности",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "54111_Brand",
          "product_sku": "54111",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "54111_Series",
          "product_sku": "54111",
          "parameter_name": "Серия",
          "parameter_value": "LOTTA"
        }
      ]
    },
    {
      "product_sku": "054140",
      "product_categoryId": "800063",
      "product_name": "GAP тумба 80*44*64,5см, с умывальником, 2 выдвижных ящика, цвет белый глянец",
      "product_mpn": "A855998806",
      "manufacturer_name": "ROCA",
      "product_seria": "GAP",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "569.71",
      "product_currency": "EUR",
      "product_price_online": "16806",
      "sourcePrice": "427.28",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054140_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054140_1.jpg"
      ],
      "description": "Габариты: 800х440х645 мм.\nМонтаж: подвесной.\nМатериал: MDF\n2 выдвижных ящика с механизмом плавного закрывания.\nДополнительно возможна установка на 2 регулируемые металлические ножки #А816405001 – докупаются отдельно.",
      parameters: [
        {
          "parameter_id": "54140_000000001",
          "product_sku": "54140",
          "parameter_name": "Ширина",
          "parameter_value": "800"
        },
        {
          "parameter_id": "54140_000000009",
          "product_sku": "54140",
          "parameter_name": "Комплектация",
          "parameter_value": "Тумба+раковина"
        },
        {
          "parameter_id": "54140_000000010",
          "product_sku": "54140",
          "parameter_name": "Тип дверей",
          "parameter_value": "Выдвижные"
        },
        {
          "parameter_id": "54140_000000013",
          "product_sku": "54140",
          "parameter_name": "Материал",
          "parameter_value": "МДФ"
        },
        {
          "parameter_id": "54140_000000014",
          "product_sku": "54140",
          "parameter_name": "Глубина",
          "parameter_value": "440"
        },
        {
          "parameter_id": "54140_000000015",
          "product_sku": "54140",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "645"
        },
        {
          "parameter_id": "54140_000000016",
          "product_sku": "54140",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "54140_000000018",
          "product_sku": "54140",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "54140_000000023",
          "product_sku": "54140",
          "parameter_name": "Тип установки смесителя",
          "parameter_value": "1 отверстие"
        },
        {
          "parameter_id": "54140_000000025",
          "product_sku": "54140",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Белый глянец"
        },
        {
          "parameter_id": "54140_000000029",
          "product_sku": "54140",
          "parameter_name": "Перелив",
          "parameter_value": "С переливом"
        },
        {
          "parameter_id": "54140_Brand",
          "product_sku": "54140",
          "parameter_name": "Бренд",
          "parameter_value": "ROCA"
        },
        {
          "parameter_id": "54140_Series",
          "product_sku": "54140",
          "parameter_name": "Серия",
          "parameter_value": "GAP"
        }
      ]
    },
    {
      "product_sku": "054195",
      "product_categoryId": "500040",
      "product_name": "HALL ванна 180*80см прямоугольная, для двоих, с ножками, с 2-мя подголовниками",
      "product_mpn": "A248163000",
      "manufacturer_name": "ROCA",
      "product_seria": "HALL",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "538.67",
      "product_currency": "EUR",
      "product_price_online": "15891",
      "sourcePrice": "387.84",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054195_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054195_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054195_2.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054195_3.jpg"
      ],
      "description": "Профильная поддержка плечей, возможность комплектации панелями и сливом-переливом",
      parameters: [
        {
          "parameter_id": "54195_Brand",
          "product_sku": "54195",
          "parameter_name": "Бренд",
          "parameter_value": "ROCA"
        },
        {
          "parameter_id": "54195_Series",
          "product_sku": "54195",
          "parameter_name": "Серия",
          "parameter_value": "HALL"
        }
      ]
    },
    {
      "product_sku": "054204",
      "product_categoryId": "600066",
      "product_name": "TERRAN поддон 90*90см ультраплоский, из искусственного камня Stonex, в комплекте с трапом и сифоном, цвет цемент",
      "product_mpn": "AP0338438401300",
      "manufacturer_name": "ROCA",
      "product_seria": "TERRAN",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "331.42",
      "product_currency": "EUR",
      "product_price_online": "9777",
      "sourcePrice": "231.99",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054204_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054204_1.jpg"
      ],
      "description": "TERRAN поддон 900*900*28 мм, из искусственного камня, ультраплоский, цвет цемент.",
      parameters: [
        {
          "parameter_id": "54204_000000001",
          "product_sku": "54204",
          "parameter_name": "Ширина",
          "parameter_value": "900"
        },
        {
          "parameter_id": "54204_000000011",
          "product_sku": "54204",
          "parameter_name": "Тип поддона",
          "parameter_value": "Мелкий"
        },
        {
          "parameter_id": "54204_000000013",
          "product_sku": "54204",
          "parameter_name": "Материал",
          "parameter_value": "Искусственный камень"
        },
        {
          "parameter_id": "54204_000000014",
          "product_sku": "54204",
          "parameter_name": "Глубина",
          "parameter_value": "900"
        },
        {
          "parameter_id": "54204_000000015",
          "product_sku": "54204",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "28"
        },
        {
          "parameter_id": "54204_000000018",
          "product_sku": "54204",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "54204_Brand",
          "product_sku": "54204",
          "parameter_name": "Бренд",
          "parameter_value": "ROCA"
        },
        {
          "parameter_id": "54204_Series",
          "product_sku": "54204",
          "parameter_name": "Серия",
          "parameter_value": "TERRAN"
        }
      ]
    },
    {
      "product_sku": "054259",
      "product_categoryId": "400070",
      "product_name": "CROMETTA E 240 1jet верхний душ",
      "product_mpn": "26726000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "Crometta E",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "195.80",
      "product_currency": "EUR",
      "product_price_online": "5874",
      "sourcePrice": "127.27",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054259_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054259_1.jpg"
      ],
      "description": "Размер душевого диска: 240 x 240 мм, тип струи: Rain, расход воды для струи Rain (при 3 бар): 18 л / мин, полностью хромированный душевой диск, материал душевого диска: пластик, монтаж: потолок или стена, соединительная резьба G ½",
      parameters: [
        {
          "parameter_id": "54259_000000142",
          "product_sku": "54259",
          "parameter_name": "Длина лейки верхнего душа, мм",
          "parameter_value": "240"
        },
        {
          "parameter_id": "54259_000000143",
          "product_sku": "54259",
          "parameter_name": "Длина кронштейна (от стены), мм",
          "parameter_value": "0"
        },
        {
          "parameter_id": "54259_000000144",
          "product_sku": "54259",
          "parameter_name": "Ширина лейки верхнего душа, мм",
          "parameter_value": "240"
        },
        {
          "parameter_id": "54259_000000145",
          "product_sku": "54259",
          "parameter_name": "Материал лейки",
          "parameter_value": "Пластик"
        },
        {
          "parameter_id": "54259_000000146",
          "product_sku": "54259",
          "parameter_name": "Форма лейки верхнего душа",
          "parameter_value": "Квадратная"
        },
        {
          "parameter_id": "54259_000000147",
          "product_sku": "54259",
          "parameter_name": "Монтаж",
          "parameter_value": "Универсальный"
        },
        {
          "parameter_id": "54259_000000148",
          "product_sku": "54259",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "54259_000000149",
          "product_sku": "54259",
          "parameter_name": "Кол-во режимов верхнего душа",
          "parameter_value": "1"
        },
        {
          "parameter_id": "54259_Brand",
          "product_sku": "54259",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "54259_Series",
          "product_sku": "54259",
          "parameter_name": "Серия",
          "parameter_value": "Crometta E"
        }
      ]
    },
    {
      "product_sku": "054261",
      "product_categoryId": "400072",
      "product_name": "CROMETTA E 240 1jet Showerpipe душевая система с термостатом, хром",
      "product_mpn": "27271000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "Crometta E",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "298.35",
      "product_currency": "EUR",
      "product_price_old": "424.1000",
      "product_price_online": "8951",
      "sourcePrice": "238.68",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054261_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054261_1.jpg"
      ],
      "description": "Crometta Е 240 1jet Showerpipe Душевая система с термостатом, хром. Верхний душ Crometta E 240, размер душевого диска: 240 x 240 мм, регулируемый угол верхнего душа, тип струи: Rain,  расход воды для струи Rain (при 3 бар): 15 л / мин, полностью хромированный душевой диск, длина держателя для душа: 350 мм, предохранительный ограничитель при 40° C, регулируемый ограничитель температуры горячей воды,  пользовательское управление посредством вращения рукоятки, вид монтажа: наружный монтаж, величина соединения DN15,  соединительная резьба G ½ ,  межосевое подключение 150 мм ± 12 мм, регулируемое по высоте крепление ручного душа, класс шума: I,  класс расхода воды: B, O",
      parameters: [
        {
          "parameter_id": "54261_000000156",
          "product_sku": "54261",
          "parameter_name": "Ширина лейки верхнего душа, мм",
          "parameter_value": "240"
        },
        {
          "parameter_id": "54261_000000157",
          "product_sku": "54261",
          "parameter_name": "Длина лейки верхнего душа, мм",
          "parameter_value": "240"
        },
        {
          "parameter_id": "54261_000000158",
          "product_sku": "54261",
          "parameter_name": "Длина кронштейна (от стены), мм",
          "parameter_value": "355"
        },
        {
          "parameter_id": "54261_000000160",
          "product_sku": "54261",
          "parameter_name": "Мин. Высота, мм",
          "parameter_value": "1 201"
        },
        {
          "parameter_id": "54261_000000161",
          "product_sku": "54261",
          "parameter_name": "Регулируемая высота стойки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "54261_000000162",
          "product_sku": "54261",
          "parameter_name": "Форма лейки верхнего душа",
          "parameter_value": "Квадратная"
        },
        {
          "parameter_id": "54261_000000163",
          "product_sku": "54261",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "54261_000000164",
          "product_sku": "54261",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "54261_000000165",
          "product_sku": "54261",
          "parameter_name": "Тип управления",
          "parameter_value": "Термостат"
        },
        {
          "parameter_id": "54261_000000166",
          "product_sku": "54261",
          "parameter_name": "Смеситель",
          "parameter_value": "Для душа"
        },
        {
          "parameter_id": "54261_000000167",
          "product_sku": "54261",
          "parameter_name": "Кол-во режимов ручного душа",
          "parameter_value": "1"
        },
        {
          "parameter_id": "54261_000000168",
          "product_sku": "54261",
          "parameter_name": "Кол-во режимов верхнего душа",
          "parameter_value": "1"
        },
        {
          "parameter_id": "54261_Brand",
          "product_sku": "54261",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "54261_Series",
          "product_sku": "54261",
          "parameter_name": "Серия",
          "parameter_value": "Crometta E"
        }
      ]
    },
    {
      "product_sku": "054271",
      "product_categoryId": "400045",
      "product_name": "VYSKOV набор (смеситель скрытого монтажа с гигиеническим душем, шланг полимер)",
      "product_mpn": "VR15340Z-BT",
      "manufacturer_name": "IMPRESE",
      "product_seria": "VYSKOV",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "82",
      "product_currency": "EUR",
      "product_price_online": "2419",
      "sourcePrice": "57.40",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054271_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054271_1.jpg"
      ],
      "description": "Модель установленного картриджа Sedal EN- 35 S/D AZ",
      parameters: [
        {
          "parameter_id": "54271_000000009",
          "product_sku": "54271",
          "parameter_name": "Комплектация",
          "parameter_value": "Смеситель скрытый+гигиенический душ"
        },
        {
          "parameter_id": "54271_Brand",
          "product_sku": "54271",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "54271_Series",
          "product_sku": "54271",
          "parameter_name": "Серия",
          "parameter_value": "VYSKOV"
        }
      ]
    },
    {
      "product_sku": "054456",
      "product_categoryId": "400013",
      "product_name": "Картридж Sedal (EN-35C/D)",
      "product_mpn": "CS01",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "5.50",
      "product_currency": "EUR",
      "product_price_online": "162",
      "sourcePrice": "3.85",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054456_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054456_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054456_2.jpg"
      ],
      "description": "Картридж Sedal (EN-35C/D) для однорычажного смесителя.",
      parameters: [
        {
          "parameter_id": "54456_Brand",
          "product_sku": "54456",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "54456_Series",
          "product_sku": "54456",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "054457",
      "product_categoryId": "400013",
      "product_name": "Картридж Sedal (EN-35S/D)",
      "product_mpn": "CS02",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "5.50",
      "product_currency": "EUR",
      "product_price_online": "162",
      "sourcePrice": "3.85",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054457_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054457_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054457_2.jpg"
      ],
      "description": "Картридж Sedal (EN-35S/D) для однорычажного смесителя..",
      parameters: [
        {
          "parameter_id": "54457_Brand",
          "product_sku": "54457",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "54457_Series",
          "product_sku": "54457",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "054458",
      "product_categoryId": "400013",
      "product_name": "Картридж Sedal (G-35 C/D)",
      "product_mpn": "CS03",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "7",
      "product_currency": "EUR",
      "product_price_online": "207",
      "sourcePrice": "4.90",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054458_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054458_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054458_2.jpg"
      ],
      "description": "Картридж Sedal (G-35 C/D) для однорычажного смесителя.",
      parameters: [
        {
          "parameter_id": "54458_Brand",
          "product_sku": "54458",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "54458_Series",
          "product_sku": "54458",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "054470",
      "product_categoryId": "180004",
      "product_name": "VOLLE умывальник 45*45*14см круглый, накладной с отверстием под смеситель",
      "product_mpn": "13-01-036",
      "manufacturer_name": "VOLLE",
      "product_seria": "Volle",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "77",
      "product_currency": "EUR",
      "product_price_old": "130.0000",
      "product_price_online": "2272",
      "sourcePrice": "84.50",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054470_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054470_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054470_2.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054470_3.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054470_4.jpg"
      ],
      "description": "Керамический умывальник на столешницу Volle 13-01-036\nХарактеристики:\n•\tТип монтажа – на столешницу\n•\tФорма – круглая\n•\t1 отверстие под смеситель\n•\tБез перелива\n•\tЦвет – белый\n•\tГабариты\nРаковина изготовлена из стекловидного фарфора. Высокая прочность материала позволяет максимально уменьшить толщину стенок. Изделие спроектировано в соответствии с концепцией VoClean: анатомичный дизайн, плавные формы и отсутствие острых углов - всё это обеспечивает эффективную эксплуатацию и облегчает очистку. Поверхность покрывается глазурью, на которую перед обжигом наносится специальное покрытие СeraPro. Благодаря этому она становится максимально гладкой и менее подверженной загрязнению.\nМожно смесителем Volle Fiesta 15151100, Benita 15171100, Nemo 15141100, Daniella 15161100\nГарантия: 25 лет\nВ случае использования продукции в общественной или промышленной сферах гарантийный срок составляет 6 месяцев",
      parameters: [
        {
          "parameter_id": "54470_000000058",
          "product_sku": "54470",
          "parameter_name": "Ширина",
          "parameter_value": "450"
        },
        {
          "parameter_id": "54470_000000059",
          "product_sku": "54470",
          "parameter_name": "Глубина",
          "parameter_value": "450"
        },
        {
          "parameter_id": "54470_000000060",
          "product_sku": "54470",
          "parameter_name": "Высота",
          "parameter_value": "140"
        },
        {
          "parameter_id": "54470_000000061",
          "product_sku": "54470",
          "parameter_name": "Монтаж",
          "parameter_value": "На столешницу"
        },
        {
          "parameter_id": "54470_000000062",
          "product_sku": "54470",
          "parameter_name": "Форма",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "54470_000000063",
          "product_sku": "54470",
          "parameter_name": "Особенности формы",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "54470_000000064",
          "product_sku": "54470",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "54470_000000065",
          "product_sku": "54470",
          "parameter_name": "Комплектация",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "54470_000000066",
          "product_sku": "54470",
          "parameter_name": "Материал",
          "parameter_value": "Керамика"
        },
        {
          "parameter_id": "54470_000000067",
          "product_sku": "54470",
          "parameter_name": "Перелив",
          "parameter_value": "Без перелива"
        },
        {
          "parameter_id": "54470_000000068",
          "product_sku": "54470",
          "parameter_name": "Отверстия под смеситель",
          "parameter_value": "1"
        },
        {
          "parameter_id": "54470_000000069",
          "product_sku": "54470",
          "parameter_name": "Кол-во смесителей",
          "parameter_value": "1"
        },
        {
          "parameter_id": "54470_000000070",
          "product_sku": "54470",
          "parameter_name": "Особенности",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "54470_Brand",
          "product_sku": "54470",
          "parameter_name": "Бренд",
          "parameter_value": "VOLLE"
        },
        {
          "parameter_id": "54470_Series",
          "product_sku": "54470",
          "parameter_name": "Серия",
          "parameter_value": "Volle"
        }
      ]
    },
    {
      "product_sku": "054473",
      "product_categoryId": "400023",
      "product_name": "Подсоединение шланговое (квадр) 1/2 \"",
      "product_mpn": "HC02",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "18",
      "product_currency": "EUR",
      "product_price_old": "22.0000",
      "product_price_online": "531",
      "sourcePrice": "14",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054473_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054473_1.jpg"
      ],
      "description": "Подсоединение шланговое 1/2, латунь.",
      parameters: [
        {
          "parameter_id": "54473_Brand",
          "product_sku": "54473",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "54473_Series",
          "product_sku": "54473",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "054478",
      "product_categoryId": "1800074",
      "product_name": "DEBBA унитаз, подвесной, Rimless",
      "product_mpn": "A34699L000",
      "manufacturer_name": "ROCA",
      "product_seria": "DEBBA",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "138.91",
      "product_currency": "EUR",
      "product_price_online": "4098",
      "sourcePrice": "104.18",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054478_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054478_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054478_2.jpg"
      ],
      "description": "DEBBA унитаз, подвесной, Rimless, прямоугольная форма, глубина 540 мм.",
      parameters: [
        {
          "parameter_id": "54478_Brand",
          "product_sku": "54478",
          "parameter_name": "Бренд",
          "parameter_value": "ROCA"
        },
        {
          "parameter_id": "54478_Series",
          "product_sku": "54478",
          "parameter_name": "Серия",
          "parameter_value": "DEBBA"
        }
      ]
    },
    {
      "product_sku": "054480",
      "product_categoryId": "900089",
      "product_name": "HRANICE полотенцедержатель 600 мм",
      "product_mpn": "131100",
      "manufacturer_name": "IMPRESE",
      "product_seria": "HRANICE",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "25",
      "product_currency": "EUR",
      "product_price_online": "738",
      "sourcePrice": "17.50",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054480_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054480_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054480_2.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054480_3.jpg"
      ],
      "description": "HRANICE полотенцедержатель подвесной, длина 600 мм, латунь.",
      parameters: [
        {
          "parameter_id": "54480_000000013",
          "product_sku": "54480",
          "parameter_name": "Материал",
          "parameter_value": "Латунь"
        },
        {
          "parameter_id": "54480_000000015",
          "product_sku": "54480",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "600"
        },
        {
          "parameter_id": "54480_000000016",
          "product_sku": "54480",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "54480_000000018",
          "product_sku": "54480",
          "parameter_name": "Форма",
          "parameter_value": "Поручни"
        },
        {
          "parameter_id": "54480_000000025",
          "product_sku": "54480",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "54480_Brand",
          "product_sku": "54480",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "54480_Series",
          "product_sku": "54480",
          "parameter_name": "Серия",
          "parameter_value": "HRANICE"
        }
      ]
    },
    {
      "product_sku": "054481",
      "product_categoryId": "9000103",
      "product_name": "HRANICE крючок",
      "product_mpn": "100100",
      "manufacturer_name": "IMPRESE",
      "product_seria": "HRANICE",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "9",
      "product_currency": "EUR",
      "product_price_online": "266",
      "sourcePrice": "6.30",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054481_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054481_1.jpg"
      ],
      "description": "HRANICE крючок одинарный, латунь, цвет хром.",
      parameters: [
        {
          "parameter_id": "54481_000000013",
          "product_sku": "54481",
          "parameter_name": "Материал",
          "parameter_value": "Латунь"
        },
        {
          "parameter_id": "54481_000000016",
          "product_sku": "54481",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "54481_000000025",
          "product_sku": "54481",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "54481_Brand",
          "product_sku": "54481",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "54481_Series",
          "product_sku": "54481",
          "parameter_name": "Серия",
          "parameter_value": "HRANICE"
        }
      ]
    },
    {
      "product_sku": "054482",
      "product_categoryId": "9000107",
      "product_name": "HRANICE стакан для зубных щеток",
      "product_mpn": "120100",
      "manufacturer_name": "IMPRESE",
      "product_seria": "HRANICE",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "14",
      "product_currency": "EUR",
      "product_price_online": "413",
      "sourcePrice": "9.80",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054482_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054482_1.jpg"
      ],
      "description": "HRANICE стакан для зубных щеток, подвесной, цвет держателя хром.",
      parameters: [
        {
          "parameter_id": "54482_000000013",
          "product_sku": "54482",
          "parameter_name": "Материал",
          "parameter_value": "Стекло"
        },
        {
          "parameter_id": "54482_000000016",
          "product_sku": "54482",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "54482_000000017",
          "product_sku": "54482",
          "parameter_name": "Назначение",
          "parameter_value": "Для зубных щеток"
        },
        {
          "parameter_id": "54482_000000025",
          "product_sku": "54482",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Другие цвета"
        },
        {
          "parameter_id": "54482_Brand",
          "product_sku": "54482",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "54482_Series",
          "product_sku": "54482",
          "parameter_name": "Серия",
          "parameter_value": "HRANICE"
        }
      ]
    },
    {
      "product_sku": "054483",
      "product_categoryId": "90007",
      "product_name": "HRANICE мыльница",
      "product_mpn": "110100",
      "manufacturer_name": "IMPRESE",
      "product_seria": "HRANICE",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "14",
      "product_currency": "EUR",
      "product_price_online": "413",
      "sourcePrice": "9.80",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054483_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054483_1.jpg"
      ],
      "description": "HRANICE мыльница подвесная, цвет держателя хром.",
      parameters: [
        {
          "parameter_id": "54483_000000013",
          "product_sku": "54483",
          "parameter_name": "Материал",
          "parameter_value": "Стекло"
        },
        {
          "parameter_id": "54483_000000016",
          "product_sku": "54483",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "54483_000000025",
          "product_sku": "54483",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Другие цвета"
        },
        {
          "parameter_id": "54483_Brand",
          "product_sku": "54483",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "54483_Series",
          "product_sku": "54483",
          "parameter_name": "Серия",
          "parameter_value": "HRANICE"
        }
      ]
    },
    {
      "product_sku": "054484",
      "product_categoryId": "900089",
      "product_name": "HRANICE полотенцедержатель, двухрожковый",
      "product_mpn": "134100",
      "manufacturer_name": "IMPRESE",
      "product_seria": "HRANICE",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "26",
      "product_currency": "EUR",
      "product_price_online": "767",
      "sourcePrice": "18.20",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054484_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054484_1.jpg"
      ],
      "description": "HRANICE полотенцедержатель, двухрожковый, подвесной, латунь, цвет хром.",
      parameters: [
        {
          "parameter_id": "54484_000000013",
          "product_sku": "54484",
          "parameter_name": "Материал",
          "parameter_value": "Латунь"
        },
        {
          "parameter_id": "54484_000000016",
          "product_sku": "54484",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "54484_000000018",
          "product_sku": "54484",
          "parameter_name": "Форма",
          "parameter_value": "Рога"
        },
        {
          "parameter_id": "54484_000000025",
          "product_sku": "54484",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "54484_Brand",
          "product_sku": "54484",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "54484_Series",
          "product_sku": "54484",
          "parameter_name": "Серия",
          "parameter_value": "HRANICE"
        }
      ]
    },
    {
      "product_sku": "054486",
      "product_categoryId": "9000120",
      "product_name": "HRANICE дозатор для мыла, объем 210 мл",
      "product_mpn": "170100",
      "manufacturer_name": "IMPRESE",
      "product_seria": "HRANICE",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "25",
      "product_currency": "EUR",
      "product_price_online": "738",
      "sourcePrice": "17.50",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054486_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054486_1.jpg"
      ],
      "description": "HRANICE дозатор для мыла, подвесной, цвет держателя хром, матовое стекло, объем 210 мл",
      parameters: [
        {
          "parameter_id": "54486_000000013",
          "product_sku": "54486",
          "parameter_name": "Материал",
          "parameter_value": "Стекло"
        },
        {
          "parameter_id": "54486_000000016",
          "product_sku": "54486",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "54486_000000017",
          "product_sku": "54486",
          "parameter_name": "Назначение",
          "parameter_value": "Для жидкого мыла"
        },
        {
          "parameter_id": "54486_000000022",
          "product_sku": "54486",
          "parameter_name": "Тип управления",
          "parameter_value": "Механический"
        },
        {
          "parameter_id": "54486_000000025",
          "product_sku": "54486",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Другие цвета"
        },
        {
          "parameter_id": "54486_Brand",
          "product_sku": "54486",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "54486_Series",
          "product_sku": "54486",
          "parameter_name": "Серия",
          "parameter_value": "HRANICE"
        }
      ]
    },
    {
      "product_sku": "054487",
      "product_categoryId": "9000105",
      "product_name": "HRANICE щетка для унитаза",
      "product_mpn": "150100",
      "manufacturer_name": "IMPRESE",
      "product_seria": "HRANICE",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "29",
      "product_currency": "EUR",
      "product_price_online": "856",
      "sourcePrice": "20.30",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054487_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054487_1.jpg"
      ],
      "description": "HRANICE щетка для унитаза, подвесная",
      parameters: [
        {
          "parameter_id": "54487_000000013",
          "product_sku": "54487",
          "parameter_name": "Материал",
          "parameter_value": "Стекло"
        },
        {
          "parameter_id": "54487_000000016",
          "product_sku": "54487",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "54487_000000024",
          "product_sku": "54487",
          "parameter_name": "Особенности",
          "parameter_value": "Без крышки"
        },
        {
          "parameter_id": "54487_000000025",
          "product_sku": "54487",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Другие цвета"
        },
        {
          "parameter_id": "54487_Brand",
          "product_sku": "54487",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "54487_Series",
          "product_sku": "54487",
          "parameter_name": "Серия",
          "parameter_value": "HRANICE"
        }
      ]
    },
    {
      "product_sku": "054489",
      "product_categoryId": "9000122",
      "product_name": "HRANICE держатель для туалетной бумаги",
      "product_mpn": "141100",
      "manufacturer_name": "IMPRESE",
      "product_seria": "HRANICE",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "19",
      "product_currency": "EUR",
      "product_price_online": "561",
      "sourcePrice": "13.30",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054489_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054489_1.jpg"
      ],
      "description": "HRANICE держатель для туалетной бумаги, подвесной без крышки, хром.",
      parameters: [
        {
          "parameter_id": "54489_000000013",
          "product_sku": "54489",
          "parameter_name": "Материал",
          "parameter_value": "Латунь"
        },
        {
          "parameter_id": "54489_000000016",
          "product_sku": "54489",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "54489_000000024",
          "product_sku": "54489",
          "parameter_name": "Особенности",
          "parameter_value": "Без крышки"
        },
        {
          "parameter_id": "54489_000000025",
          "product_sku": "54489",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "54489_Brand",
          "product_sku": "54489",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "54489_Series",
          "product_sku": "54489",
          "parameter_name": "Серия",
          "parameter_value": "HRANICE"
        }
      ]
    },
    {
      "product_sku": "054490",
      "product_categoryId": "900089",
      "product_name": "BITOV полотенцедержатель 600мм",
      "product_mpn": "131300",
      "manufacturer_name": "IMPRESE",
      "product_seria": "BITOV",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "60",
      "product_currency": "EUR",
      "product_price_online": "1770",
      "sourcePrice": "42",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054490_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054490_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054490_2.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054490_3.jpg"
      ],
      "description": "BITOV полотенцедержатель 600 мм, подвесной, латунь, хром.",
      parameters: [
        {
          "parameter_id": "54490_000000013",
          "product_sku": "54490",
          "parameter_name": "Материал",
          "parameter_value": "Латунь"
        },
        {
          "parameter_id": "54490_000000015",
          "product_sku": "54490",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "600"
        },
        {
          "parameter_id": "54490_000000016",
          "product_sku": "54490",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "54490_000000018",
          "product_sku": "54490",
          "parameter_name": "Форма",
          "parameter_value": "Поручни"
        },
        {
          "parameter_id": "54490_000000025",
          "product_sku": "54490",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "54490_Brand",
          "product_sku": "54490",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "54490_Series",
          "product_sku": "54490",
          "parameter_name": "Серия",
          "parameter_value": "BITOV"
        }
      ]
    },
    {
      "product_sku": "054491",
      "product_categoryId": "900089",
      "product_name": "BITOV полотенцедержатель",
      "product_mpn": "130300",
      "manufacturer_name": "IMPRESE",
      "product_seria": "BITOV",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "35",
      "product_currency": "EUR",
      "product_price_online": "1033",
      "sourcePrice": "24.50",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054491_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054491_1.jpg"
      ],
      "description": "BITOV полотенцедержатель, подвесной, латунь, хром.",
      parameters: [
        {
          "parameter_id": "54491_000000013",
          "product_sku": "54491",
          "parameter_name": "Материал",
          "parameter_value": "Латунь"
        },
        {
          "parameter_id": "54491_000000016",
          "product_sku": "54491",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "54491_000000018",
          "product_sku": "54491",
          "parameter_name": "Форма",
          "parameter_value": "Кольца"
        },
        {
          "parameter_id": "54491_000000025",
          "product_sku": "54491",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "54491_Brand",
          "product_sku": "54491",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "54491_Series",
          "product_sku": "54491",
          "parameter_name": "Серия",
          "parameter_value": "BITOV"
        }
      ]
    },
    {
      "product_sku": "054492",
      "product_categoryId": "9000103",
      "product_name": "BITOV крючок",
      "product_mpn": "100300",
      "manufacturer_name": "IMPRESE",
      "product_seria": "BITOV",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "22",
      "product_currency": "EUR",
      "product_price_online": "649",
      "sourcePrice": "15.40",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054492_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054492_1.jpg"
      ],
      "description": "BITOV крючок одинарный, подвесной, латунь, цвет хром.",
      parameters: [
        {
          "parameter_id": "54492_000000013",
          "product_sku": "54492",
          "parameter_name": "Материал",
          "parameter_value": "Латунь"
        },
        {
          "parameter_id": "54492_000000016",
          "product_sku": "54492",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "54492_000000025",
          "product_sku": "54492",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "54492_Brand",
          "product_sku": "54492",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "54492_Series",
          "product_sku": "54492",
          "parameter_name": "Серия",
          "parameter_value": "BITOV"
        }
      ]
    },
    {
      "product_sku": "054493",
      "product_categoryId": "9000107",
      "product_name": "BITOV стакан для зубных щеток",
      "product_mpn": "120300",
      "manufacturer_name": "IMPRESE",
      "product_seria": "BITOV",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "25",
      "product_currency": "EUR",
      "product_price_online": "738",
      "sourcePrice": "17.50",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054493_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054493_1.jpg"
      ],
      "description": "BITOV стакан для зубных щеток, подвесной, матовое стекло, цвет держатель хром, латунь.",
      parameters: [
        {
          "parameter_id": "54493_000000013",
          "product_sku": "54493",
          "parameter_name": "Материал",
          "parameter_value": "Стекло"
        },
        {
          "parameter_id": "54493_000000016",
          "product_sku": "54493",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "54493_000000017",
          "product_sku": "54493",
          "parameter_name": "Назначение",
          "parameter_value": "Для зубных щеток"
        },
        {
          "parameter_id": "54493_000000025",
          "product_sku": "54493",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Матовый"
        },
        {
          "parameter_id": "54493_Brand",
          "product_sku": "54493",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "54493_Series",
          "product_sku": "54493",
          "parameter_name": "Серия",
          "parameter_value": "BITOV"
        }
      ]
    },
    {
      "product_sku": "054494",
      "product_categoryId": "90007",
      "product_name": "BITOV мыльница",
      "product_mpn": "110300",
      "manufacturer_name": "IMPRESE",
      "product_seria": "BITOV",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "25",
      "product_currency": "EUR",
      "product_price_online": "738",
      "sourcePrice": "17.50",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054494_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054494_1.jpg"
      ],
      "description": "BITOV мыльница, подвесная, матовое стекло, материал держателя - латунь, хром.",
      parameters: [
        {
          "parameter_id": "54494_000000013",
          "product_sku": "54494",
          "parameter_name": "Материал",
          "parameter_value": "Стекло"
        },
        {
          "parameter_id": "54494_000000016",
          "product_sku": "54494",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "54494_000000025",
          "product_sku": "54494",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Матовый"
        },
        {
          "parameter_id": "54494_Brand",
          "product_sku": "54494",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "54494_Series",
          "product_sku": "54494",
          "parameter_name": "Серия",
          "parameter_value": "BITOV"
        }
      ]
    },
    {
      "product_sku": "054496",
      "product_categoryId": "900017",
      "product_name": "BITOV полочка стеклянная",
      "product_mpn": "160300",
      "manufacturer_name": "IMPRESE",
      "product_seria": "BITOV",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "24",
      "product_currency": "EUR",
      "product_price_online": "708",
      "sourcePrice": "16.80",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054496_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054496_1.jpg"
      ],
      "description": "BITOV стеклянная полочка, подвесная, материал держателя латунь, хром.",
      parameters: [
        {
          "parameter_id": "54496_000000013",
          "product_sku": "54496",
          "parameter_name": "Материал",
          "parameter_value": "Стекло"
        },
        {
          "parameter_id": "54496_000000016",
          "product_sku": "54496",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "54496_000000017",
          "product_sku": "54496",
          "parameter_name": "Назначение",
          "parameter_value": "В душ"
        },
        {
          "parameter_id": "54496_000000018",
          "product_sku": "54496",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "54496_000000025",
          "product_sku": "54496",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Прозрачный"
        },
        {
          "parameter_id": "54496_Brand",
          "product_sku": "54496",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "54496_Series",
          "product_sku": "54496",
          "parameter_name": "Серия",
          "parameter_value": "BITOV"
        }
      ]
    },
    {
      "product_sku": "054507",
      "product_categoryId": "900021",
      "product_name": "Зеркало косметическое, увеличение Х3",
      "product_mpn": "181222",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "59",
      "product_currency": "EUR",
      "product_price_online": "1741",
      "sourcePrice": "41.30",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054507_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054507_1.jpg"
      ],
      "description": "Зеркало косметическое, увеличение Х3, подвесное, латунь, цвет хром.\nДиаметр -200 mm, одностороннее",
      parameters: [
        {
          "parameter_id": "54507_000000013",
          "product_sku": "54507",
          "parameter_name": "Материал",
          "parameter_value": "Латунь"
        },
        {
          "parameter_id": "54507_000000016",
          "product_sku": "54507",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "54507_000000024",
          "product_sku": "54507",
          "parameter_name": "Особенности",
          "parameter_value": "Откидной"
        },
        {
          "parameter_id": "54507_000000025",
          "product_sku": "54507",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "54507_Brand",
          "product_sku": "54507",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "54507_Series",
          "product_sku": "54507",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "054510",
      "product_categoryId": "9000103",
      "product_name": "Крючок (3 шт) под углом",
      "product_mpn": "100111",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "17",
      "product_currency": "EUR",
      "product_price_online": "502",
      "sourcePrice": "11.90",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_054510_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_054510_1.jpg"
      ],
      parameters: [
        {
          "parameter_id": "54510_Brand",
          "product_sku": "54510",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "54510_Series",
          "product_sku": "54510",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "054511",
      "product_categoryId": "9000103",
      "product_name": "Крючок (3 шт) прямые",
      "product_mpn": "101111",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "18",
      "product_currency": "EUR",
      "product_price_online": "531",
      "sourcePrice": "12.60",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
          "https://b2bdev.antey.com.ua/media/product_sku_054511_0.jpg",
          "https://b2bdev.antey.com.ua/media/product_sku_054511_1.jpg"
        ],
      parameters: [
        {
          "parameter_id": "54511_Brand",
          "product_sku": "54511",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "54511_Series",
          "product_sku": "54511",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "055349",
      "product_categoryId": "200043",
      "product_name": "PRO инсталляция для унитаза",
      "product_mpn": "A890090020",
      "manufacturer_name": "ROCA",
      "product_seria": "PRO",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "178.65",
      "product_currency": "EUR",
      "product_price_online": "5270",
      "sourcePrice": "133.99",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_055349_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_055349_1.jpg"
      ],
      "description": "Инсталляция для чаши подвесного унитаза. С бачком, механизмом двойного слива на 3/6 литра и комплектом крепления. Сохранение промывочной воды.",
      parameters: [
        {
          "parameter_id": "55349_000000001",
          "product_sku": "55349",
          "parameter_name": "Ширина",
          "parameter_value": "500"
        },
        {
          "parameter_id": "55349_000000014",
          "product_sku": "55349",
          "parameter_name": "Глубина",
          "parameter_value": "140"
        },
        {
          "parameter_id": "55349_000000015",
          "product_sku": "55349",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "1 120"
        },
        {
          "parameter_id": "55349_000000017",
          "product_sku": "55349",
          "parameter_name": "Назначение",
          "parameter_value": "Для подвесного унитаза"
        },
        {
          "parameter_id": "55349_000000022",
          "product_sku": "55349",
          "parameter_name": "Тип управления",
          "parameter_value": "Механический"
        },
        {
          "parameter_id": "55349_Brand",
          "product_sku": "55349",
          "parameter_name": "Бренд",
          "parameter_value": "ROCA"
        },
        {
          "parameter_id": "55349_Series",
          "product_sku": "55349",
          "parameter_name": "Серия",
          "parameter_value": "PRO"
        }
      ]
    },
    {
      "product_sku": "055426",
      "product_categoryId": "500040",
      "product_name": "LAGUNA ванна прямоугольная 150*75 см, глубина: 42см, емкость: 115л, с ножками SN0+сифон Viega Simplex для ванны автомат",
      "product_mpn": "XWP0350000+285357",
      "manufacturer_name": "KOLO Украина",
      "product_seria": "LAGUNA",
      "product_status": "Распродажа",
      "product_price": "3554.26",
      "product_currency": "UAH",
      "product_price_online": "3554.26",
      "sourcePrice": "2345.81",
      "sourceCurrency": "UAH",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_055426_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_055426_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_055426_2.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_055426_3.jpg"
      ],
      "description": "LAGUNA ванна прямоугольная 150*75 см, глубина: 42см, емкость: 115л, акрил, с ножками + сифон Viega Simplex для ванны автомат (гибкая переливная труба, хромированная поворотная накладка переливного отверстия (верхняя), хромированная пробка донного клапана со штоком, гидрозатвор, сливное колено 45°, донный клапан (нержавеющая сталь)",
      parameters: [
        {
          "parameter_id": "55426_Brand",
          "product_sku": "55426",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Украина"
        },
        {
          "parameter_id": "55426_Series",
          "product_sku": "55426",
          "parameter_name": "Серия",
          "parameter_value": "LAGUNA"
        }
      ]
    },
    {
      "product_sku": "055427",
      "product_categoryId": "500040",
      "product_name": "LAGUNA ванна прямоугольная 170*80 см, глубина: 42см, емкость: 190л, с ножками SN0+сифон Viega Simplex  для ванны автомат",
      "product_mpn": "XWP0370000+285357",
      "manufacturer_name": "KOLO Украина",
      "product_seria": "LAGUNA",
      "product_status": "Распродажа",
      "product_price": "3704.26",
      "product_currency": "UAH",
      "product_price_online": "3704.26",
      "sourcePrice": "2444.81",
      "sourceCurrency": "UAH",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_055427_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_055427_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_055427_2.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_055427_3.jpg"
      ],
      "description": "LAGUNA ванна прямоугольная 170*80 см, глубина: 42см, акрил, емкость: 190л, с ножками + сифон Viega Simplex  для ванны автомат (гибкая переливная труба, хромированная поворотная накладка переливного отверстия (верхняя), хромированная пробка донного клапана со штоком, гидрозатвор, сливное колено 45°, донный клапан (нержавеющая сталь)",
      parameters: [
        {
          "parameter_id": "55427_Brand",
          "product_sku": "55427",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Украина"
        },
        {
          "parameter_id": "55427_Series",
          "product_sku": "55427",
          "parameter_name": "Серия",
          "parameter_value": "LAGUNA"
        }
      ]
    },
    {
      "product_sku": "055951",
      "product_categoryId": "600066",
      "product_name": "FIESTA поддон 90*90*15см мелкий, полукруглый",
      "product_mpn": "10-22-157tray",
      "manufacturer_name": "VOLLE",
      "product_seria": "FIESTA",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "100",
      "product_currency": "EUR",
      "product_price_online": "2950",
      "sourcePrice": "65",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_055951_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_055951_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_055951_2.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_055951_3.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_055951_4.jpg"
      ],
      "description": "Акриловый поддон 90х90х15 см R 550\nC формованной лицевой панелью, на металлической раме\nДиаметр сливного отверстия 60 мм\nСифон в комплекте (диаметр крышки сифона 90 мм)",
      parameters: [
        {
          "parameter_id": "55951_000000001",
          "product_sku": "55951",
          "parameter_name": "Ширина",
          "parameter_value": "900"
        },
        {
          "parameter_id": "55951_000000011",
          "product_sku": "55951",
          "parameter_name": "Тип поддона",
          "parameter_value": "Мелкий"
        },
        {
          "parameter_id": "55951_000000013",
          "product_sku": "55951",
          "parameter_name": "Материал",
          "parameter_value": "Акрил"
        },
        {
          "parameter_id": "55951_000000014",
          "product_sku": "55951",
          "parameter_name": "Глубина",
          "parameter_value": "900"
        },
        {
          "parameter_id": "55951_000000015",
          "product_sku": "55951",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "150"
        },
        {
          "parameter_id": "55951_000000018",
          "product_sku": "55951",
          "parameter_name": "Форма",
          "parameter_value": "Угловая"
        },
        {
          "parameter_id": "55951_Brand",
          "product_sku": "55951",
          "parameter_name": "Бренд",
          "parameter_value": "VOLLE"
        },
        {
          "parameter_id": "55951_Series",
          "product_sku": "55951",
          "parameter_name": "Серия",
          "parameter_value": "FIESTA"
        }
      ]
    },
    {
      "product_sku": "055969",
      "product_categoryId": "300052",
      "product_name": "Комплект: STYLE Rimfree унитаз подвесной + сиденье Duroplast, с микролифтом + инсталляция GEBERIT DUOFIX 3в1",
      "product_mpn": "L23120+L20112+458.126.00.1",
      "manufacturer_name": "KOLO Польша",
      "product_seria": "STYLE",
      "product_status": "Акция",
      "exchangeRate_product_source_price": [],
      "exchangeRate_product_price_online": [],
      "product_price": "6279",
      "product_currency": "UAH",
      "product_price_old": "12573.0000",
      "product_price_online": "6279",
      "sourcePrice": "9178.29",
      "sourceCurrency": "UAH",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_055969_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_055969_1.jpg"
      ],
      "description": "Комплект: Style Rimfree унитаз подвесной без ободка, инсталляция Geberit Duofix 3в1, сидение Duroplast soft-close (медленное опускание)",
      parameters: [
        {
          "parameter_id": "55969_000000009",
          "product_sku": "55969",
          "parameter_name": "Комплектация",
          "parameter_value": "Инсталляция+крепление+унитаз+сидение"
        },
        {
          "parameter_id": "55969_Brand",
          "product_sku": "55969",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Польша"
        },
        {
          "parameter_id": "55969_Series",
          "product_sku": "55969",
          "parameter_name": "Серия",
          "parameter_value": "STYLE"
        }
      ]
    },
    {
      "product_sku": "056003",
      "product_categoryId": "400071",
      "product_name": "CROMETTA Vario душевой набор 0,65 м, с мыльницей Casetta, белый/хром",
      "product_mpn": "26553400",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "CROMETTA VARIO",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "53.20",
      "product_currency": "EUR",
      "product_price_online": "1596",
      "sourcePrice": "34.58",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_056003_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056003_1.jpg"
      ],
      "description": "Тип струи: Rain, IntenseRain; переключение типов струи с помощью вращающегося душевого диска;  размер душевого диска: 100 мм; со стороны душа упорный подшипник, предотвращающий перекручивание душевого шланга; максимальный расход воды (при 3 бар): ширина штанги 22 мм; хромированные настенные крепления из пластика; с мыльницей",
      parameters: [
        {
          "parameter_id": "56003_000000150",
          "product_sku": "56003",
          "parameter_name": "Высота, мм",
          "parameter_value": "650"
        },
        {
          "parameter_id": "56003_000000151",
          "product_sku": "56003",
          "parameter_name": "Тип держателя",
          "parameter_value": "Штанга"
        },
        {
          "parameter_id": "56003_000000152",
          "product_sku": "56003",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "56003_000000153",
          "product_sku": "56003",
          "parameter_name": "Форма лейки ручного душа",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "56003_000000154",
          "product_sku": "56003",
          "parameter_name": "Мыльница",
          "parameter_value": "Да"
        },
        {
          "parameter_id": "56003_000000155",
          "product_sku": "56003",
          "parameter_name": "Кол-во режимов ручного душа",
          "parameter_value": "2"
        },
        {
          "parameter_id": "56003_000000175",
          "product_sku": "56003",
          "parameter_name": "Диаметр/Диагональ, мм",
          "parameter_value": "100"
        },
        {
          "parameter_id": "56003_000000176",
          "product_sku": "56003",
          "parameter_name": "Способ переключения режимов",
          "parameter_value": "Поворотный"
        },
        {
          "parameter_id": "56003_000000177",
          "product_sku": "56003",
          "parameter_name": "Цвет диска ручного душа",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "56003_Brand",
          "product_sku": "56003",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "56003_Series",
          "product_sku": "56003",
          "parameter_name": "Серия",
          "parameter_value": "CROMETTA VARIO"
        }
      ]
    },
    {
      "product_sku": "056045",
      "product_categoryId": "500040",
      "product_name": "OPAL PLUS ванна 150*70см прямоугольная, без ножек",
      "product_mpn": "XWP135000N",
      "manufacturer_name": "KOLO Украина",
      "product_seria": "OPAL PLUS",
      "product_status": "Акция",
      "exchangeRate_product_source_price": [],
      "exchangeRate_product_price_online": [],
      "product_price": "2820",
      "product_currency": "UAH",
      "product_price_old": "3318.0000",
      "product_price_online": "2820",
      "sourcePrice": "2355.78",
      "sourceCurrency": "UAH",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_056045_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056045_1.jpg"
      ],
      "description": "OPAL PLUS ванна 150х70х43,2 см, прямоугольная, без ножек, акрил",
      parameters: [
        {
          "parameter_id": "56045_000000071",
          "product_sku": "56045",
          "parameter_name": "Длина",
          "parameter_value": "1 500"
        },
        {
          "parameter_id": "56045_000000072",
          "product_sku": "56045",
          "parameter_name": "Ширина",
          "parameter_value": "700"
        },
        {
          "parameter_id": "56045_000000073",
          "product_sku": "56045",
          "parameter_name": "Высота",
          "parameter_value": "432"
        },
        {
          "parameter_id": "56045_000000074",
          "product_sku": "56045",
          "parameter_name": "Материал",
          "parameter_value": "Акрил"
        },
        {
          "parameter_id": "56045_000000075",
          "product_sku": "56045",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "56045_000000076",
          "product_sku": "56045",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "56045_000000077",
          "product_sku": "56045",
          "parameter_name": "Ориентация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56045_000000078",
          "product_sku": "56045",
          "parameter_name": "Монтаж",
          "parameter_value": "Пристенный"
        },
        {
          "parameter_id": "56045_000000079",
          "product_sku": "56045",
          "parameter_name": "Особенности",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56045_000000080",
          "product_sku": "56045",
          "parameter_name": "Опора",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56045_000000081",
          "product_sku": "56045",
          "parameter_name": "Панель",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56045_000000082",
          "product_sku": "56045",
          "parameter_name": "Сифон",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56045_000000083",
          "product_sku": "56045",
          "parameter_name": "Смеситель",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56045_000000084",
          "product_sku": "56045",
          "parameter_name": "Гидромассаж",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56045_000000085",
          "product_sku": "56045",
          "parameter_name": "Тип управления",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56045_000000182",
          "product_sku": "56045",
          "parameter_name": "Тип поверхности",
          "parameter_value": "Глянцевая"
        },
        {
          "parameter_id": "56045_Brand",
          "product_sku": "56045",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Украина"
        },
        {
          "parameter_id": "56045_Series",
          "product_sku": "56045",
          "parameter_name": "Серия",
          "parameter_value": "OPAL PLUS"
        }
      ]
    },
    {
      "product_sku": "056046",
      "product_categoryId": "500040",
      "product_name": "OPAL PLUS ванна 160*70см прямоугольная, без ножек",
      "product_mpn": "XWP136000N",
      "manufacturer_name": "KOLO Украина",
      "product_seria": "OPAL PLUS",
      "product_status": "Акция",
      "exchangeRate_product_source_price": [],
      "exchangeRate_product_price_online": [],
      "product_price": "2850",
      "product_currency": "UAH",
      "product_price_old": "3357.0000",
      "product_price_online": "2850",
      "sourcePrice": "2383.47",
      "sourceCurrency": "UAH",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_056046_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056046_1.jpg"
      ],
      "description": "OPAL PLUS ванна 160х70х43,2 см, прямоугольная, без ножек, акрил",
      parameters: [
        {
          "parameter_id": "56046_000000071",
          "product_sku": "56046",
          "parameter_name": "Длина",
          "parameter_value": "1 600"
        },
        {
          "parameter_id": "56046_000000072",
          "product_sku": "56046",
          "parameter_name": "Ширина",
          "parameter_value": "700"
        },
        {
          "parameter_id": "56046_000000073",
          "product_sku": "56046",
          "parameter_name": "Высота",
          "parameter_value": "432"
        },
        {
          "parameter_id": "56046_000000074",
          "product_sku": "56046",
          "parameter_name": "Материал",
          "parameter_value": "Акрил"
        },
        {
          "parameter_id": "56046_000000075",
          "product_sku": "56046",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "56046_000000076",
          "product_sku": "56046",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "56046_000000077",
          "product_sku": "56046",
          "parameter_name": "Ориентация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56046_000000078",
          "product_sku": "56046",
          "parameter_name": "Монтаж",
          "parameter_value": "Пристенный"
        },
        {
          "parameter_id": "56046_000000079",
          "product_sku": "56046",
          "parameter_name": "Особенности",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56046_000000080",
          "product_sku": "56046",
          "parameter_name": "Опора",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56046_000000081",
          "product_sku": "56046",
          "parameter_name": "Панель",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56046_000000082",
          "product_sku": "56046",
          "parameter_name": "Сифон",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56046_000000083",
          "product_sku": "56046",
          "parameter_name": "Смеситель",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56046_000000084",
          "product_sku": "56046",
          "parameter_name": "Гидромассаж",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56046_000000085",
          "product_sku": "56046",
          "parameter_name": "Тип управления",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56046_000000182",
          "product_sku": "56046",
          "parameter_name": "Тип поверхности",
          "parameter_value": "Глянцевая"
        },
        {
          "parameter_id": "56046_Brand",
          "product_sku": "56046",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Украина"
        },
        {
          "parameter_id": "56046_Series",
          "product_sku": "56046",
          "parameter_name": "Серия",
          "parameter_value": "OPAL PLUS"
        }
      ]
    },
    {
      "product_sku": "056047",
      "product_categoryId": "500040",
      "product_name": "OPAL PLUS ванна 170*70см прямоугольная, без ножек",
      "product_mpn": "XWP137000N",
      "manufacturer_name": "KOLO Украина",
      "product_seria": "OPAL PLUS",
      "product_status": "Акция",
      "exchangeRate_product_source_price": [],
      "exchangeRate_product_price_online": [],
      "product_price": "3024",
      "product_currency": "UAH",
      "product_price_old": "3561.0000",
      "product_price_online": "3024",
      "sourcePrice": "2528.31",
      "sourceCurrency": "UAH",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_056047_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056047_1.jpg"
      ],
      "description": "OPAL PLUS ванна 170х70х43,2 см, прямоугольная, без ножек, акрил",
      parameters: [
        {
          "parameter_id": "56047_000000071",
          "product_sku": "56047",
          "parameter_name": "Длина",
          "parameter_value": "1 700"
        },
        {
          "parameter_id": "56047_000000072",
          "product_sku": "56047",
          "parameter_name": "Ширина",
          "parameter_value": "700"
        },
        {
          "parameter_id": "56047_000000073",
          "product_sku": "56047",
          "parameter_name": "Высота",
          "parameter_value": "432"
        },
        {
          "parameter_id": "56047_000000074",
          "product_sku": "56047",
          "parameter_name": "Материал",
          "parameter_value": "Акрил"
        },
        {
          "parameter_id": "56047_000000075",
          "product_sku": "56047",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "56047_000000076",
          "product_sku": "56047",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "56047_000000077",
          "product_sku": "56047",
          "parameter_name": "Ориентация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56047_000000078",
          "product_sku": "56047",
          "parameter_name": "Монтаж",
          "parameter_value": "Пристенный"
        },
        {
          "parameter_id": "56047_000000079",
          "product_sku": "56047",
          "parameter_name": "Особенности",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56047_000000080",
          "product_sku": "56047",
          "parameter_name": "Опора",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56047_000000081",
          "product_sku": "56047",
          "parameter_name": "Панель",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56047_000000082",
          "product_sku": "56047",
          "parameter_name": "Сифон",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56047_000000083",
          "product_sku": "56047",
          "parameter_name": "Смеситель",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56047_000000084",
          "product_sku": "56047",
          "parameter_name": "Гидромассаж",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56047_000000085",
          "product_sku": "56047",
          "parameter_name": "Тип управления",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56047_000000182",
          "product_sku": "56047",
          "parameter_name": "Тип поверхности",
          "parameter_value": "Глянцевая"
        },
        {
          "parameter_id": "56047_Brand",
          "product_sku": "56047",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Украина"
        },
        {
          "parameter_id": "56047_Series",
          "product_sku": "56047",
          "parameter_name": "Серия",
          "parameter_value": "OPAL PLUS"
        }
      ]
    },
    {
      "product_sku": "056118",
      "product_categoryId": "400011",
      "product_name": "Набор для биде (лейка, держатель/запорный вентиль, шланг)",
      "product_mpn": "B704121",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "54",
      "product_currency": "EUR",
      "product_price_online": "1593",
      "sourcePrice": "37.80",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_056118_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056118_1.jpg"
      ],
      "description": "Гигиенический набор:\nлейка\nдержатель\nшланг 1.2 м\nповерхность: хром",
      parameters: [
        {
          "parameter_id": "56118_000000025",
          "product_sku": "56118",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "56118_Brand",
          "product_sku": "56118",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "56118_Series",
          "product_sku": "56118",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "056837",
      "product_categoryId": "40003",
      "product_name": "METROPOL смеситель для умывальника однорычажный 110, со сливным гарнитуром push-open, хром",
      "product_mpn": "32507000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "Metropol",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "268.70",
      "product_currency": "EUR",
      "product_price_online": "8061",
      "sourcePrice": "174.66",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_056837_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056837_1.jpg"
      ],
      "description": "ComfortZone 110; вынос 135 мм; обычная струя; расход воды : 5 л/ мин;  керамический узел смешивания; сливной гарнитур push-open G 1¼; регулируемое ограничение температуры; подходит для проточных водонагревателей",
      parameters: [
        {
          "parameter_id": "56837_000000117",
          "product_sku": "56837",
          "parameter_name": "Длина излива",
          "parameter_value": "135"
        },
        {
          "parameter_id": "56837_000000118",
          "product_sku": "56837",
          "parameter_name": "Высота излива",
          "parameter_value": "117"
        },
        {
          "parameter_id": "56837_000000119",
          "product_sku": "56837",
          "parameter_name": "Высота смесителя",
          "parameter_value": "184"
        },
        {
          "parameter_id": "56837_000000120",
          "product_sku": "56837",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной"
        },
        {
          "parameter_id": "56837_000000121",
          "product_sku": "56837",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "56837_000000122",
          "product_sku": "56837",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56837_000000123",
          "product_sku": "56837",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "56837_000000124",
          "product_sku": "56837",
          "parameter_name": "Наличие донного клапана",
          "parameter_value": "Да"
        },
        {
          "parameter_id": "56837_000000125",
          "product_sku": "56837",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "1"
        },
        {
          "parameter_id": "56837_Brand",
          "product_sku": "56837",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "56837_Series",
          "product_sku": "56837",
          "parameter_name": "Серия",
          "parameter_value": "Metropol"
        }
      ]
    },
    {
      "product_sku": "056839",
      "product_categoryId": "40003",
      "product_name": "METROPOL смеситель для умывальника однорычажный 260, с петлеобразной ручкой и сливн. гарнитуром push-open, хром",
      "product_mpn": "74512000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "Metropol",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "400.40",
      "product_currency": "EUR",
      "product_price_online": "12012",
      "sourcePrice": "260.26",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_056839_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056839_1.jpg"
      ],
      "description": "ComfortZone 260; вынос 204 мм; обычная струя; расход воды : 5 л/ мин;  керамический узел смешивания; сливной гарнитур push-open G 1¼; регулируемое ограничение температуры; подходит для проточных водонагревателей",
      parameters: [
        {
          "parameter_id": "56839_000000117",
          "product_sku": "56839",
          "parameter_name": "Длина излива",
          "parameter_value": "204"
        },
        {
          "parameter_id": "56839_000000118",
          "product_sku": "56839",
          "parameter_name": "Высота излива",
          "parameter_value": "259"
        },
        {
          "parameter_id": "56839_000000119",
          "product_sku": "56839",
          "parameter_name": "Высота смесителя",
          "parameter_value": "326"
        },
        {
          "parameter_id": "56839_000000120",
          "product_sku": "56839",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной"
        },
        {
          "parameter_id": "56839_000000121",
          "product_sku": "56839",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "56839_000000122",
          "product_sku": "56839",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56839_000000123",
          "product_sku": "56839",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "56839_000000124",
          "product_sku": "56839",
          "parameter_name": "Наличие донного клапана",
          "parameter_value": "Да"
        },
        {
          "parameter_id": "56839_000000125",
          "product_sku": "56839",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "1"
        },
        {
          "parameter_id": "56839_Brand",
          "product_sku": "56839",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "56839_Series",
          "product_sku": "56839",
          "parameter_name": "Серия",
          "parameter_value": "Metropol"
        }
      ]
    },
    {
      "product_sku": "056848",
      "product_categoryId": "400042",
      "product_name": "METROPOL смеситель для ванны однорычажный с петлеобразной ручкой, хром",
      "product_mpn": "74540000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "Metropol",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "347.80",
      "product_currency": "EUR",
      "product_price_online": "10434",
      "sourcePrice": "226.07",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_056848_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056848_1.jpg"
      ],
      "description": "Вынос 180 мм; вид соединения: S-образные эксцентрики; межосевое подключение: 150 мм ± 12 мм; обычная струя; расход воды: 22 л/ мин; керамический узел смешивания; регулируемое ограничение температуры, клапан обратного тока; с шумопоглотителем; подходит для проточных водонагревателей",
      parameters: [
        {
          "parameter_id": "56848_000000093",
          "product_sku": "56848",
          "parameter_name": "Длина излива",
          "parameter_value": "180"
        },
        {
          "parameter_id": "56848_000000094",
          "product_sku": "56848",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "56848_000000095",
          "product_sku": "56848",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "56848_000000096",
          "product_sku": "56848",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56848_000000097",
          "product_sku": "56848",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "56848_000000098",
          "product_sku": "56848",
          "parameter_name": "Тип переключателя ванна/душ",
          "parameter_value": "Выжимной"
        },
        {
          "parameter_id": "56848_000000099",
          "product_sku": "56848",
          "parameter_name": "Повротный излив",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56848_000000100",
          "product_sku": "56848",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "2"
        },
        {
          "parameter_id": "56848_000000126",
          "product_sku": "56848",
          "parameter_name": "Кол-во потребителей",
          "parameter_value": "2"
        },
        {
          "parameter_id": "56848_000000128",
          "product_sku": "56848",
          "parameter_name": "Форма накладки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56848_Brand",
          "product_sku": "56848",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "56848_Series",
          "product_sku": "56848",
          "parameter_name": "Серия",
          "parameter_value": "Metropol"
        }
      ]
    },
    {
      "product_sku": "056857",
      "product_categoryId": "400053",
      "product_name": "METROPOL смеситель для душа однорычажный с петлеобразной ручкой, хром",
      "product_mpn": "74560000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "Metropol",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "242.40",
      "product_currency": "EUR",
      "product_price_online": "7272",
      "sourcePrice": "157.56",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_056857_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056857_1.jpg"
      ],
      "description": "Вид соединения: S-образные эксцентрики; межосевое подключение: 150 мм ± 12 мм; расход воды: 22 л / мин; керамический узел смешивания; регулируемое ограничение температуры;  клапан обратного тока воды; с шумопоглотителем; шланговое подсоединение DN15",
      parameters: [
        {
          "parameter_id": "56857_000000101",
          "product_sku": "56857",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "56857_000000102",
          "product_sku": "56857",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56857_000000103",
          "product_sku": "56857",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "56857_000000104",
          "product_sku": "56857",
          "parameter_name": "С полочкой",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56857_000000105",
          "product_sku": "56857",
          "parameter_name": "Положение регулятора",
          "parameter_value": "Спереди по центру"
        },
        {
          "parameter_id": "56857_000000129",
          "product_sku": "56857",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "56857_000000130",
          "product_sku": "56857",
          "parameter_name": "Форма накладки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56857_Brand",
          "product_sku": "56857",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "56857_Series",
          "product_sku": "56857",
          "parameter_name": "Серия",
          "parameter_value": "Metropol"
        }
      ]
    },
    {
      "product_sku": "056927",
      "product_categoryId": "400045",
      "product_name": "Eurosmart Набор смесителей для ванны+кухня (23324001+33300002+27926000+33202002)",
      "product_mpn": "123248 МK",
      "manufacturer_name": "GROHE",
      "product_seria": "EUROSMART",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "227.08",
      "product_currency": "EUR",
      "product_price_old": "383.0000",
      "product_price_online": "6699",
      "sourcePrice": "180",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_056927_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056927_1.jpg"
      ],
      "description": "В набор входят:\nСмеситель для раковины GROHE EUROSMART 23324001\nСмеситель для ванны и душа GROHE EUROSMART NEW 33300002\nДушевой набор GROHE TEMPESTA 27926000\nКухонный смеситель GROHE EUROSMART NEW 33202002",
      parameters: [
        {
          "parameter_id": "56927_000000017",
          "product_sku": "56927",
          "parameter_name": "Назначение",
          "parameter_value": "Для ванной комнаты"
        },
        {
          "parameter_id": "56927_Brand",
          "product_sku": "56927",
          "parameter_name": "Бренд",
          "parameter_value": "GROHE"
        },
        {
          "parameter_id": "56927_Series",
          "product_sku": "56927",
          "parameter_name": "Серия",
          "parameter_value": "EUROSMART"
        }
      ]
    },
    {
      "product_sku": "056937",
      "product_categoryId": "400053",
      "product_name": "CENTRUM cмеситель для ванны, термостат, скрытый монтаж (1 потребитель), форма R",
      "product_mpn": "VRB-15400Z",
      "manufacturer_name": "IMPRESE",
      "product_seria": "CENTRUM",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "151",
      "product_currency": "EUR",
      "product_price_old": "215.0000",
      "product_price_online": "4455",
      "sourcePrice": "116",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_056937_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056937_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056937_2.jpg"
      ],
      "description": "CENTRUM cмеситель для ванны, термостат, скрытый монтаж (1 потребитель), \nФорма накладки круглая, латунь, хром.\nВнутрення часть(бокс) в комплекте.",
      parameters: [
        {
          "parameter_id": "56937_000000101",
          "product_sku": "56937",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "56937_000000102",
          "product_sku": "56937",
          "parameter_name": "Комплектация",
          "parameter_value": "Внутренняя часть"
        },
        {
          "parameter_id": "56937_000000103",
          "product_sku": "56937",
          "parameter_name": "Тип управления",
          "parameter_value": "Термостат"
        },
        {
          "parameter_id": "56937_000000104",
          "product_sku": "56937",
          "parameter_name": "С полочкой",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "56937_000000105",
          "product_sku": "56937",
          "parameter_name": "Положение регулятора",
          "parameter_value": "Спереди по центру"
        },
        {
          "parameter_id": "56937_000000129",
          "product_sku": "56937",
          "parameter_name": "Монтаж",
          "parameter_value": "Скрытый"
        },
        {
          "parameter_id": "56937_000000130",
          "product_sku": "56937",
          "parameter_name": "Форма накладки",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "56937_Brand",
          "product_sku": "56937",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "56937_Series",
          "product_sku": "56937",
          "parameter_name": "Серия",
          "parameter_value": "CENTRUM"
        }
      ]
    },
    {
      "product_sku": "056953",
      "product_categoryId": "500040",
      "product_name": "SPLIT ванна 160*90см асимметричная левая, центральный слив, с ножками",
      "product_mpn": "XWA1661000",
      "manufacturer_name": "KOLO Польша",
      "product_seria": "SPLIT",
      "product_status": null,
      "exchangeRate_product_source_price": [],
      "exchangeRate_product_price_online": [],
      "product_price": "5628",
      "product_currency": "UAH",
      "product_price_online": "5346",
      "sourcePrice": "4052.16",
      "sourceCurrency": "UAH",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_056953_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056953_1.jpg"
      ],
      "description": "SPLIT ванна 160*90*42,4 см, асимметричная, левая, центральный слив, акрил",
      parameters: [
        {
          "parameter_id": "56953_Brand",
          "product_sku": "56953",
          "parameter_name": "Бренд",
          "parameter_value": "KOLO Польша"
        },
        {
          "parameter_id": "56953_Series",
          "product_sku": "56953",
          "parameter_name": "Серия",
          "parameter_value": "SPLIT"
        }
      ]
    },
    {
      "product_sku": "056991",
      "product_categoryId": "600059",
      "product_name": "Стенка Walk-In 30*190см, каленое прозрачное стекло 8мм",
      "product_mpn": "18-07-30",
      "manufacturer_name": "VOLLE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "72",
      "product_currency": "EUR",
      "product_price_online": "2124",
      "sourcePrice": "46.80",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_056991_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056991_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056991_2.jpg"
      ],
      "description": "Стенка короткая для комплектации кабин Volle Walk-In\n•\tСтекло прозрачное\n•\tКаленое стекло, толщина 8 мм\n•\tРазмеры (ШxВ) - 300x1900 мм\n•\tВ комплект входит профиль для соединения с другой стенкой\n•\tГарантия - 3 года\nВ случае использования продукции в общественной или промышленной сферах гарантийный срок составляет 6 месяцев",
      parameters: [
        {
          "parameter_id": "56991_000000001",
          "product_sku": "56991",
          "parameter_name": "Ширина",
          "parameter_value": "300"
        },
        {
          "parameter_id": "56991_000000013",
          "product_sku": "56991",
          "parameter_name": "Материал",
          "parameter_value": "Стекло"
        },
        {
          "parameter_id": "56991_000000015",
          "product_sku": "56991",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "1 900"
        },
        {
          "parameter_id": "56991_000000018",
          "product_sku": "56991",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "56991_Brand",
          "product_sku": "56991",
          "parameter_name": "Бренд",
          "parameter_value": "VOLLE"
        },
        {
          "parameter_id": "56991_Series",
          "product_sku": "56991",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "056992",
      "product_categoryId": "600059",
      "product_name": "Стенка Walk-In 40*190см, каленое прозрачное стекло 8мм",
      "product_mpn": "18-07-40",
      "manufacturer_name": "VOLLE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "83",
      "product_currency": "EUR",
      "product_price_online": "2449",
      "sourcePrice": "53.95",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_056992_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056992_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056992_2.jpg"
      ],
      "description": "Стенка короткая для комплектации кабин Volle Walk-In 18-07-40\n•\tСтекло прозрачное\n•\tКаленое стекло, толщина 8 мм\n•\tРазмеры (ШxВ) - 400x1900 мм\n•\tВ комплект входит профиль для соединения с другой стенкой\n•\tГарантия - 3 года\nВ случае использования продукции в общественной или промышленной сферах гарантийный срок составляет 6 месяцев",
      parameters: [
        {
          "parameter_id": "56992_000000001",
          "product_sku": "56992",
          "parameter_name": "Ширина",
          "parameter_value": "400"
        },
        {
          "parameter_id": "56992_000000013",
          "product_sku": "56992",
          "parameter_name": "Материал",
          "parameter_value": "Стекло"
        },
        {
          "parameter_id": "56992_000000015",
          "product_sku": "56992",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "1 900"
        },
        {
          "parameter_id": "56992_000000018",
          "product_sku": "56992",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "56992_Brand",
          "product_sku": "56992",
          "parameter_name": "Бренд",
          "parameter_value": "VOLLE"
        },
        {
          "parameter_id": "56992_Series",
          "product_sku": "56992",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "056994",
      "product_categoryId": "600086",
      "product_name": "Держатель стекла (Е) с креплениями, 400мм",
      "product_mpn": "18-05E-40",
      "manufacturer_name": "VOLLE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "60",
      "product_currency": "EUR",
      "product_price_online": "1770",
      "sourcePrice": "39",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_056994_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056994_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056994_2.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056994_3.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056994_4.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056994_5.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056994_6.jpg"
      ],
      "description": "Короткий металлический держатель(Е) стекла кабины Volle Walk-In 18-05Е-40\n•\tКрепится перпендикулярно к другому держателю D или F\n•\tДлина 400 мм\n•\tГарантия - 3 года\nВ случае использования продукции в общественной или промышленной сферах гарантийный срок составляет 6 месяцев",
      parameters: [
        {
          "parameter_id": "56994_Brand",
          "product_sku": "56994",
          "parameter_name": "Бренд",
          "parameter_value": "VOLLE"
        },
        {
          "parameter_id": "56994_Series",
          "product_sku": "56994",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "056996",
      "product_categoryId": "600086",
      "product_name": "Держатель стекла (D) с креплениями, 1000мм",
      "product_mpn": "18-05D-100",
      "manufacturer_name": "VOLLE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "65",
      "product_currency": "EUR",
      "product_price_online": "1918",
      "sourcePrice": "42.25",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_056996_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056996_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056996_2.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056996_3.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056996_4.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056996_5.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056996_6.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056996_7.jpg"
      ],
      "description": "Длинный металлический держатель (D) стекла кабины Volle Walk-In 18-05D-100\n•\tКрепится к стене\n•\tДлина 1000 мм\n•\tГарантия - 3 года\nВ случае использования продукции в общественной или промышленной сферах гарантийный срок составляет 6 месяцев",
      parameters: [
        {
          "parameter_id": "56996_Brand",
          "product_sku": "56996",
          "parameter_name": "Бренд",
          "parameter_value": "VOLLE"
        },
        {
          "parameter_id": "56996_Series",
          "product_sku": "56996",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "056997",
      "product_categoryId": "600086",
      "product_name": "Держатель стекла (F) с креплениями, 900мм",
      "product_mpn": "18-05F-90",
      "manufacturer_name": "VOLLE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "70",
      "product_currency": "EUR",
      "product_price_online": "2065",
      "sourcePrice": "45.50",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_056997_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056997_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056997_2.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056997_3.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_056997_4.jpg"
      ],
      "description": "Длинный металлический держатель (F) стекла кабины Volle Walk-In 18-05F-90\n•\tКрепится перпендикулярно к другому держателю D или F\n•\tДлина 900 мм\n•\tГарантия - 3 года\nВ случае использования продукции в общественной или промышленной сферах гарантийный срок составляет 6 месяцев",
      parameters: [
        {
          "parameter_id": "56997_Brand",
          "product_sku": "56997",
          "parameter_name": "Бренд",
          "parameter_value": "VOLLE"
        },
        {
          "parameter_id": "56997_Series",
          "product_sku": "56997",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "056999",
      "product_categoryId": "600059",
      "product_name": "Стенка c подвижным профилем 350*1900 мм, каленое прозрачное стекло 8мм",
      "product_mpn": "18-09-35",
      "manufacturer_name": "VOLLE",
      "product_seria": "WALK-IN",
      "product_status": "Распродажа",
      "product_price": "55",
      "product_currency": "EUR",
      "product_price_old": "120.0000",
      "product_price_online": "55",
      "sourcePrice": "74.40",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_056999_0.jpg"
      ],
      "description": "Стенка c подвижным профилем 350*1900 мм, каленое прозрачное стекло 8 мм, профиль хром.",
      parameters: [
        {
          "parameter_id": "56999_000000012",
          "product_sku": "56999",
          "parameter_name": "Цвет профиля",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "56999_Brand",
          "product_sku": "56999",
          "parameter_name": "Бренд",
          "parameter_value": "VOLLE"
        },
        {
          "parameter_id": "56999_Series",
          "product_sku": "56999",
          "parameter_name": "Серия",
          "parameter_value": "WALK-IN"
        }
      ]
    },
    {
      "product_sku": "057034",
      "product_categoryId": "180004",
      "product_name": "ME BY STARCK умывальник 43*30см, мебельный, с 1м отв. под смеситель, с переливом",
      "product_mpn": "0723430000",
      "manufacturer_name": "DURAVIT",
      "product_seria": "ME BY STARCK",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 28
      },
      "exchangeRate_product_price_online": {
        "EUR": 28
      },
      "product_price": "262",
      "product_currency": "EUR",
      "product_price_online": "6602",
      "sourcePrice": "157.20",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_057034_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_057034_1.jpg"
      ],
      "description": "ME BY STARCK умывальник 43*30 см, мебельный, с 1м отверстием под смеситель, с переливом",
      parameters: [
        {
          "parameter_id": "57034_Brand",
          "product_sku": "57034",
          "parameter_name": "Бренд",
          "parameter_value": "DURAVIT"
        },
        {
          "parameter_id": "57034_Series",
          "product_sku": "57034",
          "parameter_name": "Серия",
          "parameter_value": "ME BY STARCK"
        }
      ]
    },
    {
      "product_sku": "057035",
      "product_categoryId": "800063",
      "product_name": "VERO AIR тумба 100*48см, с раковиной, без перелива, с 1м отверстием под смеситель, цвет дуб тёмный брашированный (72)",
      "product_mpn": "LC6918O7272",
      "manufacturer_name": "DURAVIT",
      "product_seria": "VERO AIR",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 28
      },
      "exchangeRate_product_price_online": {
        "EUR": 28
      },
      "product_price": "2219",
      "product_currency": "EUR",
      "product_price_online": "55919",
      "sourcePrice": "1331.40",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_057035_0.jpg"
      ],
      "description": "VERO AIR тумба 1000*480*500 мм, с раковиной, без перелива, с 1м отверстием под смеситель, цвет дуб тёмный брашированный (72), выдвижные двери, материал фасада и корпуса тумбы ДСП",
      parameters: [
        {
          "parameter_id": "57035_000000001",
          "product_sku": "57035",
          "parameter_name": "Ширина",
          "parameter_value": "1 000"
        },
        {
          "parameter_id": "57035_000000009",
          "product_sku": "57035",
          "parameter_name": "Комплектация",
          "parameter_value": "Тумба+раковина"
        },
        {
          "parameter_id": "57035_000000010",
          "product_sku": "57035",
          "parameter_name": "Тип дверей",
          "parameter_value": "Выдвижные"
        },
        {
          "parameter_id": "57035_000000013",
          "product_sku": "57035",
          "parameter_name": "Материал",
          "parameter_value": "ДСП"
        },
        {
          "parameter_id": "57035_000000014",
          "product_sku": "57035",
          "parameter_name": "Глубина",
          "parameter_value": "480"
        },
        {
          "parameter_id": "57035_000000015",
          "product_sku": "57035",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "500"
        },
        {
          "parameter_id": "57035_000000016",
          "product_sku": "57035",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "57035_000000018",
          "product_sku": "57035",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "57035_000000023",
          "product_sku": "57035",
          "parameter_name": "Тип установки смесителя",
          "parameter_value": "1 отверстие"
        },
        {
          "parameter_id": "57035_000000025",
          "product_sku": "57035",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Другие цвета"
        },
        {
          "parameter_id": "57035_000000029",
          "product_sku": "57035",
          "parameter_name": "Перелив",
          "parameter_value": "Без перелива"
        },
        {
          "parameter_id": "57035_Brand",
          "product_sku": "57035",
          "parameter_name": "Бренд",
          "parameter_value": "DURAVIT"
        },
        {
          "parameter_id": "57035_Series",
          "product_sku": "57035",
          "parameter_name": "Серия",
          "parameter_value": "VERO AIR"
        }
      ]
    },
    {
      "product_sku": "057036",
      "product_categoryId": "800047",
      "product_name": "KETHO тумба 400*285мм, подвесная, для раковины 072343, петли справа, белый глянец (22)",
      "product_mpn": "KT6417R2222",
      "manufacturer_name": "DURAVIT",
      "product_seria": "KETHO",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 28
      },
      "exchangeRate_product_price_online": {
        "EUR": 28
      },
      "product_price": "445",
      "product_currency": "EUR",
      "product_price_online": "11214",
      "sourcePrice": "267",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_057036_0.jpg"
      ],
      "description": "KETHO тумба 400*285*550 мм, подвесная, для раковины 072343, петли справа, белый глянец (22), материал фасада и корпуса ДСП",
      parameters: [
        {
          "parameter_id": "57036_000000001",
          "product_sku": "57036",
          "parameter_name": "Ширина",
          "parameter_value": "400"
        },
        {
          "parameter_id": "57036_000000010",
          "product_sku": "57036",
          "parameter_name": "Тип дверей",
          "parameter_value": "Распашные"
        },
        {
          "parameter_id": "57036_000000013",
          "product_sku": "57036",
          "parameter_name": "Материал",
          "parameter_value": "ДСП"
        },
        {
          "parameter_id": "57036_000000014",
          "product_sku": "57036",
          "parameter_name": "Глубина",
          "parameter_value": "285"
        },
        {
          "parameter_id": "57036_000000015",
          "product_sku": "57036",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "550"
        },
        {
          "parameter_id": "57036_000000016",
          "product_sku": "57036",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "57036_000000025",
          "product_sku": "57036",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Белый глянец"
        },
        {
          "parameter_id": "57036_Brand",
          "product_sku": "57036",
          "parameter_name": "Бренд",
          "parameter_value": "DURAVIT"
        },
        {
          "parameter_id": "57036_Series",
          "product_sku": "57036",
          "parameter_name": "Серия",
          "parameter_value": "KETHO"
        }
      ]
    },
    {
      "product_sku": "057076",
      "product_categoryId": "",
      "product_name": "GEBERIT сифон для душевого поддона d90, с крышкой, хром глянец",
      "product_mpn": "150.551.21.1",
      "manufacturer_name": "GEBERIT",
      "product_seria": "GEBERIT",
      "product_status": "Спеццена",
      "exchangeRate_product_source_price": [],
      "exchangeRate_product_price_online": [],
      "product_price": "1065",
      "product_currency": "UAH",
      "product_price_online": "1022",
      "sourcePrice": "798.75",
      "sourceCurrency": "UAH",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_057076_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_057076_1.jpg"
      ],
      "description": "Geberit Сифон для душевого поддона d90, хром глянец, высота гидрозатвора 50 мм, c крышкой сливного отверстия,d50 мм",
      parameters: [
        {
          "parameter_id": "57076_000000006",
          "product_sku": "57076",
          "parameter_name": "Диаметр (мм)",
          "parameter_value": "90"
        },
        {
          "parameter_id": "57076_000000013",
          "product_sku": "57076",
          "parameter_name": "Материал",
          "parameter_value": "Пластик"
        },
        {
          "parameter_id": "57076_000000018",
          "product_sku": "57076",
          "parameter_name": "Форма",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "57076_000000025",
          "product_sku": "57076",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Серый"
        },
        {
          "parameter_id": "57076_Brand",
          "product_sku": "57076",
          "parameter_name": "Бренд",
          "parameter_value": "GEBERIT"
        },
        {
          "parameter_id": "57076_Series",
          "product_sku": "57076",
          "parameter_name": "Серия",
          "parameter_value": "GEBERIT"
        }
      ]
    },
    {
      "product_sku": "057077",
      "product_categoryId": "40003",
      "product_name": "Logis E 70 Смеситель для умывальника однорычажный с донным клапаном, хром",
      "product_mpn": "71160000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "Logis E",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "80.92",
      "product_currency": "EUR",
      "product_price_online": "2428",
      "sourcePrice": "52.60",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_057077_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_057077_1.jpg"
      ],
      "description": "ComfortZone 70; выступ 107 мм; расход воды: 5 л / мин; керамический узел смешивания; регулируемое ограничение температуры; подходит для проточных\nводонагревателей, донный клапан",
      parameters: [
        {
          "parameter_id": "57077_000000117",
          "product_sku": "57077",
          "parameter_name": "Длина излива",
          "parameter_value": "100"
        },
        {
          "parameter_id": "57077_000000118",
          "product_sku": "57077",
          "parameter_name": "Высота излива",
          "parameter_value": "75"
        },
        {
          "parameter_id": "57077_000000119",
          "product_sku": "57077",
          "parameter_name": "Высота смесителя",
          "parameter_value": "145"
        },
        {
          "parameter_id": "57077_000000120",
          "product_sku": "57077",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной"
        },
        {
          "parameter_id": "57077_000000121",
          "product_sku": "57077",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "57077_000000122",
          "product_sku": "57077",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "57077_000000123",
          "product_sku": "57077",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "57077_000000124",
          "product_sku": "57077",
          "parameter_name": "Наличие донного клапана",
          "parameter_value": "Да"
        },
        {
          "parameter_id": "57077_000000125",
          "product_sku": "57077",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "1"
        },
        {
          "parameter_id": "57077_Brand",
          "product_sku": "57077",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "57077_Series",
          "product_sku": "57077",
          "parameter_name": "Серия",
          "parameter_value": "Logis E"
        }
      ]
    },
    {
      "product_sku": "057078",
      "product_categoryId": "40003",
      "product_name": "Logis E 100 Смеситель для умывальника однорычажный с донным клапаном, хром",
      "product_mpn": "71161000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "Logis E",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "102.70",
      "product_currency": "EUR",
      "product_price_online": "3081",
      "sourcePrice": "66.76",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_057078_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_057078_1.jpg"
      ],
      "description": "ComfortZone 100;  выступ 119 мм; обычная струя; расход воды: 5 л / мин; керамический узел смешивания; регулируемое ограничение температуры; подходит для проточных водонагревателей, донный клапан",
      parameters: [
        {
          "parameter_id": "57078_Brand",
          "product_sku": "57078",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "57078_Series",
          "product_sku": "57078",
          "parameter_name": "Серия",
          "parameter_value": "Logis E"
        }
      ]
    },
    {
      "product_sku": "057079",
      "product_categoryId": "400042",
      "product_name": "Logis E Смеситель для ванны однорычажный, хром",
      "product_mpn": "71403000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "Logis E",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "118.03",
      "product_currency": "EUR",
      "product_price_online": "3541",
      "sourcePrice": "76.72",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_057079_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_057079_1.jpg"
      ],
      "description": "Logis E Смеситель для ванны однорычажный, хром, керамический узел смешивания",
      parameters: [
        {
          "parameter_id": "57079_Brand",
          "product_sku": "57079",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "57079_Series",
          "product_sku": "57079",
          "parameter_name": "Серия",
          "parameter_value": "Logis E"
        }
      ]
    },
    {
      "product_sku": "057080",
      "product_categoryId": "400053",
      "product_name": "Logis E Смеситель для душа однорычажный, хром",
      "product_mpn": "71602000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "Logis E",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "95.92",
      "product_currency": "EUR",
      "product_price_online": "2878",
      "sourcePrice": "62.35",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_057080_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_057080_1.jpg"
      ],
      "description": "Logis E Смеситель для душа однорычажный, хром, керамический узел смешивания",
      parameters: [
        {
          "parameter_id": "57080_000000101",
          "product_sku": "57080",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "57080_000000102",
          "product_sku": "57080",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "57080_000000103",
          "product_sku": "57080",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "57080_000000104",
          "product_sku": "57080",
          "parameter_name": "С полочкой",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "57080_000000105",
          "product_sku": "57080",
          "parameter_name": "Положение регулятора",
          "parameter_value": "Спереди по центру"
        },
        {
          "parameter_id": "57080_000000129",
          "product_sku": "57080",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "57080_000000130",
          "product_sku": "57080",
          "parameter_name": "Форма накладки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "57080_Brand",
          "product_sku": "57080",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "57080_Series",
          "product_sku": "57080",
          "parameter_name": "Серия",
          "parameter_value": "Logis E"
        }
      ]
    },
    {
      "product_sku": "057105",
      "product_categoryId": "400010",
      "product_name": "Comfortflex Душевой шланг 1.50 м, хром",
      "product_mpn": "28160002",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "Comfortflex",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "18.62",
      "product_currency": "EUR",
      "product_price_online": "559",
      "sourcePrice": "12.10",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_057105_0.jpg"
      ],
      "description": "Comfortflex Душевой шланг 1.50 м, хром, пластик с металлическим эффектом",
      parameters: [
        {
          "parameter_id": "57105_000000013",
          "product_sku": "57105",
          "parameter_name": "Материал",
          "parameter_value": "Полимер"
        },
        {
          "parameter_id": "57105_000000015",
          "product_sku": "57105",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "1 500"
        },
        {
          "parameter_id": "57105_000000025",
          "product_sku": "57105",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "57105_Brand",
          "product_sku": "57105",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "57105_Series",
          "product_sku": "57105",
          "parameter_name": "Серия",
          "parameter_value": "Comfortflex"
        }
      ]
    },
    {
      "product_sku": "057106",
      "product_categoryId": "400010",
      "product_name": "Comfortflex Душевой шланг 1.75 м, хром",
      "product_mpn": "28162002",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "Comfortflex",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "19.03",
      "product_currency": "EUR",
      "product_price_online": "571",
      "sourcePrice": "12.37",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_057106_0.jpg"
      ],
      "description": "Comfortflex Душевой шланг 1.75 м, хром, пластик с металлическим эффектом",
      parameters: [
        {
          "parameter_id": "57106_000000013",
          "product_sku": "57106",
          "parameter_name": "Материал",
          "parameter_value": "Полимер"
        },
        {
          "parameter_id": "57106_000000015",
          "product_sku": "57106",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "1 750"
        },
        {
          "parameter_id": "57106_000000025",
          "product_sku": "57106",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "57106_Brand",
          "product_sku": "57106",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "57106_Series",
          "product_sku": "57106",
          "parameter_name": "Серия",
          "parameter_value": "Comfortflex"
        }
      ]
    },
    {
      "product_sku": "057108",
      "product_categoryId": "400072",
      "product_name": "Crometta E 240 1jet Varia Showerpipe Душевая система с термостатом, хром",
      "product_mpn": "26785000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "Crometta E 240 Varia",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "445.59",
      "product_currency": "EUR",
      "product_price_online": "13368",
      "sourcePrice": "289.63",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_057108_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_057108_1.jpg"
      ],
      "description": "Верхний душ 240x240 мм с типом струи Rain и функцией очистки QuickClean; ручной душ Crometta Vario EcoSmart с типом струи Vario и функцией  QuickClean, душевая штага, шланг для душа Isiflex 1,60 м; термостат для душа с функцией Safety Stop и запорно-переключающим клапаном.",
      parameters: [
        {
          "parameter_id": "57108_000000156",
          "product_sku": "57108",
          "parameter_name": "Ширина лейки верхнего душа, мм",
          "parameter_value": "240"
        },
        {
          "parameter_id": "57108_000000157",
          "product_sku": "57108",
          "parameter_name": "Длина лейки верхнего душа, мм",
          "parameter_value": "240"
        },
        {
          "parameter_id": "57108_000000158",
          "product_sku": "57108",
          "parameter_name": "Длина кронштейна (от стены), мм",
          "parameter_value": "352"
        },
        {
          "parameter_id": "57108_000000160",
          "product_sku": "57108",
          "parameter_name": "Мин. Высота, мм",
          "parameter_value": "1 093"
        },
        {
          "parameter_id": "57108_000000161",
          "product_sku": "57108",
          "parameter_name": "Регулируемая высота стойки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "57108_000000162",
          "product_sku": "57108",
          "parameter_name": "Форма лейки верхнего душа",
          "parameter_value": "Квадратная"
        },
        {
          "parameter_id": "57108_000000163",
          "product_sku": "57108",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "57108_000000164",
          "product_sku": "57108",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "57108_000000165",
          "product_sku": "57108",
          "parameter_name": "Тип управления",
          "parameter_value": "Термостат"
        },
        {
          "parameter_id": "57108_000000166",
          "product_sku": "57108",
          "parameter_name": "Смеситель",
          "parameter_value": "Для душа"
        },
        {
          "parameter_id": "57108_000000167",
          "product_sku": "57108",
          "parameter_name": "Кол-во режимов ручного душа",
          "parameter_value": "2"
        },
        {
          "parameter_id": "57108_000000168",
          "product_sku": "57108",
          "parameter_name": "Кол-во режимов верхнего душа",
          "parameter_value": "1"
        },
        {
          "parameter_id": "57108_Brand",
          "product_sku": "57108",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "57108_Series",
          "product_sku": "57108",
          "parameter_name": "Серия",
          "parameter_value": "Crometta E 240 Varia"
        }
      ]
    },
    {
      "product_sku": "057109",
      "product_categoryId": "400072",
      "product_name": "Crometta S 240 1jet Varia Showerpipe Душевая система с термостатом, хром",
      "product_mpn": "26781000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "Crometta S 240 Varia",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "445.59",
      "product_currency": "EUR",
      "product_price_online": "13368",
      "sourcePrice": "289.63",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_057109_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_057109_1.jpg"
      ],
      "description": "Верхний душ 240 мм с типом струи Rain и функцией очистки QuickClean; ручной душ Crometta Vario EcoSmart с типом струи Vario и функцией  QuickClean, душевая штага, шланг для душа Isiflex 1,60 м; термостат для душа с функцией Safety Stop и запорно-переключающим клапаном.",
      parameters: [
        {
          "parameter_id": "57109_Brand",
          "product_sku": "57109",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "57109_Series",
          "product_sku": "57109",
          "parameter_name": "Серия",
          "parameter_value": "Crometta S 240 Varia"
        }
      ]
    },
    {
      "product_sku": "057110",
      "product_categoryId": "400032",
      "product_name": "Logis E Смеситель для биде однорычажный, с донным клапаном, хром",
      "product_mpn": "71232000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "Logis E",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "103.04",
      "product_currency": "EUR",
      "product_price_online": "3091",
      "sourcePrice": "66.98",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_057110_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_057110_1.jpg"
      ],
      "description": "Аэратор с шарнирным соединением; обычная струя; расход воды: 7,2 л / мин; керамический узел смешивания; регулируемое ограничение температуры; донный клапан, 1¼’; подходит для проточных водонагревателей",
      parameters: [
        {
          "parameter_id": "57110_Brand",
          "product_sku": "57110",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "57110_Series",
          "product_sku": "57110",
          "parameter_name": "Серия",
          "parameter_value": "Logis E"
        }
      ]
    },
    {
      "product_sku": "057111",
      "product_categoryId": "40003",
      "product_name": "Logis E 230 Смеситель для умывальника однорычажный с донным клапаном, хром",
      "product_mpn": "71162000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "Logis E",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "152.32",
      "product_currency": "EUR",
      "product_price_online": "4570",
      "sourcePrice": "99.01",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_057111_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_057111_1.jpg"
      ],
      "description": "ComfortZone 230; выступ 185 мм; обычная струя; расход воды: 5 л / мин; керамический узел смешивания; регулируемое ограничение температуры; подходит для проточных одонагревателей, донный клапан",
      parameters: [
        {
          "parameter_id": "57111_Brand",
          "product_sku": "57111",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "57111_Series",
          "product_sku": "57111",
          "parameter_name": "Серия",
          "parameter_value": "Logis E"
        }
      ]
    },
    {
      "product_sku": "057659",
      "product_categoryId": "200031",
      "product_name": "Шумоизоляционная прокладка для подвесного унитаза и биде",
      "product_mpn": "620071",
      "manufacturer_name": "OLI",
      "product_seria": "OLI",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29
      },
      "exchangeRate_product_price_online": {
        "EUR": 29
      },
      "product_price": "5",
      "product_currency": "EUR",
      "product_price_online": "145",
      "sourcePrice": "3.25",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_057659_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_057659_1.jpg"
      ],
      "description": "OLI шумоизоляционная прокладка для подвесного унитаза и биде",
      parameters: [
        {
          "parameter_id": "57659_Brand",
          "product_sku": "57659",
          "parameter_name": "Бренд",
          "parameter_value": "OLI"
        },
        {
          "parameter_id": "57659_Series",
          "product_sku": "57659",
          "parameter_name": "Серия",
          "parameter_value": "OLI"
        }
      ]
    },
    {
      "product_sku": "057663",
      "product_categoryId": "200031",
      "product_name": "OLI запорное кольцо 60*23,8*2,7",
      "product_mpn": "49484",
      "manufacturer_name": "OLI",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29
      },
      "exchangeRate_product_price_online": {
        "EUR": 29
      },
      "product_price": "13.10",
      "product_currency": "EUR",
      "product_price_online": "380",
      "sourcePrice": "8.52",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_057663_0.jpg"
      ],
      "description": "OLI запорное кольцо 600*238*27 мм, силикон.",
      parameters: [
        {
          "parameter_id": "57663_Brand",
          "product_sku": "57663",
          "parameter_name": "Бренд",
          "parameter_value": "OLI"
        },
        {
          "parameter_id": "57663_Series",
          "product_sku": "57663",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "057664",
      "product_categoryId": "200043",
      "product_name": "Инсталляция для подвесного унитаза",
      "product_mpn": "i5220",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "124",
      "product_currency": "EUR",
      "product_price_online": "3658",
      "sourcePrice": "96.72",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_057664_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_057664_1.jpg"
      ],
      "description": "Инсталляция для подвесного унитаза:\nДвойной смыв 6/3 литра (регулируемый 7/3 и 4/2 л)\nМеталлические крепления к несущей стене\nМеханический привод клавиш смыва\nРабочее давление в сети от 0,1 до 16 бар\nУстойчивость к атмосферной влажности (RH < 90%)\nИзготовлен из высокопрочного полипропилена\nБесшумный, класс 1 сертифицирован NF\nСертифицирован по стандарту CE EN 14055 Class CL1 в соответствии с правилами DIN / NF KIWA\nПоставляется с анти-конденсационной и акустической изоляцией\nНагрузка 400 кг\nФановый отвод для слива с переходником ø90/110\nG1/2” запорный клапан",
      parameters: [
        {
          "parameter_id": "57664_000000001",
          "product_sku": "57664",
          "parameter_name": "Ширина",
          "parameter_value": "500"
        },
        {
          "parameter_id": "57664_000000014",
          "product_sku": "57664",
          "parameter_name": "Глубина",
          "parameter_value": "110"
        },
        {
          "parameter_id": "57664_000000015",
          "product_sku": "57664",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "1 150"
        },
        {
          "parameter_id": "57664_000000017",
          "product_sku": "57664",
          "parameter_name": "Назначение",
          "parameter_value": "Для подвесного унитаза"
        },
        {
          "parameter_id": "57664_000000022",
          "product_sku": "57664",
          "parameter_name": "Тип управления",
          "parameter_value": "Механический"
        },
        {
          "parameter_id": "57664_Brand",
          "product_sku": "57664",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "57664_Series",
          "product_sku": "57664",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "057665",
      "product_categoryId": "20006",
      "product_name": "PAN клавиша смыва",
      "product_mpn": "i8100",
      "manufacturer_name": "IMPRESE",
      "product_seria": "LASKA",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "50",
      "product_currency": "EUR",
      "product_price_online": "1475",
      "sourcePrice": "39",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_057665_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_057665_1.jpg"
      ],
      "description": "PAN Laska клавиша смыва 185*120 мм, прямоугольная, пластик, двойной смыв, для подвесного унитаза.",
      parameters: [
        {
          "parameter_id": "57665_000000001",
          "product_sku": "57665",
          "parameter_name": "Ширина",
          "parameter_value": "185"
        },
        {
          "parameter_id": "57665_000000013",
          "product_sku": "57665",
          "parameter_name": "Материал",
          "parameter_value": "Пластик"
        },
        {
          "parameter_id": "57665_000000015",
          "product_sku": "57665",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "120"
        },
        {
          "parameter_id": "57665_000000017",
          "product_sku": "57665",
          "parameter_name": "Назначение",
          "parameter_value": "Для подвесного унитаза"
        },
        {
          "parameter_id": "57665_000000018",
          "product_sku": "57665",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "57665_000000020",
          "product_sku": "57665",
          "parameter_name": "Тип слива",
          "parameter_value": "Двойной"
        },
        {
          "parameter_id": "57665_000000025",
          "product_sku": "57665",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "57665_Brand",
          "product_sku": "57665",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "57665_Series",
          "product_sku": "57665",
          "parameter_name": "Серия",
          "parameter_value": "LASKA"
        }
      ]
    },
    {
      "product_sku": "057667",
      "product_categoryId": "20006",
      "product_name": "PAN Laska Bila клавиша смыва, белый",
      "product_mpn": "i8040W",
      "manufacturer_name": "IMPRESE",
      "product_seria": "LASKA",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "47",
      "product_currency": "EUR",
      "product_price_online": "1387",
      "sourcePrice": "36.66",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_057667_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_057667_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_057667_2.jpg"
      ],
      "description": "PAN Laska bila клавиша смыва 185*120 мм, для подвесного унитаза, пластик, цвет белый.",
      parameters: [
        {
          "parameter_id": "57667_000000001",
          "product_sku": "57667",
          "parameter_name": "Ширина",
          "parameter_value": "185"
        },
        {
          "parameter_id": "57667_000000013",
          "product_sku": "57667",
          "parameter_name": "Материал",
          "parameter_value": "Пластик"
        },
        {
          "parameter_id": "57667_000000015",
          "product_sku": "57667",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "120"
        },
        {
          "parameter_id": "57667_000000017",
          "product_sku": "57667",
          "parameter_name": "Назначение",
          "parameter_value": "Для подвесного унитаза"
        },
        {
          "parameter_id": "57667_000000018",
          "product_sku": "57667",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "57667_000000020",
          "product_sku": "57667",
          "parameter_name": "Тип слива",
          "parameter_value": "Двойной"
        },
        {
          "parameter_id": "57667_000000025",
          "product_sku": "57667",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "57667_Brand",
          "product_sku": "57667",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "57667_Series",
          "product_sku": "57667",
          "parameter_name": "Серия",
          "parameter_value": "LASKA"
        }
      ]
    },
    {
      "product_sku": "057710",
      "product_categoryId": "400070",
      "product_name": "Душ верхний 300 мм, 2 мм, сталь",
      "product_mpn": "S300SS2",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "66",
      "product_currency": "EUR",
      "product_price_online": "1947",
      "sourcePrice": "46.20",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_057710_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_057710_1.jpg"
      ],
      "description": "Производитель Imprese - относительно молодая чешская компания, официально представленная на Украине с 2009года. Украинский рынок - приоритетное направление для компании. Именно поэтому Imprese учитывает в процессе производства вкусы и предпочтения украинского покупателя, а качество продукции, отвечая высоким европейским стандартам, рассчитано на особенности и состояние системы водоснабжения страны приоритетного покупателя. Все модели Imprese выверенны, производитель старался достичь той золотой середины, где обеспечивается надежность, придается утонченность формам и сохраняется доступная цена.\nОсновные характеристики:\nлейка 300 мм\nповерхность: зеркальная, хром\nматериал: нержавеющая сталь\nтолщина 6мм\nEasy clean.",
      parameters: [
        {
          "parameter_id": "57710_000000142",
          "product_sku": "57710",
          "parameter_name": "Длина лейки верхнего душа, мм",
          "parameter_value": "300"
        },
        {
          "parameter_id": "57710_000000143",
          "product_sku": "57710",
          "parameter_name": "Длина кронштейна (от стены), мм",
          "parameter_value": "0"
        },
        {
          "parameter_id": "57710_000000144",
          "product_sku": "57710",
          "parameter_name": "Ширина лейки верхнего душа, мм",
          "parameter_value": "300"
        },
        {
          "parameter_id": "57710_000000145",
          "product_sku": "57710",
          "parameter_name": "Материал лейки",
          "parameter_value": "Металл"
        },
        {
          "parameter_id": "57710_000000146",
          "product_sku": "57710",
          "parameter_name": "Форма лейки верхнего душа",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "57710_000000147",
          "product_sku": "57710",
          "parameter_name": "Монтаж",
          "parameter_value": "Универсальный"
        },
        {
          "parameter_id": "57710_000000148",
          "product_sku": "57710",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "57710_000000149",
          "product_sku": "57710",
          "parameter_name": "Кол-во режимов верхнего душа",
          "parameter_value": "1"
        },
        {
          "parameter_id": "57710_Brand",
          "product_sku": "57710",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "57710_Series",
          "product_sku": "57710",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "057711",
      "product_categoryId": "400070",
      "product_name": "Душ верхний 400 мм, 2 мм, сталь",
      "product_mpn": "S400SS2",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "88",
      "product_currency": "EUR",
      "product_price_online": "2596",
      "sourcePrice": "61.60",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_057711_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_057711_1.jpg"
      ],
      "description": "Основные характеристики:\nлейка 400 мм\nповерхность: зеркальная, хром\nматериал: нержавеющая сталь\nтолщина 6мм\nEasy clean.",
      parameters: [
        {
          "parameter_id": "57711_000000142",
          "product_sku": "57711",
          "parameter_name": "Длина лейки верхнего душа, мм",
          "parameter_value": "400"
        },
        {
          "parameter_id": "57711_000000143",
          "product_sku": "57711",
          "parameter_name": "Длина кронштейна (от стены), мм",
          "parameter_value": "0"
        },
        {
          "parameter_id": "57711_000000144",
          "product_sku": "57711",
          "parameter_name": "Ширина лейки верхнего душа, мм",
          "parameter_value": "400"
        },
        {
          "parameter_id": "57711_000000145",
          "product_sku": "57711",
          "parameter_name": "Материал лейки",
          "parameter_value": "Металл"
        },
        {
          "parameter_id": "57711_000000146",
          "product_sku": "57711",
          "parameter_name": "Форма лейки верхнего душа",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "57711_000000147",
          "product_sku": "57711",
          "parameter_name": "Монтаж",
          "parameter_value": "Универсальный"
        },
        {
          "parameter_id": "57711_000000148",
          "product_sku": "57711",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "57711_000000149",
          "product_sku": "57711",
          "parameter_name": "Кол-во режимов верхнего душа",
          "parameter_value": "1"
        },
        {
          "parameter_id": "57711_Brand",
          "product_sku": "57711",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "57711_Series",
          "product_sku": "57711",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "057712",
      "product_categoryId": "400070",
      "product_name": "Душ верхний 400х400 мм, 2 мм, сталь",
      "product_mpn": "SQ400SS2",
      "manufacturer_name": "IMPRESE",
      "product_seria": "",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "98",
      "product_currency": "EUR",
      "product_price_online": "2891",
      "sourcePrice": "68.60",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_057712_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_057712_1.jpg"
      ],
      "description": "Верхний душ Imprese 40x40 см (SQ400SS2) - продукт одной из известных чешских компаний Imprese. Особенностями продукции Imprese являются качество, которое отвечает европейским стандартам, функциональность характеристик и уникальный дизайн каждого из товаров. \nДополнительная характеристика:\nразмеры душевой головки 400x400 мм\nквадратной формы\nматериал: нержавеющая сталь\nзеркальная поверхность хром\nзащита от загрязнений Easy clean\nтип струи: ливень\nподвод 1/2\"\nмонтаж: на держатель.",
      parameters: [
        {
          "parameter_id": "57712_000000142",
          "product_sku": "57712",
          "parameter_name": "Длина лейки верхнего душа, мм",
          "parameter_value": "400"
        },
        {
          "parameter_id": "57712_000000143",
          "product_sku": "57712",
          "parameter_name": "Длина кронштейна (от стены), мм",
          "parameter_value": "0"
        },
        {
          "parameter_id": "57712_000000144",
          "product_sku": "57712",
          "parameter_name": "Ширина лейки верхнего душа, мм",
          "parameter_value": "400"
        },
        {
          "parameter_id": "57712_000000145",
          "product_sku": "57712",
          "parameter_name": "Материал лейки",
          "parameter_value": "Металл"
        },
        {
          "parameter_id": "57712_000000146",
          "product_sku": "57712",
          "parameter_name": "Форма лейки верхнего душа",
          "parameter_value": "Квадратная"
        },
        {
          "parameter_id": "57712_000000147",
          "product_sku": "57712",
          "parameter_name": "Монтаж",
          "parameter_value": "Универсальный"
        },
        {
          "parameter_id": "57712_000000148",
          "product_sku": "57712",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "57712_000000149",
          "product_sku": "57712",
          "parameter_name": "Кол-во режимов верхнего душа",
          "parameter_value": "1"
        },
        {
          "parameter_id": "57712_Brand",
          "product_sku": "57712",
          "parameter_name": "Бренд",
          "parameter_value": "IMPRESE"
        },
        {
          "parameter_id": "57712_Series",
          "product_sku": "57712",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "057863",
      "product_categoryId": "400072",
      "product_name": "NEMO система душевая без смесителя (верхний и ручной душ 1 режим, шланг 1,5 м)",
      "product_mpn": "15149100",
      "manufacturer_name": "VOLLE",
      "product_seria": "NEMO",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "130",
      "product_currency": "EUR",
      "product_price_online": "3835",
      "sourcePrice": "84.50",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_057863_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_057863_1.jpg"
      ],
      "description": "Душевая система без смесителя Volle Nemo 15149100\nХарактеристики:\n•\tТип монтажа - настенный\n•\tМатериал трубы - нержавеющая сталь\n•\tМатериал лейки верхнего душа - ABS пластик\n•\tМатериал лейки ручного душа - ABS пластик\n•\tМатериал шланга - ПВХ в металлической оплётке с латунными фитингами\n•\tМатериал держателя лейки - ABS пластик\n•\tПокрытие - хром\n•\t1 режим струи\nКомплектация:\n•\tДушевая труба с держателем\n•\tВерхний душ - диаметр лейки 200 мм\n•\tРучной душ\n•\tШланг 1,5 м\nДизайн изделия отвечает современным тенденциям в области интерьеров ванных комнат и основным требованиям эргономичности. Оно спроектировано в соответствии с концепцией ТМ Volle и потому великолепно сочетается с большинством коллекций сантехники.\nГарантия: 2 годa\nВ случае использования продукции в общественной или промышленной сферах гарантийный срок составляет 6 месяцев",
      parameters: [
        {
          "parameter_id": "57863_000000156",
          "product_sku": "57863",
          "parameter_name": "Ширина лейки верхнего душа, мм",
          "parameter_value": "200"
        },
        {
          "parameter_id": "57863_000000157",
          "product_sku": "57863",
          "parameter_name": "Длина лейки верхнего душа, мм",
          "parameter_value": "200"
        },
        {
          "parameter_id": "57863_000000158",
          "product_sku": "57863",
          "parameter_name": "Длина кронштейна (от стены), мм",
          "parameter_value": "398"
        },
        {
          "parameter_id": "57863_000000160",
          "product_sku": "57863",
          "parameter_name": "Мин. Высота, мм",
          "parameter_value": "950"
        },
        {
          "parameter_id": "57863_000000161",
          "product_sku": "57863",
          "parameter_name": "Регулируемая высота стойки",
          "parameter_value": "Да"
        },
        {
          "parameter_id": "57863_000000162",
          "product_sku": "57863",
          "parameter_name": "Форма лейки верхнего душа",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "57863_000000163",
          "product_sku": "57863",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "57863_000000164",
          "product_sku": "57863",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "57863_000000165",
          "product_sku": "57863",
          "parameter_name": "Тип управления",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "57863_000000166",
          "product_sku": "57863",
          "parameter_name": "Смеситель",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "57863_000000167",
          "product_sku": "57863",
          "parameter_name": "Кол-во режимов ручного душа",
          "parameter_value": "1"
        },
        {
          "parameter_id": "57863_000000168",
          "product_sku": "57863",
          "parameter_name": "Кол-во режимов верхнего душа",
          "parameter_value": "1"
        },
        {
          "parameter_id": "57863_Brand",
          "product_sku": "57863",
          "parameter_name": "Бренд",
          "parameter_value": "VOLLE"
        },
        {
          "parameter_id": "57863_Series",
          "product_sku": "57863",
          "parameter_name": "Серия",
          "parameter_value": "NEMO"
        }
      ]
    },
    {
      "product_sku": "057881",
      "product_categoryId": "400042",
      "product_name": "METROPOL смеситель для ванны однорычажный с дугообразной ручкой, скрытый монтаж, хром",
      "product_mpn": "74545000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "Metropol",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "242.40",
      "product_currency": "EUR",
      "product_price_online": "7272",
      "sourcePrice": "157.56",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_057881_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_057881_1.jpg"
      ],
      "description": "Metropol cмеситель для ванны однорычажный с дугообразной ручкой, скрытый монтаж, латунь, цвет - хром.\nВстраиваемая часть в комплект не входит. Необходимо комплектовать 01800180",
      parameters: [
        {
          "parameter_id": "57881_000000093",
          "product_sku": "57881",
          "parameter_name": "Длина излива",
          "parameter_value": "0"
        },
        {
          "parameter_id": "57881_000000094",
          "product_sku": "57881",
          "parameter_name": "Монтаж",
          "parameter_value": "Скрытый"
        },
        {
          "parameter_id": "57881_000000095",
          "product_sku": "57881",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "57881_000000096",
          "product_sku": "57881",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "57881_000000097",
          "product_sku": "57881",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "57881_000000098",
          "product_sku": "57881",
          "parameter_name": "Тип переключателя ванна/душ",
          "parameter_value": "Выжимной"
        },
        {
          "parameter_id": "57881_000000099",
          "product_sku": "57881",
          "parameter_name": "Повротный излив",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "57881_000000100",
          "product_sku": "57881",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "1"
        },
        {
          "parameter_id": "57881_000000126",
          "product_sku": "57881",
          "parameter_name": "Кол-во потребителей",
          "parameter_value": "2"
        },
        {
          "parameter_id": "57881_000000128",
          "product_sku": "57881",
          "parameter_name": "Форма накладки",
          "parameter_value": "Квадратная"
        },
        {
          "parameter_id": "57881_Brand",
          "product_sku": "57881",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "57881_Series",
          "product_sku": "57881",
          "parameter_name": "Серия",
          "parameter_value": "Metropol"
        }
      ]
    },
    {
      "product_sku": "057911",
      "product_categoryId": "11000111",
      "product_name": "Axor Citterio E Термостат 12 x 12, скрытый монтаж, хром",
      "product_mpn": "36702000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "AXOR CITTERIO E",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "429.80",
      "product_currency": "EUR",
      "product_price_online": "12249",
      "sourcePrice": "279.37",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_057911_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_057911_1.jpg"
      ],
      "description": "Картридж термостата; предохранительный ограничитель при 40° C; регулируемое ограничение температуры; расход воды: 59 л / мин; комплект поставки: рукоятка, гильза, металлическая розетка; клапан обратного тока воды; материал: металл; класс шума: I; класс расхода воды: A, C",
      parameters: [
        {
          "parameter_id": "57911_000000016",
          "product_sku": "57911",
          "parameter_name": "Монтаж",
          "parameter_value": "Встраиваемый в стену"
        },
        {
          "parameter_id": "57911_000000022",
          "product_sku": "57911",
          "parameter_name": "Тип управления",
          "parameter_value": "Термостат"
        },
        {
          "parameter_id": "57911_000000025",
          "product_sku": "57911",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "57911_Brand",
          "product_sku": "57911",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "57911_Series",
          "product_sku": "57911",
          "parameter_name": "Серия",
          "parameter_value": "AXOR CITTERIO E"
        }
      ]
    },
    {
      "product_sku": "057920",
      "product_categoryId": "400053",
      "product_name": "Metropol Classic Смеситель для душа однорычажный, с рычаговой рукояткой, СМ, хром/под золото",
      "product_mpn": "31365090",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "Metropol Classic",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "348",
      "product_currency": "EUR",
      "product_price_online": "10440",
      "sourcePrice": "226.20",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_057920_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_057920_1.jpg"
      ],
      "description": "Вид соединения: скрытая часть; керамический узел смешивания; регулируемое ограничение температуры; класс шума: I; класс расхода воды: B; комплект поставки: розетка, рукоятка, гильза, функциональный блок.",
      parameters: [
        {
          "parameter_id": "57920_Brand",
          "product_sku": "57920",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "57920_Series",
          "product_sku": "57920",
          "parameter_name": "Серия",
          "parameter_value": "Metropol Classic"
        }
      ]
    },
    {
      "product_sku": "058526",
      "product_categoryId": "400042",
      "product_name": "Grohtherm SmartControl термостат встраеваемый на 3 выхода",
      "product_mpn": "29126000",
      "manufacturer_name": "GROHE",
      "product_seria": "SMARTCONTROL",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 29.5
      },
      "exchangeRate_product_price_online": {
        "EUR": 29.5
      },
      "product_price": "406.75",
      "product_currency": "EUR",
      "product_price_old": "603.0000",
      "product_price_online": "11999",
      "sourcePrice": "299",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_058526_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_058526_1.jpg"
      ],
      "description": "Grohtherm SmartControl термостат встраеваемый на 3 выхода, встроенный обратный клапан для защиты от обратного потока, грязеулавливающий фильтр, ограничитель температуры воды, розетка, ручка.\nКомплектация:\nвстроенный обратный клапан для защиты от обратного потока\nгрязеулавливающий фильтр\nограничитель температуры воды\nрозетка\nручка\nВстраиваемая часть в комплект не входит. Необходимо комплектовать 35600000",
      parameters: [
        {
          "parameter_id": "58526_000000093",
          "product_sku": "58526",
          "parameter_name": "Длина излива",
          "parameter_value": "0"
        },
        {
          "parameter_id": "58526_000000094",
          "product_sku": "58526",
          "parameter_name": "Монтаж",
          "parameter_value": "Скрытый"
        },
        {
          "parameter_id": "58526_000000095",
          "product_sku": "58526",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "58526_000000096",
          "product_sku": "58526",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "58526_000000097",
          "product_sku": "58526",
          "parameter_name": "Тип управления",
          "parameter_value": "Термостат"
        },
        {
          "parameter_id": "58526_000000098",
          "product_sku": "58526",
          "parameter_name": "Тип переключателя ванна/душ",
          "parameter_value": "Нажимной"
        },
        {
          "parameter_id": "58526_000000099",
          "product_sku": "58526",
          "parameter_name": "Повротный излив",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "58526_000000100",
          "product_sku": "58526",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "1"
        },
        {
          "parameter_id": "58526_000000126",
          "product_sku": "58526",
          "parameter_name": "Кол-во потребителей",
          "parameter_value": "3"
        },
        {
          "parameter_id": "58526_000000128",
          "product_sku": "58526",
          "parameter_name": "Форма накладки",
          "parameter_value": "Квадратная"
        },
        {
          "parameter_id": "58526_Brand",
          "product_sku": "58526",
          "parameter_name": "Бренд",
          "parameter_value": "GROHE"
        },
        {
          "parameter_id": "58526_Series",
          "product_sku": "58526",
          "parameter_name": "Серия",
          "parameter_value": "SMARTCONTROL"
        }
      ]
    },
    {
      "product_sku": "058562",
      "product_categoryId": "20006",
      "product_name": "Type70 Дистанционная клавиша смыва, двойной смыв, для Sigma бачков 12 см, стекло белое",
      "product_mpn": "115.630.SI.1",
      "manufacturer_name": "GEBERIT",
      "product_seria": "TYPE70",
      "product_status": null,
      "exchangeRate_product_source_price": {
        "EUR": 32
      },
      "exchangeRate_product_price_online": {
        "EUR": 32
      },
      "product_price": "14196",
      "product_currency": "UAH",
      "product_price_online": "14196",
      "sourcePrice": "9227.40",
      "sourceCurrency": "UAH",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_058562_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_058562_1.jpg"
      ],
      "description": "Дистанционная клавиша смыва type 70, двойной смыв, для Sigma бачков 120 мм, стекло белое.",
      parameters: [
        {
          "parameter_id": "58562_000000001",
          "product_sku": "58562",
          "parameter_name": "Ширина",
          "parameter_value": "112"
        },
        {
          "parameter_id": "58562_000000013",
          "product_sku": "58562",
          "parameter_name": "Материал",
          "parameter_value": "Стекло"
        },
        {
          "parameter_id": "58562_000000015",
          "product_sku": "58562",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "50"
        },
        {
          "parameter_id": "58562_000000017",
          "product_sku": "58562",
          "parameter_name": "Назначение",
          "parameter_value": "Для подвесного унитаза"
        },
        {
          "parameter_id": "58562_000000018",
          "product_sku": "58562",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "58562_000000020",
          "product_sku": "58562",
          "parameter_name": "Тип слива",
          "parameter_value": "Двойной"
        },
        {
          "parameter_id": "58562_000000022",
          "product_sku": "58562",
          "parameter_name": "Тип управления",
          "parameter_value": "Пневматический"
        },
        {
          "parameter_id": "58562_000000025",
          "product_sku": "58562",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "58562_Brand",
          "product_sku": "58562",
          "parameter_name": "Бренд",
          "parameter_value": "GEBERIT"
        },
        {
          "parameter_id": "58562_Series",
          "product_sku": "58562",
          "parameter_name": "Серия",
          "parameter_value": "TYPE70"
        }
      ]
    },
    {
      "product_sku": "058587",
      "product_categoryId": "400072",
      "product_name": "Crometta S 240 1jet Showerpipe Душевая система с однорычажным смесителем, хром",
      "product_mpn": "27269000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "Crometta S",
      "product_status": "Акция",
      "exchangeRate_product_source_price": {
        "EUR": 30
      },
      "exchangeRate_product_price_online": {
        "EUR": 30
      },
      "product_price": "270.13",
      "product_currency": "EUR",
      "product_price_old": "391.5000",
      "product_price_online": "8104",
      "sourcePrice": "216.10",
      "sourceCurrency": "EUR",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_058587_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_058587_1.jpg"
      ],
      "description": "Регулируемый ограничитель температуры горячей воды; верхний душ Crometta S 240; размер душевого диска: 240 мм; регулируемый угол верхнего душа; тип струи: Rain; расход воды для струи Rain (при 3 бар): 15 л / мин; полностью хромированный душевой диск; длина держателя для душа: 350 мм; регулируемое по высоте крепление ручного душа; вид монтажа: наружный монтаж; величина соединения DN15; соединительная резьба G ½; межосевое подключение 150 мм ± 12 мм;  керамический узел смешивания; регулируемое ограничение температуры; класс шума: I; класс расхода воды: O, B.",
      parameters: [
        {
          "parameter_id": "58587_000000156",
          "product_sku": "58587",
          "parameter_name": "Ширина лейки верхнего душа, мм",
          "parameter_value": "240"
        },
        {
          "parameter_id": "58587_000000157",
          "product_sku": "58587",
          "parameter_name": "Длина лейки верхнего душа, мм",
          "parameter_value": "240"
        },
        {
          "parameter_id": "58587_000000158",
          "product_sku": "58587",
          "parameter_name": "Длина кронштейна (от стены), мм",
          "parameter_value": "352"
        },
        {
          "parameter_id": "58587_000000160",
          "product_sku": "58587",
          "parameter_name": "Мин. Высота, мм",
          "parameter_value": "1 191"
        },
        {
          "parameter_id": "58587_000000161",
          "product_sku": "58587",
          "parameter_name": "Регулируемая высота стойки",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "58587_000000162",
          "product_sku": "58587",
          "parameter_name": "Форма лейки верхнего душа",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "58587_000000163",
          "product_sku": "58587",
          "parameter_name": "Монтаж",
          "parameter_value": "Настенный"
        },
        {
          "parameter_id": "58587_000000164",
          "product_sku": "58587",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "58587_000000165",
          "product_sku": "58587",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "58587_000000166",
          "product_sku": "58587",
          "parameter_name": "Смеситель",
          "parameter_value": "Для душа"
        },
        {
          "parameter_id": "58587_000000167",
          "product_sku": "58587",
          "parameter_name": "Кол-во режимов ручного душа",
          "parameter_value": "1"
        },
        {
          "parameter_id": "58587_000000168",
          "product_sku": "58587",
          "parameter_name": "Кол-во режимов верхнего душа",
          "parameter_value": "1"
        },
        {
          "parameter_id": "58587_Brand",
          "product_sku": "58587",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "58587_Series",
          "product_sku": "58587",
          "parameter_name": "Серия",
          "parameter_value": "Crometta S"
        }
      ]
    },
    {
      "product_sku": "058646",
      "product_categoryId": "40003",
      "product_name": "Metropol Смеситель для умывальника однорычажный с дугообразной ручкой и изливом 225 мм, настен. монтаж, хром",
      "product_mpn": "74526000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "Metropol",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_058646_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_058646_1.jpg"
      ],
      "description": "C возможностью размещения рукоятки справа или слева, выступ 225 мм, обычная струя, расход воды: 5 л/мин. Универсальное размещение системы смешивания по выбору слева или справа от излива, незапираемый сливной клапан, подходит для проточных водонагревателей.\nВстраиваемая часть в комплект не входит. Необходимо комплектовать 13622180",
      parameters: [
        {
          "parameter_id": "58646_000000117",
          "product_sku": "58646",
          "parameter_name": "Длина излива",
          "parameter_value": "225"
        },
        {
          "parameter_id": "58646_000000118",
          "product_sku": "58646",
          "parameter_name": "Высота излива",
          "parameter_value": "0"
        },
        {
          "parameter_id": "58646_000000119",
          "product_sku": "58646",
          "parameter_name": "Высота смесителя",
          "parameter_value": "0"
        },
        {
          "parameter_id": "58646_000000120",
          "product_sku": "58646",
          "parameter_name": "Монтаж",
          "parameter_value": "Скрытый"
        },
        {
          "parameter_id": "58646_000000121",
          "product_sku": "58646",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "58646_000000122",
          "product_sku": "58646",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "58646_000000123",
          "product_sku": "58646",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "58646_000000124",
          "product_sku": "58646",
          "parameter_name": "Наличие донного клапана",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "58646_000000125",
          "product_sku": "58646",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "2"
        },
        {
          "parameter_id": "58646_Brand",
          "product_sku": "58646",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "58646_Series",
          "product_sku": "58646",
          "parameter_name": "Серия",
          "parameter_value": "Metropol"
        }
      ]
    },
    {
      "product_sku": "058653",
      "product_categoryId": "40003",
      "product_name": "Metropol Смеситель для умывальника однорычажный с изливом 225 мм, настенный монтаж, хром",
      "product_mpn": "32526000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "Metropol",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_058653_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_058653_1.jpg"
      ],
      "description": "Metropol cмеситель для раковины однорычажный с изливом 225 мм, настенный монтаж, цвет - хром.\nС возможностью размещения рукоятки справа или слева, выступ 225 мм, обычная струя, расход воды: 5 л/мин, универсальное размещение системы смешивания по выбору слева или справа от излива,\nнезапираемый сливной клапан, подходит для проточных водонагревателей.\nВстраиваемая часть в комплект не входит. Необходимо комплектовать 13622180",
      parameters: [
        {
          "parameter_id": "58653_000000117",
          "product_sku": "58653",
          "parameter_name": "Длина излива",
          "parameter_value": "240"
        },
        {
          "parameter_id": "58653_000000118",
          "product_sku": "58653",
          "parameter_name": "Высота излива",
          "parameter_value": "0"
        },
        {
          "parameter_id": "58653_000000119",
          "product_sku": "58653",
          "parameter_name": "Высота смесителя",
          "parameter_value": "0"
        },
        {
          "parameter_id": "58653_000000120",
          "product_sku": "58653",
          "parameter_name": "Монтаж",
          "parameter_value": "Скрытый"
        },
        {
          "parameter_id": "58653_000000121",
          "product_sku": "58653",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "58653_000000122",
          "product_sku": "58653",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "58653_000000123",
          "product_sku": "58653",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "58653_000000124",
          "product_sku": "58653",
          "parameter_name": "Наличие донного клапана",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "58653_000000125",
          "product_sku": "58653",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "2"
        },
        {
          "parameter_id": "58653_Brand",
          "product_sku": "58653",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "58653_Series",
          "product_sku": "58653",
          "parameter_name": "Серия",
          "parameter_value": "Metropol"
        }
      ]
    },
    {
      "product_sku": "058696",
      "product_categoryId": "180004",
      "product_name": "VOLLE умывальник 35,5*35,5*12,5см, накладной, круглый, матовый",
      "product_mpn": "13-01M-040",
      "manufacturer_name": "VOLLE",
      "product_seria": "",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_058696_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_058696_1.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_058696_2.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_058696_3.jpg"
      ],
      "description": "VOLLE умывальник 355*355*125 мм, накладной, круглый, без перелива, без отверстия смесителя, матовый.",
      parameters: [
        {
          "parameter_id": "58696_000000058",
          "product_sku": "58696",
          "parameter_name": "Ширина",
          "parameter_value": "355"
        },
        {
          "parameter_id": "58696_000000059",
          "product_sku": "58696",
          "parameter_name": "Глубина",
          "parameter_value": "355"
        },
        {
          "parameter_id": "58696_000000060",
          "product_sku": "58696",
          "parameter_name": "Высота",
          "parameter_value": "125"
        },
        {
          "parameter_id": "58696_000000061",
          "product_sku": "58696",
          "parameter_name": "Монтаж",
          "parameter_value": "На столешницу"
        },
        {
          "parameter_id": "58696_000000062",
          "product_sku": "58696",
          "parameter_name": "Форма",
          "parameter_value": "Круглая"
        },
        {
          "parameter_id": "58696_000000063",
          "product_sku": "58696",
          "parameter_name": "Особенности формы",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "58696_000000064",
          "product_sku": "58696",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Белый"
        },
        {
          "parameter_id": "58696_000000065",
          "product_sku": "58696",
          "parameter_name": "Комплектация",
          "parameter_value": "нет"
        },
        {
          "parameter_id": "58696_000000066",
          "product_sku": "58696",
          "parameter_name": "Материал",
          "parameter_value": "Керамика"
        },
        {
          "parameter_id": "58696_000000067",
          "product_sku": "58696",
          "parameter_name": "Перелив",
          "parameter_value": "Без перелива"
        },
        {
          "parameter_id": "58696_000000068",
          "product_sku": "58696",
          "parameter_name": "Отверстия под смеситель",
          "parameter_value": "Без отверстия"
        },
        {
          "parameter_id": "58696_000000069",
          "product_sku": "58696",
          "parameter_name": "Кол-во смесителей",
          "parameter_value": "Без отверстия"
        },
        {
          "parameter_id": "58696_000000070",
          "product_sku": "58696",
          "parameter_name": "Особенности",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "58696_Brand",
          "product_sku": "58696",
          "parameter_name": "Бренд",
          "parameter_value": "VOLLE"
        },
        {
          "parameter_id": "58696_Series",
          "product_sku": "58696",
          "parameter_name": "Серия",
          "parameter_value": ""
        }
      ]
    },
    {
      "product_sku": "058716",
      "product_categoryId": "1300069",
      "product_name": "FINION зеркало 120*75*4,5см, с подсветкой, системой Bluetooth, с подогревом",
      "product_mpn": "G6101200",
      "manufacturer_name": "VILLEROY & BOCH",
      "product_seria": "FINION",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_058716_0.jpg"
      ],
      "description": "Finion зеркало 1200*750*45 мм, подвесное, прямоугольное, с подсветкой, системой Bluetooth, с подогревом.",
      parameters: [
        {
          "parameter_id": "58716_000000001",
          "product_sku": "58716",
          "parameter_name": "Ширина",
          "parameter_value": "1 200"
        },
        {
          "parameter_id": "58716_000000002",
          "product_sku": "58716",
          "parameter_name": "Конструкция",
          "parameter_value": "Зеркало"
        },
        {
          "parameter_id": "58716_000000013",
          "product_sku": "58716",
          "parameter_name": "Материал",
          "parameter_value": "Стекло"
        },
        {
          "parameter_id": "58716_000000014",
          "product_sku": "58716",
          "parameter_name": "Глубина",
          "parameter_value": "24"
        },
        {
          "parameter_id": "58716_000000015",
          "product_sku": "58716",
          "parameter_name": "Длина/высота (мм)",
          "parameter_value": "750"
        },
        {
          "parameter_id": "58716_000000016",
          "product_sku": "58716",
          "parameter_name": "Монтаж",
          "parameter_value": "Подвесной"
        },
        {
          "parameter_id": "58716_000000018",
          "product_sku": "58716",
          "parameter_name": "Форма",
          "parameter_value": "Прямоугольная"
        },
        {
          "parameter_id": "58716_000000024",
          "product_sku": "58716",
          "parameter_name": "Особенности",
          "parameter_value": "С подсветкой"
        },
        {
          "parameter_id": "58716_000000025",
          "product_sku": "58716",
          "parameter_name": "Цвет/тип покрытия",
          "parameter_value": "Другие цвета"
        },
        {
          "parameter_id": "58716_Brand",
          "product_sku": "58716",
          "parameter_name": "Бренд",
          "parameter_value": "VILLEROY & BOCH"
        },
        {
          "parameter_id": "58716_Series",
          "product_sku": "58716",
          "parameter_name": "Серия",
          "parameter_value": "FINION"
        }
      ]
    },
    {
      "product_sku": "058721",
      "product_categoryId": "40003",
      "product_name": "Metropol Смеситель для умывальника, однорычажный",
      "product_mpn": "32512000",
      "manufacturer_name": "HANSGROHE",
      "product_seria": "METROPOL",
      "product_status": null,
      "product_price": "0",
      "product_currency": "",
      "product_price_online": "0",
      "sourcePrice": "0",
      "sourceCurrency": "",
      "product_availability_local": "true",
      "ext_info": "false",
      pictures: [
        "https://b2bdev.antey.com.ua/media/product_sku_058721_0.jpg",
        "https://b2bdev.antey.com.ua/media/product_sku_058721_1.jpg"
      ],
      "description": "Смеситель для раковины 260, однорычажный, с рычаговой рукояткой, со сливным клапаном Push-Open, для раковины в форме таза.\nComfortZone 260, выступ 204 мм, обычная струя, расход воды: 5 л/мин, сливной клапан Push-Open (управление с помощью пробки, для раковин с переливом), подходит для проточных водонагревателей.",
      parameters: [
        {
          "parameter_id": "58721_000000117",
          "product_sku": "58721",
          "parameter_name": "Длина излива",
          "parameter_value": "204"
        },
        {
          "parameter_id": "58721_000000118",
          "product_sku": "58721",
          "parameter_name": "Высота излива",
          "parameter_value": "259"
        },
        {
          "parameter_id": "58721_000000119",
          "product_sku": "58721",
          "parameter_name": "Высота смесителя",
          "parameter_value": "326"
        },
        {
          "parameter_id": "58721_000000120",
          "product_sku": "58721",
          "parameter_name": "Монтаж",
          "parameter_value": "Врезной"
        },
        {
          "parameter_id": "58721_000000121",
          "product_sku": "58721",
          "parameter_name": "Цвет изделия",
          "parameter_value": "Хром"
        },
        {
          "parameter_id": "58721_000000122",
          "product_sku": "58721",
          "parameter_name": "Комплектация",
          "parameter_value": "Нет"
        },
        {
          "parameter_id": "58721_000000123",
          "product_sku": "58721",
          "parameter_name": "Тип управления",
          "parameter_value": "Однорычажный"
        },
        {
          "parameter_id": "58721_000000124",
          "product_sku": "58721",
          "parameter_name": "Наличие донного клапана",
          "parameter_value": "Да"
        },
        {
          "parameter_id": "58721_000000125",
          "product_sku": "58721",
          "parameter_name": "Кол-во отверстий",
          "parameter_value": "1"
        },
        {
          "parameter_id": "58721_Brand",
          "product_sku": "58721",
          "parameter_name": "Бренд",
          "parameter_value": "HANSGROHE"
        },
        {
          "parameter_id": "58721_Series",
          "product_sku": "58721",
          "parameter_name": "Серия",
          "parameter_value": "METROPOL"
        }
      ]
    }
  ]

  // product table insert
    // tempProducts.map((item, index)=>{
    //     const image = item.pictures == undefined ? "":item.pictures;
    //     Product.create({
    //         sku: item.product_sku,
    //         id_sku:item.product_mpn,
    //         sub_category_id: parseInt(item.product_categoryId),
    //         title: item.product_name,
    //         description_1: item.description,
    //         vendor: item.manufacturer_name,
    //         series:item.product_seria,
    //         status: item.product_status,
    //         price: parseFloat(item.product_price),
    //         discount: parseFloat(item.sourcePrice),
    //         currency:item.product_currency,
    //         is_sale: item.product_availability_local == "true" ? 1 : 0,
    //         is_active: item.product_availability_local == "true" ? 1 : 0,
    //         img: image[0],
    //     }).then(function(){
    //         console.log(index, "<=====================success===============>")
    //     })
    // })

// product images table insert
// tempProducts.map((item, index)=>{
//   const image = item.pictures == undefined ? []:item.pictures;
//   const id = 158 + parseInt(index);
//   // const ext = image[0].split(".")[4];
//   ProductImage.create({
//       product_id: id,
//       name:""+index+cst[0],
//       ext: 'jpg',
//       mime: "image/jpeg",
//       url: image.toString()
//   }).then(function(){
//       console.log(id, ext, "<=====================success===============>")
//   })
// })

// product thumbnail table insert
  // tempProducts.map((item, index)=>{
    //     const image = item.pictures == undefined ? []:item.pictures;
    //     const id = 158 + parseInt(index);
    //     const ext = image.length === 0 ? "" : '.'+image[0].split(".")[4];
    //     const name =image.length === 0 ? '' : image[0].split("/")[4];
    //     const url = image.length === 0 ? null : image[0];
    //     ProductThumbnail.create({
    //         product_id: id,
    //         name:name,
    //         ext: ext,
    //         mime: "image/jpeg",
    //         url: url,
    //     }).then(function(){
    //         console.log(id, ext, "<=====================success===============>")
    //     })
    // })

// filter options table insert
// const insertItem = {};
//       tempProducts.map((item, index)=>{
//         const image = item.parameters == undefined ? []:item.parameters;
//         const productid = 158 + parseInt(index);
//         const price = parseFloat(item.product_price);
//         insertItem["product_id"] = productid;
//         insertItem["price"] = price;
//         for( let i = 0 ; i < image.length ; i++ ){
//             const name = image[i].parameter_value;
//             const strID = image[i].parameter_id.split("_")[1]
//             let id = -1;
            
//             if( strID.toLowerCase() === "brand")
//                 id = 189;
//             else if( strID.toLowerCase() === "series" )
//                 id = 190;
//             else id = parseInt(strID) - 1;

//             if( id !== -1 ) {
//                 if( enFilters[id] === "height" || enFilters[id] === "length" || enFilters[id] === "depth" || enFilters[id] === "width")
//                     insertItem[`${enFilters[id]}`] = parseFloat(name);    
//                 else insertItem[`${enFilters[id]}`] = name;
//             }

//         }
//         Filter_Options.create(
//             insertItem
//         ).then(function(){
//             console.log(productid, "<=====================success===============>")
//         })
//     })

const datafields = ["brand", "series", "width", "equipment", "color", "material", "depth", "length", "installation_type", "form", "type", "control_type", "country_vendor", "height"]
const ruFilters = [
    "000000001", "000000002", "000000003", "Диаметр (мм)", "Диаметр 2 (мм)", "Комплектация", "Тип дверей", "Тип поддона", "Цвет профиля", "Материал", "Глубина", "Длина/высота (мм)",
    "Монтаж", "Назначение", "Форма","Подвод воды", "Тип слива", "Подключение к канализации", "Тип управления", "Тип установки смесителя", "Особенности", "Цвет/тип покрытия",
    "Страна производитель", "Тип сидения", "Перелив", "Длина", "Высота", "Подключение к канализации", "Безободковый", "Тип изделия", "Цвет изделия",
    "Тип слива бачка", "Сиденье, крышка", "Материал сиденья", "Унитаз с функцией биде", "Особенности формы", "Отверстия под смеситель", "Кол-во смесителей", "Особенности"
];
export const enFilters = [
    "width", "width", "width", "width", "width", "width", "width", "width", "equipment", "equipment", "equipment", "color", "material", "depth", "length", 
    "installation_type", "installation_type", "form", "form", "type", "type", "control_type", "installation_type", "installation_type", "color",
    "country_vendor", "type", "type", "type", "type", "type", "type", "type", "type", "type", "type", "type", "type", "type", "type", "length", "width", "height", 
    "installation_type", "installation_type", "installation_type", "form", "type", "color", "equipment",
    "type", "type", "type", "material", "material", "material", "material", "width", "depth", "height", "installation_type", "form", "form", "color", "equipment", "material",
    "material", "material", "material", "material", "length", "width", "height", "material", "color", "form", "form", "installation_type", "installation_type",
    "installation_type", "installation_type", "installation_type", "installation_type", "installation_type", "control_type", "control_type", "control_type", "height", "color",
    "control_type", "control_type", "control_type", "control_type", "installation_type", "color", "equipment", "control_type", "type", "type", "type", "color", "equipment",
    "control_type","control_type","control_type","control_type","control_type","control_type", "installation_type", "color", "control_type","control_type","control_type","control_type",
    "equipment", "equipment", "equipment", "equipment", "equipment", "installation_type", "color", "equipment", "control_type", "control_type", "control_type", "control_type",
    "control_type", "control_type", "installation_type", "installation_type", "length", "width", "height", "height", "height", "height", "height", "color", "height", "height", 
    "height", "height", "height", "height", "material", "material", "installation_type", "color", "color", "height", "height", "color","color","color","color","color","color","color",
    "color","color","color","color", "installation_type", "color", "control_type", "control_type", "control_type", "control_type", "control_type", "control_type", "control_type", 
    "color","color","color","color","color","color","color","color","color","color","color","color","color", "control_type", "control_type", "control_type", "control_type", "control_type",
    "brand", "series"
]