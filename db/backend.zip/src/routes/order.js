import express from "express";
import {OneClickOrder, Order, OrderDetail} from "../db/models";
import bcrypt from "bcryptjs";
import config from "../config";
const orderid = require('order-id')('mysecret')
const dateFormat = require('dateformat');

const nodemailer = require("nodemailer");
const sendgrid = require("nodemailer-sendgrid-transport")

const regEmail = require("../emails/registration");
const orderEmail = require("../emails/order-confirmation")

const stripe = require('stripe')('sk_test_51GsJEqALCR9ctSLfdYOmdYYjp1ELZljfwA1ZDOIbovzJYYMKNgiwvTDOhapJDQlqFHJ01Xu5C6Ca0AJ1jM1NlnHm00fM0ZxL0L');

const transporter = nodemailer.createTransport(sendgrid({
  auth: {api_key: config.SENDGRID_API_KEY}
}))


const router = express.Router();

router.get('/liqpay', async(req, res)=>{

    var LiqPay = require('liqpay');
    var liqpay = new LiqPay('public_key', 'private_key');
    console.log(liqpay)

    // var html = liqpay.cnb_form({
    //     'action'         : 'pay',
    //     'amount'         : '1',
    //     'currency'       : 'USD',
    //     'description'    : 'description text',
    //     'order_id'       : 'order_id_1',
    //     'version'        : '3'
    // });
    // res.json({data: html})
})

router.post('/oneclick', async(req, res) => {
    console.log(req.body);
    try{
        await OneClickOrder.create({
            product_id: req.body.productId,
            product_title: req.body.title,
            product_sku: req.body.sku,
            phonenumber: req.body.phone,
            active: req.body.active
        }).then((item)=>{
            console.log(item);
            res.json({status: true, id: item.id});
        })
    } catch(err){
        res.json({status:false});
    }
})

router.post('/get/total',async (req, res) => {
    const retData = [];

    await Order.findAll().then((order) => {
        order.map((item)=>{
            let insert = item.dataValues;
            const ordernumber = item.OrderNumber;
            OrderDetail.findAll({
            where:{
                OrderNumber: ordernumber
            }
            }).then((detailItem)=>{
                detailItem.map((detail)=>{
                    const insertItem = {
                        ...insert,
                        sku: detail.IDSKU,
                        name: detail.Title,
                        vendor: detail.Vendor,
                        amount: detail.Quantity,
                        price: detail.Price
                    }
                    retData.push(insertItem);
                })
            })
        })
    })
    setTimeout(() => {
            res.json(retData)
    }, 1000);
});


router.post('/get/list',async (req, res) => {
    const retData = [];

    await Order.findAll({
        where: {
            CustomerID: req.body.data.user.CustomerID === undefined ? req.body.data.user.id : req.body.data.user.CustomerID
        }
    }).then((order) => {
        order.map((item)=>{
            let insert = item.dataValues;
            const ordernumber = item.OrderNumber;
            OrderDetail.findAll({
            where:{
                OrderNumber: ordernumber
            }
            }).then((detailItem)=>{
                detailItem.map((detail)=>{
                    const insertItem = {
                        ...insert,
                        sku: detail.IDSKU,
                        name: detail.Title,
                        vendor: detail.Vendor,
                        amount: detail.Quantity,
                        price: detail.Price
                    }
                    retData.push(insertItem);
                })
            })
        })
    })
    setTimeout(() => {
            res.json(retData)
    }, 1000);
});

router.post('/pay', async (req, res) => {
    const { authID, amount, email, name, department, deliveryMethod, phone, name1, surname,  payMethod, payOption, items, city, notCall, notice } = req.body;
    let callBack = 1
    if(!notCall) {
        callBack = 0;
    }
    const amnt = parseInt(amount) * 100;
    try {
        const paymentCharge = await stripe.charges.create({
            amount: amnt,
            currency: 'UAH',
            source: req.body.token,
            description: "Akvamarket",
            receipt_email: email,
        });
        if( !paymentCharge.status ) res.json({status:"failed"});
        const date_ = Date.now();
        const date = dateFormat(date_, "yyyy-mm-dd h:MM:ss");
        const orderDate = dateFormat(date_, "yyyy-mm-dd");

        const id = orderid.generate()
        const orderItem = await Order.create({
            CustomerID: authID,
            OrderNumber: id,
            Amount: amount,
            Name: name,
            Surname: surname,
            City: city,
            Department: department,
            ShipperID:deliveryMethod.id,
            Paid: true,
            Email: email,
            NotCall: callBack,
            Phone: phone,
            Currenry: 'UAH',
            Notice: notice,
            PaymentID: payOption.id,
            PaymentMethod: payOption.name,
            OrderDate: orderDate,
            createAt: date,
            updateAt: date,
        }).then((ordered)=>{
            items.map(async(orderprod) => {
                await OrderDetail.create({
                    OrderID: ordered.OrderID,
                    ProductID: orderprod.id,
                    OrderNumber: ordered.OrderNumber,
                    IDSKU:orderprod.sku,
                    Quantity:orderprod.quantity,
                    Price:orderprod.sale_price,
                    Title: orderprod.title,
                    Vendor: orderprod.vendor,
                    orderDate: orderDate,
                    createdAt: date,
                    updateAt: date
                })
            })
            res.json({'payment_result': 'succed', 'paymentCharge':paymentCharge, 'orderId': id, 'email': email});
        })
        transporter.sendMail(orderEmail(email, id))

    } catch (err) {
        console.log('resdata', err);
        res.json({'payment_result': err});

    }
})

router.post('/paymentLater', async (req, res) => {
    const { authID, amount, email, name, department, deliveryMethod, phone, name1, surname,  payMethod, payOption, items, city, notCall, notice } = req.body;
    let callBack = 1
    if(!notCall) {
        callBack = 0;
    }
    const amnt = parseInt(amount) * 100;
    try {
        const date_ = Date.now();
        const date = dateFormat(date_, "yyyy-mm-dd hh:MM:ss");
        const orderDate = dateFormat(date_, "yyyy-mm-dd");
        const id = orderid.generate()
        const orderItem = await Order.create({
            CustomerID: authID,
            OrderNumber: id,
            Amount: amount,
            Name: name,
            Surname: surname,
            City: city,
            Department: department,
            ShipperID:deliveryMethod.id,
            Email: email,
            NotCall: callBack,
            Notice:notice,
            Phone: phone,
            Paid: false,
            Currency: `UAH`,
            PaymentID: payOption.id,
            PaymentMethod: payOption.name,
            OrderDate: orderDate,
            createAt: date,
            updateAt: date,
        }).then((ordered)=>{
            items.map(async(orderprod) => {
                await OrderDetail.create({
                    OrderID: ordered.OrderID,
                    ProductID: orderprod.id,
                    OrderNumber: ordered.OrderNumber,
                    IDSKU:orderprod.sku,
                    Quantity:orderprod.quantity,
                    Price:orderprod.sale_price,
                    Title: orderprod.title,
                    Vendor: orderprod.vendor,
                    createdAt: date,
                    updateAt: date
                })
            })
            res.json({'payment_result': 'succed', 'orderId': id, 'email': email});
        })
        transporter.sendMail(orderEmail(email, id))
    } catch (err) {
        console.log('resdata', err);
        res.json({'payment_result': 'failed'});
    }
})
module.exports = router;
