import express from "express";
import { Collection, Product } from "../db/models";
import config from "../config";
import { 
    getCollectionBySlug,
    getCategoryById, 
    getProductImagesById, 
    getProductThumbnailById, 
    getBrandById, 
    getFilterOptionsByID 
} from './utilitis';

const router = express.Router();

function makeReturnProductData(products, req, res){
    return new Promise(async(resolve, reject) => {
        let retproduct = [];
        products.map( async (product, index) => {
            const pID = product.id;
            const cID = product.category_id;
            const bID = product.brand_id;
        
            const category = await getCategoryById(cID);
            const temp = await getProductImagesById(pID);
            const imgurls = temp === null || temp[0] === undefined? [] : temp[0].url.split(',');
            let productImage = [];
            productImage = imgurls.map((url)=>{
                return {
                    id:temp[0].id,
                    product_id: temp[0].product_id,
                    url
                }
            });
            const thumbnail = await getProductThumbnailById(pID);
            const brands = await getBrandById(bID);
            const filterOpt = await getFilterOptionsByID(pID);

            let filterOptions = [];
            if( filterOpt != undefined ){
                if( filterOpt.brand != "" ) filterOptions.push({key:"Brand", ru_key:"Бренд", value:filterOpt.brand});
                if( filterOpt.series != "" ) filterOptions.push({key:"Series", ru_key:"Серия", value:filterOpt.series});
                if( filterOpt.price != 0 ) filterOptions.push({key:"Price", ru_key:"Цена", value:filterOpt.price});
                if( filterOpt.shipping_time != "" ) filterOptions.push({key:"Shippingtime", ru_key:"Время доставки", value:filterOpt.shipping_time});
                if( filterOpt.shape != "" ) filterOptions.push({key:"Shape", ru_key:"Форма", value:filterOpt.shape});
                if( filterOpt.width != 0 ) filterOptions.push({key:"Width", ru_key:"Ширина", value:filterOpt.width});
                if( filterOpt.equipment != 0 ) filterOptions.push({key:"Equipment", ru_key:"Комплектация", value:filterOpt.equipment});
                if( filterOpt.depth != 0 ) filterOptions.push({key:"Depth", ru_key:"Глубина", value:filterOpt.depth});
                if( filterOpt.material != "" ) filterOptions.push({key:"Material", ru_key:"Материал", value:filterOpt.material});
                if( filterOpt.length != "" ) filterOptions.push({key:"Length", ru_key:"Длина", value:filterOpt.length});
                if( filterOpt.installation_type != "" ) filterOptions.push({key:"InstallationType", ru_key:"Монтаж", value:filterOpt.installation_type});
                if( filterOpt.color != "" ) filterOptions.push({key:"Color", ru_key:"Цвет", value:filterOpt.color});
                if( filterOpt.form != "" ) filterOptions.push({key:"Form", ru_key:"Форма", value:filterOpt.form});
                if( filterOpt.type != "" ) filterOptions.push({key:"Type", ru_key:"Тип", value:filterOpt.type});
                if( filterOpt.control_type != "" ) filterOptions.push({key:"ControlType", ru_key:"Тип упрaвления", value:filterOpt.control_type});
                if( filterOpt.country_vendor != "" ) filterOptions.push({key:"CountryVendor", ru_key:"Страна производитель", value:filterOpt.country_vendor});
                if( filterOpt.height != "" ) filterOptions.push({key:"Height", ru_key:"Рост", value:filterOpt.height});
                if( filterOpt.bowl_width != 0 ) filterOptions.push({key:"Bowlwidth", ru_key:"Ширина чаши", value:filterOpt.bowl_width});
                if( filterOpt.bowl_diameter != 0 ) filterOptions.push({key:"Bowldiameter", ru_key:"Диаметр чаши", value:filterOpt.bowl_diameter});

            }
            const buy = product.buy_with === null || product.buy_with === '' ? [] : product.buy_with.split('-');
            const alter = product.alter_product === null || product.alter_product === '' ? [] : product.alter_product.split('-');
            return retproduct.push({
                id:pID,
                title:product === null ? '' : product.title,
                is_featured:product.is_featured,
                is_hot:product === null ? 0 : product.is_hot,
                price:product === null ? 0 : parseFloat(product.price),
                sale_price: product === null ? 0 :parseFloat(product.discount),
                vendor:product.vendor,
                review:parseFloat(product.rating),
                is_out_of_stock:product.is_out_of_stock,
                depot:parseFloat(product.depot),
                sku:product.sku,
                id_sku:product.id_sku,
                description_1: product.description_1,
                weight:parseFloat(product.weight),
                inventory:parseFloat(product.inventory),
                is_active:product.is_active,
                is_sale:product.is_sale,
                currency: product.currency,
                discount_percent:product.discount_percent,
                available: product.available,
                url:product.img,
                created_at:product.created_at,
                updated_at:product.update,
                variants:[],
                icon:product.icon,
                buy_with: buy,
                alter_product: alter,
                rect:[
                    product.positionL,
                    product.positionT,
                    product.positionW,
                    product.positionH
                ],
                filterOptions,
                images: productImage,
                thumbnail,
                product_categories: [category],
                brands:[brands],
                collections:[]
            });
        })

        setTimeout(() => {
            resolve(retproduct);
        }, (2000));
    })
}

router.get('/', (req, res) => {
    console.log("this is server slugin ==> " , req.query.slug_in)
    const slugin = req.query.slug_in;
    let data = [];
    slugin.map(async (slug) => {
        const oneCollection = await getCollectionBySlug(slug);
        if( oneCollection[0] !== undefined )
            if( oneCollection[0].dataValues !== undefined)
            {
                const colID = oneCollection[0].dataValues.CollectionID;
                Product.findAll({
                    where : {
                        collection_id: parseInt(colID)
                    }
                }).then(async (product) => {
                    const resproduct = await makeReturnProductData(product, req, res);
                    data.push({
                        id: colID,
                        name:oneCollection[0].dataValues.CollectionName,
                        slug:oneCollection[0].dataValues.Tag,
                        description:oneCollection[0].dataValues.Description,
                        created_at:oneCollection[0].dataValues.createdAt,
                        updated_at:oneCollection[0].dataValues.updatedAt,
                        products: resproduct
                    })
                })
            }
    })
    setTimeout(()=>{
        res.json(data);
    }, 2500)
    
});


module.exports = router;