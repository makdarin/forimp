import express from "express";
import { Review } from "../db/models";
import config from "../config";
import fs from "fs";
import path from "path";

const Sequelize = require('sequelize');
const router = express.Router();

router.post('/add', (req, res) => {
    const body = req.body;
    Review.create({
        pid: body.pid,
        uid: body.uid,
        star: body.star,
        review: body.review,
        username: body.username,
        email: body.email
    }).then(function(){
        res.json({data:'success'});
    })
});

router.post('/', (req, res) => {
    const body = req.body
    Review.findAll({
        where: {
            uid: body.uid,
            pid: body.pid
        }
    }).then( products => {
        res.json(products);
    })
});

module.exports = router;
