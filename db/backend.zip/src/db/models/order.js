'use strict';
module.exports = (sequelize, DataTypes) => {
  const Order = sequelize.define('Order', {
    OrderID: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    CustomerID: DataTypes.INTEGER,
    ShippingInfoID: DataTypes.INTEGER,
    OrderNumber: DataTypes.STRING,
    Amount: DataTypes.STRING,
    Name: DataTypes.STRING,
    Surname: DataTypes.STRING,
    City: DataTypes.STRING,
    Department: DataTypes.STRING,
    Email: DataTypes.STRING,
    NotCall: DataTypes.TINYINT(1),
    Phone: DataTypes.STRING,
    Currency: DataTypes.STRING,
    StatusCode: DataTypes.INTEGER,
    Status: DataTypes.STRING,
    TrackingNumber: DataTypes.STRING,
    PaymentID: DataTypes.INTEGER,
    PaymentMethod: DataTypes.STRING,
    OrderDate: DataTypes.DATE,
    ShipDate: DataTypes.DATE,
    RequiredDate: DataTypes.DATE,
    ShipperID: DataTypes.INTEGER,
    Freight: DataTypes.STRING,
    Timestamp: DataTypes.DATE,
    TransactStatus: DataTypes.STRING,
    ErrMsg: DataTypes.STRING,
    Fulfilled: DataTypes.TINYINT(1),
    Deleted: DataTypes.TINYINT(1),
    Paid: DataTypes.TINYINT(1),
    Modified: DataTypes.DATE,
    Created: DataTypes.DATE
  }, {});
  Order.associate = function(models) {
    // associations can be defined here
  };
  return Order;
};