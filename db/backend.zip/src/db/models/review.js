'use strict';
module.exports = (sequelize, DataTypes) => {
  const Review = sequelize.define('Review', {
    pid:DataTypes.INTEGER,
    uid:DataTypes.INTEGER,
    star:DataTypes.INTEGER,
    review: DataTypes.STRING,
    username: DataTypes.STRING,
    email: DataTypes.STRING,
    visible:DataTypes.BOOLEAN,
    createdAt: DataTypes.DATE,
    updatedAt: DataTypes.DATE
  }, {});
  Review.associate = function(models) {
    // associations can be defined here
  };
  return Review;
};