/*MyDoc - Application app - backend - API version 1.0
Author: Iurii Makalov */

var restify = require('restify');
var Connection = require('tedious').Connection;
var server = restify.createServer();
var express = require('express');
var bodyParser = require('body-parser');
var mysql = require('mysql');
var uuid = require('uuid');
var dateFormat = require('dateformat');

var connection = mysql.createConnection({server: '127.0.0.1:3306', user: 'yuriy', password: 'Test1234!', database: 'antey'});

server.listen(7085, function () {
    console.log('listening at %s', server.url);
});

//get order info 
server.get('/order/:id/', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    var orderId = req.params.id;
    console.log(orderId);

    connection.query("SELECT o.OrderID, o.OrderNumber, o.PaymentID, o.Amount, o.Currency, o.OrderDate, o.Created, o.Modified, o.TrackingNumber, o.ShipDate, o.ShipperID, o.Status, c.CustomerID, c.Email, c.Phone, c.FirstName, c.LastName, c.ShipAddress,c.ShipPostalCode, c.ShipCity, sh.CompanyName, od.ProductID, od.IDSKU,od.Quantity, od.Price FROM orders o, orderdetails od, customers c, shippers sh WHERE o.CustomerID = c.CustomerID AND o.OrderID = od.OrderID AND o.ShipperID = sh.ShipperID AND o.OrderID = ?", [orderId], function (err, tmpres) {
        if (err) {
            console.log("query failed!" + req.params.orderId + err);
            return;
        }
        var out = [];
        tmpres.forEach(function (a) {
            out.push({
                orderID: a.OrderID,
                orderNumber: a.OrderNumber,
                paymentID: a.PaymentID,
                amount: a.Amount,
                currency: a.Currency,
                orderDate: dateFormat(a.OrderDate, "yyyy-mm-dd"),
                shipperID: a.ShipperID,
                created: a.Created,
                modified: a.Modified,
                status: a.Status,
                trackingNumber: a.TrackingNumber,
                shipperCompany: a.CompanyName,
                customerID: a.CustomerID,
                customerEmail: a.Email,
                customerPhone: a.Phone,
                customerName: a.FirstName + ' ' + a.LastName,
                shipAddress: a.ShipAddress + ',' + a.ShipPostalCode + ',' + a.ShipCity,
                orderDetails: [{
                        sku: a.IDSKU,
                        quantity: a.Quantity,
                        price: a.Price
                }]
            });
        });
        res.json(out);
        console.log('Get order information: ' + orderId);
    });
});

//get list of orders by day
server.get('/orders/:date', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    var date1 = req.params.date;
    // var date = stringToDate(number,"yyyy-mm-dd","-")
    console.log(date1);
    connection.query("SELECT o.OrderID, o.OrderNumber, o.PaymentID, o.Amount, o.Currency, o.OrderDate, o.Created, o.Modified, o.TrackingNumber, o.ShipDate, o.ShipperID, o.Status, c.CustomerID, c.Email, c.Phone, c.FirstName, c.LastName, c.ShipAddress,c.ShipPostalCode, c.ShipCity, sh.CompanyName, od.ProductID, od.IDSKU,od.Quantity, od.Price FROM orders o, orderdetails od, customers c, shippers sh WHERE o.CustomerID = c.CustomerID AND o.OrderID = od.OrderID AND o.ShipperID = sh.ShipperID AND o.Created LIKE ?", ['%' + date1 + '%'], function (err, tmpres) {
        if (err) {
            console.log("query failed!" + req.params.id + err);
            return;
        }
        var out = [];
        tmpres.forEach(function (a) {
            out.push({
                orderID: a.OrderID,
                orderNumber: a.OrderNumber,
                paymentID: a.PaymentID,
                amount: a.Amount,
                currency: a.Currency,
                orderDate: dateFormat(a.OrderDate, "yyyy-mm-dd"),
                created: a.Created,
                modified: a.Modified,
                status: a.Status,
                trackingNumber: a.TrackingNumber,
                shipperID: a.ShipperID,
                shipperCompany: a.CompanyName,
                customerID: a.CustomerID,
                customerEmail: a.Email,
                customerPhone: a.Phone,
                customerName: a.FirstName + ' ' + a.LastName,
                shipAddress: a.ShipAddress + ',' + a.ShipPostalCode + ',' + a.ShipCity,
                orderDetails: [{
                        sku: a.IDSKU,
                        quantity: a.Quantity,
                        price: a.Price
                }]
            });
        });
        res.json(out);
        console.log('Get orders by date: ' + date1);
    });
});

//change data for order
server.put('/order/:id', bodyParser(), function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    var orderId = req.params.id;
    var status = req.body.status;
    var trackingNumber = req.body.trackingNumber;
    var date_ = Date.now();
    var date = dateFormat(date_, "yyyy-mm-dd h:MM:ss");
    console.log('changing order info')
    connection.query("UPDATE orders SET Status = ?, TrackingNumber = ?, Modified = ? WHERE OrderID = ?", [
        status, trackingNumber, date, orderId
    ], function (err, tmpres) {
        if (err) {
            console.log("query failed!" + req.params.id + err);
            return res.json({success: false});
        }
        console.log('Data have been changed successfully for order: ' + orderId);
        return res.json({
            success: !!tmpres
        });
    });
});


//get product info 
server.get('/products/:id/', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    var productId = req.params.id;
    console.log(productId);

    connection.query("SELECT * FROM products1 WHERE sku  = ?", [productId], function (err, tmpres) {
        if (err) {
            console.log("query failed!" + req.params.id + err);
            return;
        }
        var out = [];
        tmpres.forEach(function (a) {
            out.push({
                sku: a.sku,
                id_sku: a.id_sku,
                vendor: a.vendor,
                name: a.title,
                description: a.description_1,
                inventory: a.inventory,
                status: a.status,
                series: a.series,
                price: a.price,
                currency: a.currency,
                available: a.is_active,
                img: a.img 
            });
        });
        res.json(out);
        console.log('Get information for product: ' + productId);
    });
});

//get product info 
server.get('/brand/products/:brand/', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    var brand = req.params.brand;
    console.log(brand);

    connection.query("SELECT * FROM products1 WHERE vendor  LIKE ?", ['%'+brand+'%'], function (err, tmpres) {
        if (err) {
            console.log("query failed!" + req.params.brand + err);
            return;
        }
        var out = [];
        tmpres.forEach(function (a) {
            out.push({
                sku: a.sku,
                id_sku: a.id_sku,
                vendor: a.vendor,
                name: a.title,
                description: a.description_1,
                inventory: a.inventory,
                status: a.status,
                series: a.series,
                price: a.price,
                currency: a.currency,
                available: a.is_active,
                img: a.img 
            });
        });
        res.json(out);
        console.log('Get products information for brand: ' + brand);
    });
});

//get product info 
server.get('/group/products/:group/', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    var group = req.params.group;
    console.log(group);

    connection.query("SELECT * FROM products1 WHERE sub_category_id LIKE ?", [''+group+'%'], function (err, tmpres) {
        if (err) {
            console.log("query failed!" + req.params.group + err);
            return;
        }
        var out = [];
        tmpres.forEach(function (a) {
            out.push({
                sku: a.sku,
                id_sku: a.id_sku,
                categoryId: a.sub_category_id,
                vendor: a.vendor,
                name: a.title,
                description: a.description_1,
                inventory: a.inventory,
                status: a.status,
                series: a.series,
                price: a.price,
                currency: a.currency,
                available: a.is_active,
                img: a.img 
            });
        });
        res.json(out);
        console.log('Get products information for group: ' + group);
    });
});



//change product information
server.put('/products/:id', bodyParser(), function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    var sku = req.params.id;
    var id_sku = req.body.id_sku;
    var vendor = req.body.vendor;
    var name = req.body.name;
    var description = req.body.description;
    var inventory = req.body.inventory;
    var status = req.body.status;
    var series = req.body.series;
    var price = req.body.price;
    var currency = req.body.currency;
    var available = req.body.available;
    var img = req.body.img;
    var date_ = Date.now();
    var date = dateFormat(date_, "yyyy-mm-dd h:MM:ss");
    console.log('changing order info')
    connection.query("UPDATE products1 SET id_sku = ?, vendor = ?, title = ?, description_1 = ?, inventory = ?, status = ?, series = ?, price = ?, currency = ?, is_active = ?, img = ?,  updatedAt = ? WHERE sku= ?", [
        id_sku, vendor, name, description, inventory, status, series, price, currency, available, img, date, sku
    ], function (err, tmpres) {
        if (err) {
            console.log("query failed!" + req.params.id + err);
            return res.json({success: false});
        }
        console.log('Data have been changed successfully for product: ' + sku);
        return res.json({
            success: !!tmpres
        });
    });
});


server.post('/products/:id', bodyParser(), function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Content-Type", "application/json; charset=utf-8");
    res.header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Acc' +
            'ess-Control-Request-Method, Access-Control-Request-Headers,X-Access-Token,XKey,A' +
            'uthorization');
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    var sku = req.params.id;
    var id_sku = req.body.id_sku;
    var category_id = req.body.categoryId;
    var vendor = req.body.vendor;
    var name = req.body.name;
    var description = req.body.description;
    var inventory = req.body.inventory;
    var status = req.body.status;
    var series = req.body.series;
    var price = req.body.price;
    var currency = req.body.currency;
    var available = req.body.available;
    var img = req.body.img;
    var date_ = Date.now();
    var date = dateFormat(date_, "yyyy-mm-dd h:MM:ss");
    console.log('adding new product to store'); 
    connection.query("INSERT INTO products1 (sku, id_sku, category_id, vendor, title,  description_1, inventory, status, series, price, currency, is_active, img, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [
        sku, id_sku, category_id, vendor, name, description, inventory, status, series, price, currency, available, img, date, date
    ], function (err, tmpres) {
        if (err) {
            console.log("query failed!" + req.params.id + err);
            return res.json({success: false});
        }
        console.log('Product data has been added successfully ->' + sku);
        return res.json({
            success: !!tmpres
        });
    });
});

//delete product 
server.del('/products/:id', bodyParser(), function(req, res) {
        var sku = req.params.id;
        connection.query('DELETE FROM PRODUCTS1 WHERE sku = ?', [sku], function(err, myres) {
            if (err) return res.json(500, err);
            return res.json(200, { success: true});
        });
});

//get brands 
server.get('/brands', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    connection.query("SELECT * FROM brands", function (err, tmpres) {
        if (err) {
            console.log("query failed!" + err);
            return;
        }
        var out = [];
        tmpres.forEach(function (a) {
            out.push({
                brandId: a.BrandID,
                name: a.BrandName,
                description: a.Description,
                created: a.Created,
                modified: a.Modified
            });
        });
        res.json(out);
        console.log('Get list of brands');
    });
});


//get series
server.get('/series', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    connection.query("SELECT * FROM series", function (err, tmpres) {
        if (err) {
            console.log("query failed!" + err);
            return;
        }
        var out = [];
        tmpres.forEach(function (a) {
            out.push({
                serieId: a.SerieID,
                name: a.SerieName,
                description: a.Description,
                created: a.Created,
                modified: a.Modified
            });
        });
        res.json(out);
        console.log('Get list of series');
    });
});

//get categories
server.get('/categories', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    connection.query("SELECT * FROM category", function (err, tmpres) {
        if (err) {
            console.log("query failed!" + err);
            return;
        }
        var out = [];
        tmpres.forEach(function (a) {
            out.push({
                categoryId: a.CategoryID,
                name: a.CategoryName,
                description: a.Description,
                created: a.Created,
                modified: a.Modified
            });
        });
        res.json(out);
        console.log('Get list of categories');
    });
});

//get subcategories
server.get('/subcategories', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    connection.query("SELECT * FROM sub_category", function (err, tmpres) {
        if (err) {
            console.log("query failed!" + err);
            return;
        }
        var out = [];
        tmpres.forEach(function (a) {
            out.push({
                id: a.Tag,
                categoryId: a.CategoryID,
                name: a.SubCategoryName,
                description: a.Description,
                created: a.Created,
                modified: a.Modified
            });
        });
        res.json(out);
        console.log('Get list of sub-categories');
    });
});

//get subcategories
server.get('/shippers', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    connection.query("SELECT * FROM shippers", function (err, tmpres) {
        if (err) {
            console.log("query failed!" + err);
            return;
        }
        var out = [];
        tmpres.forEach(function (a) {
            out.push({
                shipperId: a.ShipperID,
                name: a.CompanyName,
                description: a.Description
            });
        });
        res.json(out);
        console.log('Get list of shippers');
    });
});

//get customers
server.get('/customers', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    connection.query("SELECT * FROM customers", function (err, tmpres) {
        if (err) {
            console.log("query failed!" + err);
            return;
        }
        var out = [];
        tmpres.forEach(function (a) {
            out.push({
                customerId: a.CustomerID,
                firstname: a.FirstName,
                lastname: a.LastName,
                email: a.Email,
                phone: a.Phone,
                // shipAddress: a.ShipAddress + ',' + a.ShipPostalCode + ',' + a.ShipCity,
                shipStreet: a.ShipAddress,
                shipPostalCode: a.ShipPostalCode,
                shipCity: a.ShipCity,
                billStreet: a.BillingAddress,
                billPostalCode: a.BillingPostalCode,
                billCity: a.BillingCity,
                created: a.Created
            });
        });
        res.json(out);
        console.log('Get list of customers');
    });
});

//get Products
server.get('/products', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    connection.query("SELECT * FROM products1", function (err, tmpres) {
        if (err) {
            console.log("query failed!" + err);
            return;
        }
        var out = [];
        tmpres.forEach(function (a) {
            out.push({
                sku: a.sku,
                id_sku: a.id_sku,
                vendor: a.vendor,
                name: a.title,
                description: a.description_1,
                inventory: a.inventory,
                status: a.status,
                series: a.series,
                price: a.price,
                currency: a.currency,
                available: a.is_active,
                img: a.img,
                created: a.createdAt,
                modified: a.updatedAt
            });
        });
        res.json(out);
        console.log('Get list of products');
    });
});

//get first list of categories
server.get('/category', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

    connection.query("SELECT id, name FROM category ORDER BY id + 0 ASC", function (err, tmpres) {
        if (err) {
            console.log("query failed!" + req.params.tagId + err);
            return;
        }
        var out = [];
        tmpres.forEach(function (a) {
            out.push({id: a.id, name: a.name});
        });
        res.json(out);
        console.log('Get list of categories');
    });
});

//get list of all questions for category
server.get('/allQuestions/:id/', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    var test = req.params.id;
    console.log(test);

    connection.query("SELECT * FROM questions WHERE category_id = ?", [test], function (err, tmpres) {
        if (err) {
            console.log("query failed!" + req.params.tagId + err);
            return;
        }
        var out = [];
        tmpres.forEach(function (a) {
            out.push({
                id: a.id,
                questionId: a.question_id,
                categoryId: a.category_id,
                category: a.category,
                type: a.type,
                difficulty: a.difficulty,
                question: a.question,
                correct_answer: a.correct_answer,
                incorrect_answers: [
                    a.incorrect_answer1, a.incorrect_answer2, a.incorrect_answer3
                ],
                description: a.description,
                url: a.url,
                changed: a.changed,
                created: a.created
            });
        });
        res.json(out);
        console.log('Get all questions for category: ' + test);
    });
});

//get list of all questions for category
server.get('/getAllQuestions', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

    connection.query("SELECT * FROM questions", function (err, tmpres) {
        if (err) {
            console.log("query failed!" + req.params.tagId + err);
            return;
        }
        var out = [];
        tmpres.forEach(function (a) {
            out.push({
                id: a.id,
                questionId: a.question_id,
                categoryId: a.category_id,
                category: a.category,
                type: a.type,
                difficulty: a.difficulty,
                question: a.question,
                correct_answer: a.correct_answer,
                incorrect_answers: [
                    a.incorrect_answer1, a.incorrect_answer2, a.incorrect_answer3
                ],
                description: a.description,
                url: a.url,
                changed: a.changed,
                created: a.created
            });
        });
        res.json(out);
        console.log('Get all questions');
    });
});

//get customer info for edit
server.get('/question/edit/:id', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

    var number = req.params.id;
    console.log(number);
    connection.query("SELECT * FROM questions WHERE id = ?", [number], function (err, tmpres) {
        if (err) {
            console.log("query failed!" + req.params.id + err);
            return;
        }
        var out = [];
        tmpres.forEach(function (a) {
            out.push({
                id: a.id,
                category: a.category,
                type: a.type,
                difficulty: a.difficulty,
                question: a.question,
                correct_answer: a.correct_answer,
                incorrect_answers: [
                    a.incorrect_answer1, a.incorrect_answer2, a.incorrect_answer3
                ],
                description: a.description,
                url: a.url,
                changed: a.changed,
                created: a.created
            });
        });
        res.json(out);
        console.log('Get questions´s info: ' + number);
    });
});

//change data for customer
server.put('/question/edit/:id', bodyParser(), function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    var description = req.body.description;
    var url = req.body.url;
    var number = req.params.id;
    var date_ = Date.now();
    var date = dateFormat(date_, "yyyy-mm-dd h:MM:ss");
    //var termin = "2016-03-15 00:00:00";
    console.log('changing termin')
    connection.query("UPDATE questions SET description = ?, url = ?,  changed = ? WHERE id = ?", [
        description, url, date, number
    ], function (err, tmpres) {

        if (err) {
            console.log("query failed!" + req.params.id + err);
            return res.json({success: false});
        }
        console.log('Data have been changed for question: ' + number);
        return res.json({
            success: !!tmpres
        });
    });
});

//get tests for web version test
server.get('/test/questions/:id', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    var number = parseInt(req.params.id);

    console.log(number);
    connection.query("SELECT * FROM questions LIMIT ?", [number], function (err, tmpres) {
        if (err) {
            console.log("query failed!" + req.params.id + err);
            return;
        }
        var out = [];
        tmpres.forEach(function (a) {
            out.push({
                id: a.id,
                question: a.question,
                questionImg: 'http://interactive.wttw.com/sites/default/files/styles/hero/public/Q' + a.id + '.jpg',
                feedback: a.description,
                url: a.url,
                options: [
                    {
                        name: a.correct_answer,
                        correct: true
                    }, {
                        name: a.incorrect_answer1,
                        correct: false
                    }, {
                        name: a.incorrect_answer2,
                        correct: false
                    }, {
                        name: a.incorrect_answer3,
                        correct: false
                    }
                ]
            });
        });

        var test = {
            quizMetadata: {
                title: "Тест в прокуратуру (підготовка)",
                intro: "Перелік тестових питань для іспиту з метою виявлення рівня знань та умінь у асто" +
                        "суванні закону, відповідності здійснювати повноваження прокурора",
                introImg: "http://interactive.wttw.com/sites/default/files/styles/small-hero/public/B12_b.j" +
                        "pg",
                introImgCredit: "Одесса"
            },
            quizQuestions: out
        }
        res.json(test);
        console.log('Get questions for test (total)->' + number);
    });
});

//get tests for app
server.get('/app/questions/:id/:cat_id', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    var number = parseInt(req.params.id);
    var category = parseInt(req.params.cat_id);
    console.log(number);
    connection.query("SELECT questions.*, category.name FROM questions, category WHERE questions.categ" +
            "ory_id = category.id AND questions.category_id = ? LIMIT ?",
    [
        category, number
    ], function (err, tmpres) {
        if (err) {
            console.log("query failed!" + req.params.id + err);
            return;
        }
        var out = [];
        tmpres.forEach(function (a) {
            out.push({
                id: a.id,
                category: a.name,
                type: a.type,
                difficulty: a.difficulty,
                question: a.question,
                correct_answer: a.correct_answer,
                incorrect_answers: [a.incorrect_answer1, a.incorrect_answer2, a.incorrect_answer3]
            });
        });
        console.log(out.length)
        if (out.length > 0) {
            test = 0
        } else {
            test = 1
        }

        var data = {
            response_code: test,
            results: out
        }

        res.json(data);
        console.log('Get questions for app (category ID)->' + category + ' total questions->' + number);
    });
});

//get first list of categories
server.get('/app/categories', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

    connection.query("SELECT id, name FROM category ORDER BY id + 0 ASC", function (err, tmpres) {
        if (err) {
            console.log("query failed!" + req.params.tagId + err);
            return;
        }
        var out = [];
        tmpres.forEach(function (a) {
            out.push({id: a.id, name: a.name});
        });

        if (out.length > 0) {
            test = 0
        } else {
            test = 1
        }

        var data = {
            response_code: test,
            results: out
        }

        res.json(data);
        console.log('Get list of categories for app');
    });
});

server.post('/test/result', bodyParser(), function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Content-Type", "application/json; charset=utf-8");
    res.header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Acc' +
            'ess-Control-Request-Method, Access-Control-Request-Headers,X-Access-Token,XKey,A' +
            'uthorization');
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    var ip = req.body.ip;
    var score = req.body.score;
    var city = req.body.city;
    var date_ = Date.now();
    var date = dateFormat(date_, "yyyy-mm-dd h:MM:ss");
    //var termin = "2016-03-15 00:00:00";
    console.log('adding score result to analytics table')
    connection.query("INSERT INTO analytics (ip, score, city, created) VALUES (?, ?, ?, ?)", [
        ip, score, city, date
    ], function (err, tmpres) {

        if (err) {
            console.log("query failed!" + req.params.id + err);
            return res.json({success: false});
        }
        console.log('Score data has been added successfully ->' + ip);
        return res.json({
            success: !!tmpres
        });
    });
});

//get customer info for edit
server.get('/analytics/getResults/:date', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    var number = req.params.date;
    // var date = stringToDate(number,"yyyy-mm-dd","-")
    console.log(number);
    connection.query("SELECT * FROM analytics WHERE created like ?", ['%' + number + '%'], function (err, tmpres) {
        if (err) {
            console.log("query failed!" + req.params.id + err);
            return;
        }
        var out = [];
        tmpres.forEach(function (a) {
            out.push({id: a.id, ip: a.ip, city: a.city, score: a.score, created: a.created});
        });
        res.json(out);
        console.log('Get score results for date: ' + number);
    });
});

//get customer info for edit
server.get('/analytics/getTest/:id', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    var number = req.params.id;
    // var date = stringToDate(number,"yyyy-mm-dd","-")
    console.log(number);
    connection.query("SELECT * FROM analytics WHERE id = ?", [number], function (err, tmpres) {
        if (err) {
            console.log("query failed!" + req.params.id + err);
            return;
        }
        var out = [];
        tmpres.forEach(function (a) {
            out.push({
                id: a.id,
                ip: a.ip,
                correct_answer: a.correct_answer,
                city: a.city,
                score: a.score,
                created: a.created
            });
        });
        res.json(out);
        console.log('Get test result info: ' + number);
    });
});

// function stringToDate(_date,_format,_delimiter) {             var
// formatLowerCase=_format.toLowerCase();             var
// formatItems=formatLowerCase.split(_delimiter);             var
// dateItems=_date.split(_delimiter);             var
// monthIndex=formatItems.indexOf("mm");             var
// dayIndex=formatItems.indexOf("dd");             var
// yearIndex=formatItems.indexOf("yyyy");             var
// month=parseInt(dateItems[monthIndex]);             month-=1;             var
// formatedDate = new Date(dateItems[yearIndex],month,dateItems[dayIndex]);
// return formatedDate; } checking status of customer's request
server.get('/customer/status/:receiptId/:zipCode', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

    var receiptId = req.params.receiptId;
    var zipCode = req.params.zipCode;

    connection.query("SELECT * FROM progress WHERE Belegnummer = ? AND LieferadressePLZ = ?", [
        receiptId, zipCode
    ], function (err, tmpres) {
        if (err) {
            console.log("query failed!" + req.params.tagId + err);
            return;
        }
        var out = [];
        tmpres.forEach(function (a) {
            out.push({
                name: a.LieferadresseName2,
                surname: a.LeferadresseName3,
                street: a.LieferadresseStraße,
                postCode: a.LieferadressePLZ,
                city: a.LieferadresseOrt,
                created: a.Erstanlagedatum,
                updated: a.Änderungsdatum,
                notice: a.Beschreibung,
                shortInfo: a.Kurztext,
                appId: a.Belegnummer,
                status: a.Status
            });
        });
        res.json(out);
        console.log("get status info for customer: " + out);
    });
});

//get first list of employees
server.get('/route/support', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

    connection.query("SELECT kurzname FROM personal", function (err, tmpres) {
        if (err) {
            console.log("query failed!" + req.params.tagId + err);
            return;
        }
        var out = [];
        tmpres.forEach(function (a) {
            out.push({name: a.kurzname});
        });
        res.json(out);
        console.log('Get list of employees');
    });
});

//get list of customers for employee by date
server.get('/route/:name/:date', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

    var test = req.params.name;
    var date1 = req.params.date;
    //var date1 = '2015'; var test = DateTime.Now;
    console.log(date1);
    connection.query("SELECT *  FROM progress WHERE employee = ? AND Termin LIKE ? AND (Status = '24' " +
            "OR Status = '30')",
    [
        test, '%' + date1 + '%'
    ], function (err, tmpres) {
        if (err) {
            console.log("query failed!" + req.params.tagId + err);
            return;
        }
        var out = [];
        tmpres.forEach(function (a) {
            out.push({
                number: a.Nummer,
                name: a.LieferadresseName2,
                surname: a.LieferadresseName3,
                street: a.LieferadresseStraße,
                postCode: a.LieferadressePLZ,
                city: a.LieferadresseOrt,
                termin: a.Termin + a.Status,
                status: a.Status,
                created: a.Erstanlagedatum,
                employee: a.employee,
                appId: a.Belegnummer
            });
        });
        res.json(out);
        console.log('Get clients info of ' + test + ' on: ' + date1);
    });
});

//get list of all customers for employee
server.get('/allClients/:name/', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    var test = req.params.name;
    console.log(test);

    connection.query("SELECT * FROM progress WHERE employee = ? AND (Status = '24' OR Status = '30')", [test], function (err, tmpres) {
        if (err) {
            console.log("query failed!" + req.params.tagId + err);
            return;
        }
        var out = [];
        tmpres.forEach(function (a) {
            out.push({
                number: a.Nummer,
                name: a.LieferadresseName2,
                surname: a.LieferadresseName3,
                street: a.LieferadresseStraße,
                postCode: a.LieferadressePLZ,
                city: a.LieferadresseOrt,
                termin: a.Termin,
                status: a.Status,
                created: a.Erstanlagedatum,
                employee: a.employee,
                appId: a.Belegnummer
            });
        });
        res.json(out);
        console.log('Get all clients for employee: ' + test);
    });
});

//get customer info for edit
server.get('/customer/edit/:id', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

    var number = req.params.id;
    console.log(number);
    connection.query("SELECT * FROM progress WHERE Nummer = ?", [number], function (err, tmpres) {
        if (err) {
            console.log("query failed!" + req.params.id + err);
            return;
        }
        var out = [];
        tmpres.forEach(function (a) {
            out.push({
                number: a.Nummer,
                name: a.LieferadresseName2,
                surname: a.LieferadresseName3,
                street: a.LieferadresseStraße,
                postCode: a.LieferadressePLZ,
                city: a.LieferadresseOrt,
                termin: a.Termin + a.Status,
                status: a.Status,
                employee: a.employee
            });
        });
        res.json(out);
        console.log('Get customer´s info: ' + number);
    });
});

//change data for customer
server.put('/change/appointment/:id/:date', bodyParser(), function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Acc' +
            'ess-Control-Request-Method, Access-Control-Request-Headers,X-Access-Token,XKey,A' +
            'uthorization');
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    var city = req.body.city;
    var postcode = req.body.postcode;
    var street = req.body.street;
    var number = req.params.id;
    var termin = req.params.date;
    var date_ = Date.now();
    var date = dateFormat(date_, "yyyy-mm-dd h:MM:ss");
    //var termin = "2016-03-15 00:00:00";
    console.log('changing termin')
    connection.query("UPDATE progress SET Termin = ?, LieferadresseOrt = ?, LieferadressePLZ = ?, Lief" +
            "eradresseStraße = ?, Änderungsdatum = ? WHERE Nummer = ?",
    [
        termin,
        city,
        postcode,
        street,
        date,
        number
    ], function (err, tmpres) {

        if (err) {
            console.log("query failed!" + req.params.id + err);
            return res.json({success: false});
        }
        console.log('Data has been changed for customer: ' + number);
        return res.json({
            success: !!tmpres
        });
    });
});

//change data for customer
server.post('/add/appointment/:date', bodyParser(), function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    var city = req.body.city;
    var postcode = req.body.postcode;
    var street = req.body.street;
    var termin = req.params.date;
    var employee = req.body.employee;
    var status = req.body.status;
    var name = req.body.name;
    var surname = req.body.surname;
    var appId = req.body.appId;
    var date_ = Date.now();
    var date = dateFormat(date_, "yyyy-mm-dd h:MM:ss");
    var id = uuid.v1();
    connection.query("INSERT INTO progress (LieferadresseOrt, LieferadressePLZ , LieferadresseStraße, " +
            "employee, Status, LieferadresseName2, LieferadresseName3, Nummer, Erstanlagedatu" +
            "m, Belegnummer, Termin, Änderungsdatum) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
    [
        city,
        postcode,
        street,
        employee,
        status,
        name,
        surname,
        id,
        date,
        appId,
        termin,
        date
    ], function (err, tmpres) {
        if (err) {
            console.log("query failed!" + req.params.id + err);
            return res.json({success: false});
        }
        console.log('New application has been added successfully: ' + appId);
        return res.json({
            success: !!tmpres
        });
    });
});

//change data for customer
server.post('/add/employee', bodyParser(), function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    var name = req.body.name;
    var id = uuid.v1();
    connection.query("INSERT INTO personal (kurzname, id) VALUES (?, ?)", [
        name, id
    ], function (err, tmpres) {
        if (err) {
            console.log("query failed!" + req.params.id + err);
            return res.json({success: false});
        }
        console.log('New employee has been added successfully: ' + name);
        return res.json({
            success: !!tmpres
        });
    });
});