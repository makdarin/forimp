'use strict';

module.exports = {
    up: (queryInterface, Sequelize) => {
        
        return queryInterface.bulkInsert('ShippingMethods', [{
            ShippingName: 'International',
            ShippingPrice: 30,
        }], {});
    },

    down: (queryInterface, Sequelize) => {
        return queryInterface.bulkDelete('ShippingMethods', null, {});
    }
};
