'use strict';
module.exports = (sequelize, DataTypes) => {
  const ProductThumbnail = sequelize.define('ProductThumbnail', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    product_id: DataTypes.INTEGER,
    name: DataTypes.STRING,
    alternativeText: DataTypes.STRING,
    caption: DataTypes.STRING,
    width: DataTypes.INTEGER,
    height: DataTypes.INTEGER,
    formats: DataTypes.STRING,
    hash: DataTypes.STRING,
    ext: DataTypes.STRING,
    mime:DataTypes.STRING,
    size:DataTypes.DECIMAL,
    url:DataTypes.STRING,
    previewUrl:DataTypes.STRING,
    provider:DataTypes.STRING,
    provider_metadata: DataTypes.STRING
  }, {});
  ProductThumbnail.associate = function(models) {
    // associations can be defined here
  };
  return ProductThumbnail;
};