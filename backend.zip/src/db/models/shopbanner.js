'use strict';
module.exports = (sequelize, DataTypes) => {
  const ShopBanner = sequelize.define('ShopBanner', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    type: DataTypes.STRING,
    img: DataTypes.STRING,
    title: DataTypes.STRING,
    titleRu: DataTypes.STRING,
    titleUa: DataTypes.STRING,
    titleDe: DataTypes.STRING,
    titleFr: DataTypes.STRING,
    titlePl: DataTypes.STRING,
    content: DataTypes.STRING,
    contentRu: DataTypes.STRING,
    contentUa: DataTypes.STRING,
    contentDe: DataTypes.STRING,
    contentFr: DataTypes.STRING,
    contentPl: DataTypes.STRING,
    url: DataTypes.STRING,
    createdAt: DataTypes.STRING,
    updatedAt:DataTypes.STRING
  }, {});
  ShopBanner.associate = function(models) {
    // associations can be defined here
  };
  return ShopBanner;
};