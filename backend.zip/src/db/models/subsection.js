'use strict';
module.exports = (sequelize, DataTypes) => {
    const Subsection = sequelize.define('Subsection', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        sectionid: DataTypes.INTEGER,
        name: DataTypes.STRING,
        url: DataTypes.STRING,
        type: DataTypes.STRING,
    }, {});
    Subsection.associate = function(models) {
        // associations can be defined here
    };
    return Subsection;
};