'use strict';
module.exports = (sequelize, DataTypes) => {
  const DesignerDetail = sequelize.define('DesignerDetail', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    designerId: DataTypes.INTEGER,
    sku: DataTypes.STRING,
    posX: DataTypes.INTEGER,
    posY: DataTypes.INTEGER,
  }, {});
  DesignerDetail.associate = function(models) {
    // associations can be defined here
  };
  return DesignerDetail;
};