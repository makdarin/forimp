'use strict';
module.exports = (sequelize, DataTypes) => {
    const Subcategory = sequelize.define('Subcategory', {
        SubCategoryID: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        CategoryID: DataTypes.INTEGER,
        SubCategoryName: DataTypes.STRING,
        LocaleName: DataTypes.STRING,
        Description: DataTypes.STRING,
        Tag: DataTypes.STRING,
        Picture: DataTypes.STRING,
        Active: DataTypes.TINYINT(1),
    }, {});
    Subcategory.associate = function(models) {
        // associations can be defined here
    };
    return Subcategory;
};