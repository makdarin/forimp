'use strict';
module.exports = (sequelize, DataTypes) => {
  const Brand = sequelize.define('Brand', {
    BrandID: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    BrandName: DataTypes.STRING,
    Description: DataTypes.STRING,
    Tag: DataTypes.STRING,
  }, {});
  Brand.associate = function(models) {
    // associations can be defined here
  };
  return Brand;
};