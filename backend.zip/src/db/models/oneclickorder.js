'use strict';
module.exports = (sequelize, DataTypes) => {
  const OneClickOrder = sequelize.define('OneClickOrder', {
    product_id: DataTypes.INTEGER,
    product_title: DataTypes.STRING,
    product_sku: DataTypes.STRING,
    phonenumber: DataTypes.STRING,
    active: DataTypes.TINYINT(1)
  }, {});
  OneClickOrder.associate = function(models) {
    // associations can be defined here
  };
  return OneClickOrder;
};