'use strict';
module.exports = (sequelize, DataTypes) => {
  const Cart = sequelize.define('Cart', {
    CartID: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    CustomerID: DataTypes.INTEGER,
    ProductID: DataTypes.INTEGER,
    Quantity: DataTypes.INTEGER,
    amount: DataTypes.FLOAT,
    totalweight: DataTypes.FLOAT,
    cartTotal: DataTypes.INTEGER,
    discount: DataTypes.INTEGER,
    collectionSlug:DataTypes.STRING,
    designeddiscount: DataTypes.INTEGER,
    designedamount: DataTypes.FLOAT
  }, {});
  Cart.associate = function(models) {
    // associations can be defined here
  };
  return Cart;
};