'use strict';
module.exports = (sequelize, DataTypes) => {
    const SectionBanCategory = sequelize.define('SectionBanCategory', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        sectionbannerid: DataTypes.INTEGER,
        url: DataTypes.STRING,
        cateogryId: DataTypes.INTEGER,
        name: DataTypes.STRING,
        imgurl: DataTypes.STRING,
        picUrl: DataTypes.STRING,
        title: DataTypes.STRING,
        header: DataTypes.STRING,
        description: DataTypes.STRING,
        footer: DataTypes.STRING,
        price: DataTypes.INTEGER,
        discount: DataTypes.INTEGER,
        active: DataTypes.TINYINT,
    }, {});
    SectionBanCategory.associate = function(models) {
        // associations can be defined here
    };
    return SectionBanCategory;
};