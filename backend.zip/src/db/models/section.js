'use strict';
module.exports = (sequelize, DataTypes) => {
    const Section = sequelize.define('Section', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        name: DataTypes.STRING,
        url: DataTypes.STRING,
        submenu: DataTypes.TINYINT,
        mega: DataTypes.TINYINT,
    }, {});
    Section.associate = function(models) {
        // associations can be defined here
    };
    return Section;
};