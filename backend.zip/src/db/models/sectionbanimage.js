'use strict';
module.exports = (sequelize, DataTypes) => {
    const SectionBanImage = sequelize.define('SectionBanImage', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        sectionbannerid: DataTypes.INTEGER,
        url: DataTypes.STRING
    }, {});
    SectionBanImage.associate = function(models) {
        // associations can be defined here
    };
    return SectionBanImage;
};