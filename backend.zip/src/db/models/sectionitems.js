'use strict';
module.exports = (sequelize, DataTypes) => {
    const Sectionitem = sequelize.define('Sectionitem', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        subsectionid: DataTypes.INTEGER,
        name: DataTypes.STRING,
        url: DataTypes.STRING,
    }, {});
    Sectionitem.associate = function(models) {
        // associations can be defined here
    };
    return Sectionitem;
};