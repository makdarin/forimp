
'use strict';
module.exports = (sequelize, DataTypes) => {
  const Voucher = sequelize.define('Voucher', {
    id:{
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    code: DataTypes.STRING,
    discount: DataTypes.INTEGER
  }, {});
  Voucher.associate = function(models) {
    // associations can be defined here
  };
  return Voucher;
};