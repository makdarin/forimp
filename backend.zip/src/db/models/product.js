'use strict';
module.exports = (sequelize, DataTypes) => {
  const Product = sequelize.define('Product', {
    category_id:DataTypes.INTEGER,
    sub_category_id:DataTypes.INTEGER,
    brand_id:DataTypes.INTEGER,
    img: DataTypes.STRING,
    title: DataTypes.STRING,
    vendor: DataTypes.STRING,
    is_featured:DataTypes.BOOLEAN,
    is_hot:DataTypes.BOOLEAN,
    subtitle: DataTypes.STRING,
    price: DataTypes.DECIMAL,
    rating: DataTypes.DECIMAL,
    is_out_of_stock:DataTypes.STRING,
    depot:DataTypes.DECIMAL,
    sku:DataTypes.STRING,
    id_sku:DataTypes.DECIMAL,
    inventory:DataTypes.DECIMAL,
    is_active:DataTypes.BOOLEAN,
    is_sale:DataTypes.BOOLEAN,
    weight:DataTypes.INTEGER,
    variants:DataTypes.STRING,
    icon:DataTypes.STRING,
    positionL:DataTypes.INTEGER,
    positionT:DataTypes.INTEGER,
    positionW:DataTypes.INTEGER,
    positionH:DataTypes.INTEGER,
    description_1: DataTypes.STRING,
    description_2:DataTypes.STRING,
    code:DataTypes.DECIMAL,
    hashtag:DataTypes.STRING,
    technology:DataTypes.STRING,
    discount: DataTypes.DECIMAL,
    series:DataTypes.STRING,
    status:DataTypes.STRING,
    currency:DataTypes.STRING
  }, {});
  Product.associate = function(models) {
    // associations can be defined here
  };
  return Product;
};