'use strict';
module.exports = (sequelize, DataTypes) => {
    const Product = sequelize.define('Product', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        sectionID: DataTypes.INTEGER,
        category_id: DataTypes.INTEGER,
        sub_category_id: DataTypes.INTEGER,
        brand_id: DataTypes.INTEGER,
        collection_id: DataTypes.INTEGER,
        productImageId: DataTypes.INTEGER,
        thumbnailId: DataTypes.INTEGER,
        filterId: DataTypes.INTEGER,
        img: DataTypes.STRING,
        title: DataTypes.STRING,
        vendor: DataTypes.STRING,
        is_featured: DataTypes.TINYINT,
        is_hot: DataTypes.TINYINT,
        is_new: DataTypes.TINYINT,
        subtitle: DataTypes.STRING,
        price: DataTypes.DECIMAL,
        rating: DataTypes.DECIMAL,
        is_out_of_stock: DataTypes.STRING,
        depot: DataTypes.DECIMAL,
        sku: DataTypes.STRING,
        id_sku: DataTypes.STRING,
        inventory: DataTypes.DECIMAL,
        is_active: DataTypes.BOOLEAN,
        is_sale: DataTypes.BOOLEAN,
        weight: DataTypes.INTEGER,
        variants: DataTypes.STRING,
        icon: DataTypes.STRING,
        positionL: DataTypes.INTEGER,
        positionT: DataTypes.INTEGER,
        positionW: DataTypes.INTEGER,
        positionH: DataTypes.INTEGER,
        description_1: DataTypes.STRING,
        description_2: DataTypes.STRING,
        code: DataTypes.DECIMAL,
        hashtag: DataTypes.STRING,
        technology: DataTypes.STRING,
        discount: DataTypes.DECIMAL,
        discount_percent: DataTypes.DECIMAL,
        series: DataTypes.STRING,
        status: DataTypes.STRING,
        currency: DataTypes.STRING,
        available: DataTypes.TINYINT(1),
        buy_with: DataTypes.STRING,
        alter_product: DataTypes.STRING,
        createdAt: DataTypes.DATE
    }, {});
    Product.associate = function(models) {
        // associations can be defined here
    };
    return Product;
};