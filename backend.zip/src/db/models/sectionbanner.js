'use strict';
module.exports = (sequelize, DataTypes) => {
    const SectionBanner = sequelize.define('SectionBanner', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        sectionid: DataTypes.INTEGER,
        title: DataTypes.STRING,
        header: DataTypes.STRING,
        description: DataTypes.STRING,
        footer: DataTypes.STRING,
        price: DataTypes.INTEGER,
        discount: DataTypes.INTEGER,
        active: DataTypes.TINYINT,
    }, {});
    SectionBanner.associate = function(models) {
        // associations can be defined here
    };
    return SectionBanner;
};