'use strict';
module.exports = (sequelize, DataTypes) => {
  const Collection = sequelize.define('Collection', {
    CollectionID: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    CollectionName: DataTypes.STRING,
    Tag:DataTypes.STRING,
    Description: DataTypes.STRING,
    createdAt: DataTypes.STRING,
    updatedAt: DataTypes.STRING,
  }, {});
  Collection.associate = function(models) {
    // associations can be defined here
  };
  return Collection;
};