'use strict';
module.exports = (sequelize, DataTypes) => {
  const Designer = sequelize.define('Designer', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    tag: DataTypes.STRING,
    discount: DataTypes.INTEGER,
    url: DataTypes.STRING,
    projectName: DataTypes.STRING,
    solutionNumber: DataTypes.INTEGER,
    description: DataTypes.STRING,
    price: DataTypes.INTEGER,
    currency: DataTypes.STRING,
    designerName: DataTypes.STRING,
    designerAvatar: DataTypes.STRING,
    visible: DataTypes.TINYINT,
  }, {});
  Designer.associate = function(models) {
    // associations can be defined here
  };
  return Designer;
};

// "id": 55,
//       "project_name": "projectName1",
//       "img": "/static/img/instagram/1.jpg",
//       "solution_number" : 1,
//       "description": "Описание проекта 1",
//       "price": "1,665",
//       "currency" : "ГРН",
//       "url": "/design/designer1",
//       "designer":{
//         "name": "Designer1",
//         "avatar" :"/static/img/users/our-team/1.jpg"
//       }