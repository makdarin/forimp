'use strict';
module.exports = (sequelize, DataTypes) => {
  const Locale = sequelize.define('Locale', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    name: DataTypes.STRING,
    ru: DataTypes.STRING,
    en: DataTypes.STRING,
    ua: DataTypes.STRING,
    de: DataTypes.STRING,
    fr: DataTypes.STRING,
    pl: DataTypes.STRING,
  }, {});
  Locale.associate = function(models) {
    // associations can be defined here
  };
  return Locale;
};