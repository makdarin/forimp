'use strict';
module.exports = (sequelize, DataTypes) => {
  const MainBanner = sequelize.define('MainBanner', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    titleRu: DataTypes.STRING,
    subtitleRu: DataTypes.STRING,
    titleEn: DataTypes.STRING,
    subtitleEn: DataTypes.STRING,
    titleUa: DataTypes.STRING,
    subtitleUa: DataTypes.STRING,
    titleDe: DataTypes.STRING,
    subtitleDe: DataTypes.STRING,
    titleFr: DataTypes.STRING,
    subtitleFr: DataTypes.STRING,
    titlePl: DataTypes.STRING,
    subtitlePl: DataTypes.STRING,
    btnTextRu: DataTypes.STRING,
    btnTextEn: DataTypes.STRING,
    btnTextUa: DataTypes.STRING,
    btnTextDe: DataTypes.STRING,
    btnTextFr: DataTypes.STRING,
    btnTextPl: DataTypes.STRING,
    btnurl: DataTypes.STRING,
    img:DataTypes.STRING,
    active: DataTypes.TINYINT,
    createdAt: DataTypes.STRING,
    updatedAt:DataTypes.STRING
  }, {});
  MainBanner.associate = function(models) {
    // associations can be defined here
  };
  return MainBanner;
};