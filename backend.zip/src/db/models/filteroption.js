'use strict';
module.exports = (sequelize, DataTypes) => {
  const FilterOption = sequelize.define('Filter_Options', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    product_id: DataTypes.INTEGER,
    brand: DataTypes.STRING,
    series:DataTypes.STRING,
    price: DataTypes.INTEGER,
    width: DataTypes.INTEGER,
    equipment:DataTypes.STRING,
    color: DataTypes.STRING,
    material: DataTypes.STRING,
    depth: DataTypes.INTEGER,
    length: DataTypes.INTEGER,
    installation_type: DataTypes.STRING,
    form:DataTypes.STRING,
    type:DataTypes.STRING,
    control_type:DataTypes.STRING,
    country_vendor:DataTypes.STRING,
    height:DataTypes.INTEGER,
    shipping_time: DataTypes.STRING,
    shape: DataTypes.STRING,
    bowl_width: DataTypes.INTEGER,
    bowl_diameter: DataTypes.INTEGER,
  }, {});
  FilterOption.associate = function(models) {
    // associations can be defined here
  };
  return FilterOption;
};

// ["brand", "series", "price", "width", "equipment", "color", "material", "depth", "length", "installation_type", "form", "type", "control_type", "country_vendor", "height"]