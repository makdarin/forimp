'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('Filter_Options', {
      id: {
        allowNull: false,
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      product_id: {
          type: Sequelize.INTEGER 
      },
      brand: {
        type: Sequelize.STRING
      },
      price: {
        type: Sequelize.INTEGER
      },
      shipping_time: {
        type: Sequelize.STRING
      },
      shape:{
        type: Sequelize.STRING
      },
      width: {
        type: Sequelize.INTEGER
      },
      depth: {
        type: Sequelize.INTEGER
      },
      material: {
        type: Sequelize.STRING
      },
      color: {
          type: Sequelize.STRING
      },
      bowl_width: {
        type: Sequelize.INTEGER
      },
      bowl_diameter: {
        type: Sequelize.INTEGER
      },
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('Filter_Options');
  }
};