'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('ProductThumbnail', {
        id: {
        allowNull: false,
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
        },
        product_id: {
            type: Sequelize.INTEGER 
        },
        name: {
            type: Sequelize.STRING
        },
        alternativeText: {
            type: Sequelize.STRING
        },
        caption: {
            type: Sequelize.STRING
        },
        width: {
            type: Sequelize.INTEGER
        },
        height: {
            type: Sequelize.INTEGER
        },
        formats: {
            type: Sequelize.STRING
        },
        hash: {
            type: Sequelize.STRING
        },
        ext: {
            type: Sequelize.STRING
        },
        mime:{
            type: Sequelize.STRING
        },
        size:{
            type: Sequelize.DECIMAL
        },
        url:{
            type: Sequelize.STRING
        },
        previewUrl:{
            type: Sequelize.STRING
        },
        provider:{
            type: Sequelize.STRING
        },
        provider_metadata: {
            type: Sequelize.STRING
        },
        createdAt:{
            type: Sequelize.STRING
        },
        updatedAt:{
            type: Sequelize.STRING
        }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('ProductThumbnail');
  }
};