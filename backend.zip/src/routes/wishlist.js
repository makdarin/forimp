import express from "express";
import { Wishlist } from "../db/models";
import { Product } from "../db/models";

import { getProductImagesById, getProductThumbnailById } from './utilitis';

const router = express.Router();
const { Op } = require("sequelize");

router.post('/get', (req, res) => {
  try {
    Product.hasMany(Wishlist)
    Wishlist.belongsTo(Product)
    Wishlist.findAll({
      where: {
        CustomerID: req.body.authID
      },
      include: Product
    }).then( (wishlist) => {
      const retData = [];
      wishlist.map(async (item) => {
        const product = item.Product;
        const productImage = await getProductImagesById(product.id);
        const thumbnail = await getProductThumbnailById(product.id);
        retData.push({
          id:product.id,
          title:product === null ? '' : product.title,
          is_featured:product.is_featured,
          is_hot:product === null ? 0 : product.is_hot,
          price:product === null ? 0 : parseFloat(product.price),
          sale_price: product === null ? 0 :parseFloat(product.discount),
          vendor:product.vendor,
          review:parseFloat(product.rating),
          is_out_of_stock:product.is_out_of_stock,
          depot:parseFloat(product.depot),
          sku:product.sku,
          id_sku:product.id_sku,
          weight:parseFloat(product.weight),
          inventory:parseFloat(product.inventory),
          is_active:product.is_active,
          is_sale:product.is_sale,
          currency: product.currency,
          discount_percent:product.discount_percent,
          available: product.available,
          buy_with: [],
          alter_product: [],
          created_at:product.created_at,
          updated_at:product.update,
          variants:[],
          icon:product.icon,
          quantity:item.quantity,
          rect:[
              product.positionL,
              product.positionT,
              product.positionW,
              product.positionH
          ],
          filterOptions:[],
          images: productImage,
          thumbnail,
          product_categories: [],
          brands:[],
          collections:[]
        });
      }) 
      setTimeout(()=>{
        res.json(retData)
      }, 1000)
    })
  } catch(err) {
    res.json(err)
  }
});

router.post('/add', async (req, res) => {
  try {
    Wishlist.findOne(
      {
        where:{
          CustomerID: req.body.authID,
          ProductID: req.body.productID,
        }
      }
    ).then(async function(wishlist){
      if( wishlist ){
        const upd = wishlist.update({
          quantity: req.body.quantity,
          updateAt: Date.now(),
        },{
          where: {
            CustomerID: req.body.authID,
            ProductID: req.body.productID,
          },
        });
        res.json(upd);
      } else{
        const wishlist = await Wishlist.create({
          CustomerID: req.body.authID,
          ProductID: req.body.productID,
          quantity: req.body.quantity,
          createAt: Date.now(),
          updateAt: Date.now(),
        });
        res.json(wishlist)
      }
    })
  } catch (err) {
    res.json(err)
  }
});

router.post('/remove', (req, res) => {
  try {
    const wishlist = Wishlist.destroy({
      where: {
        [Op.and]: [
          { ProductID: req.body.productID },
          { CustomerID: req.body.authID }
        ]
      },
    })
    res.json(wishlist)
  } catch (err) {
    res.json(err)
  }
});

router.post('/clear', (req, res) => {
  const id = req.body.auth.data.user.CustomerID === undefined ? req.body.auth.data.user.id : req.body.auth.data.user.CustomerID;
  try {
    const wishlist = Wishlist.destroy({
      where: {
        [Op.and]: [
          { CustomerID: id }
        ]
      },
    })
    res.json(wishlist)
  } catch (err) {
    res.json(err)
  }
});

module.exports = router;
