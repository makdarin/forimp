import express from "express";
import { 
    Section,
    Subsection,
    Sectionitem,
    SectionBanner,
    SectionBanImage,
    SectionBanCategory,
    Subcategory,
} from "../db/models";

const router = express.Router();

router.get('/', (req, res) => {
    console.log("getting start====>")
    try {
        let count = 0;
        Section.findAll({
            where: {
                visible: 1
            }
        }).then(async(sections) => {
            let ret = [];
            await sections.map(async(element) => {
                const ssId = element.id;
                let subMenu = await getSubSection(ssId);
                let megaContent = [];
                let sectionItem = [];
                if (element.mega) {
                    await subMenu.map(async ele => {
                        sectionItem = await getSectionItem(ele.id);
                        megaContent.push({
                            heading: ele.text,
                            url: ele.url,
                            megaItems: sectionItem
                        })
                    });
                    count++;
                    ret.push({
                        text: element.name,
                        url: element.url,
                        chapter_id: element.id,
                        extraClass: "menu-item-has-children has-mega-menu",
                        subClass: "sub-menu",
                        mega: "true",
                        megaContent: megaContent
                    });
                } else {
                    count++;
                    ret.push({
                        text: element.name,
                        url: element.url,
                        chapter_id: element.id,
                        extraClass: "menu-item-has-children",
                        subClass: "sub-menu",
                        subMenu: subMenu
                    });
                }
                if( count === sections.length){
                    setTimeout(() => {
                        const sortedData = ret.sort(function(a, b) {
                            return a.chapter_id - b.chapter_id;
                        });
                        res.json(sortedData);
                    }, 1000);
                    
                }
            });
        })
    } catch (err) {
        res.json(err)
    }
});

function getSubSection(id) {
    return new Promise(async(resolve, reject) => {
        await Subsection.findAll({
            where: {
                sectionid: id,
                visible: 1,
            }
        }).then((subsection) => {
            if (subsection) {
                let ret = [];
                subsection.forEach(ele => {
                    ret.push({
                        id: ele.id,
                        text: ele.name,
                        url: ele.url,
                    })
                })
                resolve(ret);
            } else {
                resolve();
            }
        }).catch((err) => {
            reject(err);
        });
    })
}

function getSectionItem(id) {
    return new Promise(async(resolve, reject) => {
        await Sectionitem.findAll({
            where: {
                subsectionid: id,
                visible: 1
            }
        }).then((subsection) => {
            if (subsection) {
                let ret = [];
                subsection.forEach(ele => {
                    ret.push({
                        text: ele.name,
                        url: ele.url,
                    })
                })
                resolve(ret);
            } else {
                resolve();
            }
        }).catch((err) => {
            reject(err);
        });
    })
}

router.get('/banner/:id', (req, res) => {
    const sid = req.params.id;
    SectionBanner.findOne({
        where: {
            sectionid: parseInt(sid)
        }
    }).then((sbitems) => {
        if (sbitems === null)
            res.json(sbitems);
        const sbid = sbitems.id;
        let category = [];
        let imgs = [];
        SectionBanImage.findAll({
            where: {
                sectionbannerid: sbid
            }
        }).then((sbiItems) => {
            imgs = sbiItems;
        });

        SectionBanCategory.findAll({
            where: { sectionbannerid: sbid}
        }).then((sbcItems) => {
            category = sbcItems;
        });

        setTimeout(() => {
            res.json({
                id: sbid,
                title: sbitems.title,
                header: sbitems.header,
                description: sbitems.description.split(','),
                footer: sbitems.footer,
                price: sbitems.price,
                discount: sbitems.discount,
                active: sbitems.active,
                imgs,
                category,
            })
        }, 1000);
    })
})

router.get("/banner/subcategory/:id", (req, res) => {
    const id = parseInt(req.params.id);
    SectionBanCategory.findOne({
        where: { cateogryId: id }
    }).then((it) => {
        if( it !== null ){
            Subcategory.findAll({
                where: { CategoryID: it.cateogryId, active: 1 }
            }).then((subRes) => {
                res.json({
                    id: it.id,
                    sectionbannerid: it.sectionbannerid,
                    url: it.url,
                    name: it.name,
                    imgurl: it.imgurl,
                    picUrl: it.picUrl,
                    title: it.title,
                    header: it.header,
                    description: it.description.split(','),
                    footer: it.footer,
                    price: it.price,
                    discount: it.discount,
                    active: it.active,
                    sub: subRes,
                });
            })
        }
    });
});
module.exports = router;

//menuceramics