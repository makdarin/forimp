import express from "express";
import { Collection, Product } from "../db/models";
import config from "../config";
import { 
    getCollectionBySlug,
    getCategoryById, 
    getProductImagesById, 
    getProductThumbnailById, 
    getBrandById, 
    getFilterOptionsByID 
} from './utilitis';

const router = express.Router();

function makeReturnProductData(products, req, res){
    return new Promise(async(resolve, reject) => {
        let retproduct = [];
        products.map( async (product, index) => {
            const pID = product.id;
            const cID = product.category_id;
            const bID = product.brand_id;
        
            const category = await getCategoryById(cID);
            const productImage = await getProductImagesById(pID);
            const thumbnail = await getProductThumbnailById(pID);
            const brands = await getBrandById(bID);
            const filterOpt = await getFilterOptionsByID(pID);

            let filterOptions = [];
            if( filterOpt != undefined ){
                if( filterOpt.brand != "" ) filterOptions.push({key:"Brand", value:filterOpt.brand});
                if( filterOpt.price != 0 ) filterOptions.push({key:"Price", value:filterOpt.price});
                if( filterOpt.shipping_time != "" ) filterOptions.push({key:"Shippingtime", value:filterOpt.shipping_time});
                if( filterOpt.shape != "" ) filterOptions.push({key:"Shape", value:filterOpt.shape});
                if( filterOpt.width != 0 ) filterOptions.push({key:"Width", value:filterOpt.width});
                if( filterOpt.depth != 0 ) filterOptions.push({key:"Depth", value:filterOpt.delete});
                if( filterOpt.material != "" ) filterOptions.push({key:"Material", value:filterOpt.material});
                if( filterOpt.color != "" ) filterOptions.push({key:"Color", value:filterOpt.color});
                if( filterOpt.bowl_width != 0 ) filterOptions.push({key:"Bowlwidth", value:filterOpt.bowl_width});
                if( filterOpt.bowl_diameter != 0 ) filterOptions.push({key:"Bowldiameter", value:filterOpt.bowl_diameter});
            }
            return retproduct.push({
                id:pID,
                title:product.title,
                is_featured:product.is_featured,
                is_hot:product.is_hot,
                price: parseFloat(product.price),
                sale_price:parseFloat(product.discount),
                vendor:product.vendor,
                review:parseFloat(product.rating),
                is_out_of_stock:product.is_out_of_stock,
                depot:parseFloat(product.depot),
                inventory:parseFloat(product.inventory),
                is_active:product.is_active,
                is_sale:product.is_sale,
                created_at:product.created_at,
                updated_at:product.update,
                variants:[],
                icon:product.icon,
                rect:[
                    product.positionL,
                    product.positionT,
                    product.positionW,
                    product.positionH
                ],
                filterOptions,
                images: productImage,
                thumbnail,
                product_categories: [category],
                brands:[brands],
                collections:[]
            });
        })

        setTimeout(() => {
            resolve(retproduct);
        }, (2000));
    })
}

router.get('/', (req, res) => {
    console.log("this is server slugin ==> " , req.query.slug_in)
    const slugin = req.query.slug_in;
    let data = [];
    slugin.map(async (slug) => {
        const oneCollection = await getCollectionBySlug(slug);
        if( oneCollection[0] !== undefined )
            if( oneCollection[0].dataValues !== undefined)
            {
                const colID = oneCollection[0].dataValues.CollectionID;
                Product.findAll({
                    where : {
                        collection_id: parseInt(colID)
                    }
                }).then(async (product) => {
                    const resproduct = await makeReturnProductData(product, req, res);
                    data.push({
                        id: colID,
                        name:oneCollection[0].dataValues.CollectionName,
                        slug:oneCollection[0].dataValues.Tag,
                        description:oneCollection[0].dataValues.Description,
                        created_at:oneCollection[0].dataValues.createdAt,
                        updated_at:oneCollection[0].dataValues.updatedAt,
                        products: resproduct
                    })
                })
            }
    })
    setTimeout(()=>{
        res.json(data);
    }, 2500)
    
});


module.exports = router;