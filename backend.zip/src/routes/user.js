import express from "express";
import bcrypt from "bcryptjs";
const crypto = require("crypto");
import passport from "passport";
import { User, Customer } from "../db/models";
import config from "../config";
import helpers from "../helpers/helpers";
const nodemailer = require("nodemailer");
const sendgrid = require("nodemailer-sendgrid-transport")

const regEmail = require("../emails/registration");
const resetEmail = require("../emails/reset")


const transporter = nodemailer.createTransport(sendgrid({
  auth: {api_key: config.SENDGRID_API_KEY}
}))

const router = express.Router();

router.post('/signup', (req, res) => {
  Customer.findOne({
    where: {
      Email: req.body.email
    }
  }).then((customer) => {
    if (customer) {
      res.status(400).send("Пользователь с таким email уже существует!");
    } else {
      bcrypt.hash(req.body.password, config.bcrypt.saltRounds, (err, hash) => {
        Customer.create({
          Email: req.body.email,
          Password: hash
        }).then((customer) => {
          res.json(customer);
          transporter.sendMail(regEmail(req.body.email)) //await
        });
      });
    }
  }).catch((err) => {
    res.status(err.statusCode).send(err.message);
  })
});

router.post('/signin/password', (req, res) => {
  try {
    crypto.randomBytes(32, (err, buffer) => {
      if(err) {
        req.flash('error', 'Что-то пошло не так, повторите попытку')
      }
      const token = buffer.toString('hex')

      const candidate = Customer.findOne({
        where: {
          Email: req.body.email,
        }
      })

      if(candidate) {
        candidate.ResetToken = token;
        candidate.ResetTokenExp = Date.now() + 60*60*1000 //to milliseconds
        // candidate.update()
        Customer.update({...req.body, ...{
            ResetToken: token,
            ResetTokenExp: Date.now() + 60*60*1000
          }}, {where: {Email: req.body.email}}).then((user) => {
          transporter.sendMail(resetEmail(req.body.email, token))
          res.json({success: true, user})
        }).catch((err) => {
          res.status(err.statusCode).send(err.message);
        });

      } else {
        res.status(400).send("Customer with this email does not exist");
      }
    })

  } catch (e) {
    console.log(e);
  }
})

router.post('/password/token', async (req, res) => {
  if(!req.body.token) {
    res.json(400).send("Ошибка данных")
  }
  try {
    const user = await Customer.findOne({
      where: {
        ResetToken: req.body.token,
        // ResetTokenExp: {$gt: Date.now()},
      }
    })
    if(!user) {
      return res.redirect(`${config.BASE_URL}/account/login`)
    } else {
      // return res.redirect(`${config.BASE_URL}/account/password`)
      res.json({userId: user.CustomerID.toString(),token: req.body.token});
/*      res.render(`${config.BASE_URL}/account/password`, {
        titile: 'Password recovery',
        error: req.flash('error'),
        userId: user.CustomerID.toString(),
        token: req.body.token
      })*/
    }
  } catch(e) {
    console.log(e)
  }
})

router.post('/signin/newpassword', async(req, res) => {
  try {
    Customer.findOne({
      where: {
        CustomerID: req.body.userId,
        ResetToken: req.body.token,
      }
    }).then((customer) => {
      if (customer) {
        bcrypt.hash(req.body.password.password, config.bcrypt.saltRounds, (err, hash1) => {
          Customer.update({
            ResetToken: null,
            ResetTokenExp: null,
            Password: hash1
          },
              {where: {
                CustomerID: req.body.userId
              }
          }).then((customer) => {
            res.json(customer);
          });
        });
      } else {

      }
    }).catch((err) => {
      res.status(err.statusCode).send(err.message);
    })
  } catch(e) {
    console.log(e)
  }




//
//     const user = await Customer.findOne({
//       where: {
//         CustomerID: req.body.userId,
//         ResetToken: req.body.token,
//         // ResetTokenExp:   {$gt: Date.now()},
//       }
//     })
//
//     if(user) {
//       console.log(user.CustomerID)
//       // user.password = await bcrypt.hash(req.body.password, 10)
//       // user.resetToken = undefined,
//       //     user.resetTokenExp = undefined
//       // await user.save()
//       bcrypt.hash(req.body.password, config.bcrypt.saltRounds, (err, hash) => {
//         console.log(hash)
//         console.log(req.body.password)
//         user.update({...req.body, ...{
//                 Password: hash,
//                 ResetToken: null,
//                 ResetTokenExp: null
//               }}).then((user) => {
//           res.redirect('/account/login')
//           // res.json({success: true, user})
//         }).catch((err) => {
//           res.status(err.statusCode).send(err.message);
//         });
//       });
//
//
// /*      bcrypt.hash(req.body.password, config.bcrypt.saltRounds, (err, hash) => {
//         Customer.update({...req.body, ...{
//                 Password: hash,
//                 ResetToken: undefined,
//                 ResetTokenExp: undefined
//               }},
//             {where: {
//                 CustomerID: req.body.userId
//               }
//             }).then((user) => {
//           res.redirect('/account/login')
//           res.json({success: true, user})
//         }).catch((err) => {
//           res.status(err.statusCode).send(err.message);
//         });
//       });*/
//
//       // Customer.update({...req.body, ...{
//       //     Password: await bcrypt.hash(req.body.password, salt),
//       //     ResetToken: undefined,
//       //     ResetTokenExp: undefined
//       //   }},
//       //     {where: {
//       //         CustomerID: req.body.userId
//       //       }
//       //     }).then((user) => {
//       //   res.redirect('/account/login')
//       //   res.json({success: true, user})
//       // }).catch((err) => {
//       //   res.status(err.statusCode).send(err.message);
//       // });
//     } else {
//       res.status(400).send("Token Time expired");
//       // res.redirect('/account/login/')
//     }
//
//   } catch(e) {
//     console.log(e)
//   }
})

router.post('/signin/local', (req, res) => {
  Customer.findOne({
    where: {
      Email: req.body.email,
    }
  }).then(user => {
    bcrypt.compare(req.body.password, user.Password).then((equal) => {
      if (equal) {
        const body = {
          id: user.CustomerID,
          email: user.Email
        };
        const token = helpers.jwtSign({ user: body });
        res.json({
          user,
          success: true,
          token
        })
      } else {
        res.status(400).send("Ошибка авторизации! Проверьте ваш логин/пароль!");
      }
    });
  }).catch(() => {
    res.status(400).send("Клиент с данным email не найден");
  })
});

router.get('/signin/google', (req, res, next) => {
  passport.authenticate("google", { scope: ["profile", "email"], state: req.query.app })(req, res, next);
});

router.get('/signin/google/callback', passport.authenticate("google", { failureRedirect: "/login", session: false }),
  function (req, res) {
    socialRedirect(res, req.query.state, req.user.token, config);
  }
);

router.get('/signin/facebook', (req, res, next) => {
  passport.authenticate("facebook", { scope: ["profile", "email"], state: req.query.app })(req, res, next);
});

router.get('/signin/facebook/callback', passport.authenticate("facebook", { failureRedirect: "/login", session: false }),
  function (req, res) {
    socialRedirect(res, req.query.state, req.user.token, config);
  }
);

router.get('/signin/microsoft', (req, res, next) => {
  passport.authenticate("microsoft", { scope: ["https://graph.microsoft.com/user.read openid"], state: req.query.app })(req, res, next);
});

router.get('/signin/microsoft/callback', passport.authenticate("microsoft", { failureRedirect: "/login", session: false }),
  function (req, res) {
    socialRedirect(res, req.query.state, req.user.token, config);
  }
);

function socialRedirect(res, state, token, config) {
  let url;
  let fullPath = /^http(s?):\/\//.test(state);
  if (fullPath) {
    url = state;
  } else {
    url = config.hostUI + `${config.portUI ? `:${config.portUI}` : ``}` + `${state ? `/${state}` : ``}`;
  }
  res.redirect(url + "/#/login?token=" + token);
}

module.exports = router;
