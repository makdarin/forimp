import express from "express";
import { Category } from "../db/models";
import config from "../config";

const router = express.Router();

router.get('/',  (req, res) => {
    Category.findAll().then( category => {
        res.json(category);
    })
});

router.get('/:id', (req, res) => {
    Category.findOne({
        where: { CategoryID: parseInt(req.params.id) }
    }).then(category => {
        res.json(category);
    })
});


module.exports = router;