import express from "express";
import { Category, Subcategory } from "../db/models";
import config from "../config";

const router = express.Router();

router.get('/', (req, res) => {
    try {
        Category.findAll().then(category => {
            const ret = [];
            category.map((item) => {
                Subcategory.findAll({
                    where: { CategoryID: item.CategoryID }
                }).then((subcategory) => {
                    ret.push({
                        CategoryID: item.CategoryID,
                        SectionID: item.sectionID,
                        CategoryName: item.CategoryName,
                        LocaleName: item.LocaleName,
                        Slug: item.Slug,
                        Description: item.Description,
                        Tag: item.Tag,
                        Picture: item.Picture,
                        Active: item.Active,
                        subcategory
                    })
                })
            })

            setTimeout(() => {
                res.json(ret);
            }, 1500)
        })
    } catch (e) {
        console.log(e);
    }

});

router.get('/subcate', (req, res) => {
    try {
        let ret = [];
        Subcategory.findAll().then((subcategory) => {
            subcategory.map((item) => {
                ret.push(item.SubCategoryName)
            })
        })

        setTimeout(() => {
            res.json(ret);
        }, 1500)
    } catch (e) {
        console.log(e);
    }
})
router.get('/:id', (req, res) => {
    Category.findOne({
        where: { CategoryID: parseInt(req.params.id) }
    }).then(category => {
        res.json(category);
    })
});

module.exports = router;