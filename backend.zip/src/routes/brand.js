import express from "express";
import { Brand } from "../db/models";
import config from "../config";

const router = express.Router();

router.get('/',  (req, res) => {
    Brand.findAll().then( brand => {
        res.json(brand);
    })
});

module.exports = router;