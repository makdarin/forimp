import express from "express";
import { OneClickOrder, Order, OrderDetail } from "../db/models";
import config from "../config";
import cons from "consolidate";
const dateFormat = require('dateformat');
const Sequelize = require('sequelize');
const nodemailer = require("nodemailer");
const sendgrid = require("nodemailer-sendgrid-transport")

const regEmail = require("../emails/registration");
const orderEmail = require("../emails/order-confirmation")

const transporter = nodemailer.createTransport(sendgrid({
    auth: { api_key: config.SENDGRID_API_KEY }
}))


const router = express.Router();

router.get('/liqpay', async(req, res) => {
    // console.log("this is liqpayment")
    // var LiqPay = require('liqpay');
    // var liqpay = new LiqPay('sandbox_i54424020395', 'sandbox_RVP1JhTEUO9gu4TXeVEa9gyc0hF9CGUFh0S7JuTH');
    // var sign = liqpay.str_to_sign(
    //     PRIVATE_KEY +
    //     data +
    //     PRIVATE_KEY
    //     );
    // var html = liqpay.cnb_form({
    //     'action'         : 'pay',
    //     'amount'         : '1',
    //     'currency'       : 'USD',
    //     'description'    : 'description text',
    //     'order_id'       : 'order_id_1',
    //     'version'        : '3'
    // });

})

router.post('/oneclick', async(req, res) => {
    try {
        await OneClickOrder.create({
            product_id: req.body.productId,
            product_title: req.body.title,
            product_sku: req.body.sku,
            phonenumber: req.body.phone,
            active: req.body.active
        }).then((item) => {
            res.json({ status: true, id: item.id });
        })
    } catch (err) {
        res.json({ status: false });
    }
})

router.post('/get/total', async(req, res) => {
    const retData = [];

    await Order.findAll().then((order) => {
        order.map((item) => {
            let insert = item.dataValues;
            const ordernumber = item.OrderNumber;
            OrderDetail.findAll({
                where: {
                    OrderNumber: ordernumber
                }
            }).then((detailItem) => {
                detailItem.map((detail) => {
                    const insertItem = {
                        ...insert,
                        sku: detail.IDSKU,
                        mpn: detail.mpn,
                        name: detail.Title,
                        vendor: detail.Vendor,
                        amount: detail.Quantity,
                        price: detail.Price,
                        tracking: detail.TrackingNumber,
                        Status: detail.Status
                    }
                    retData.push(insertItem);
                })
            })
        })
    })
    setTimeout(() => {
        res.json(retData)
    }, 1000);
});


router.post('/get/list', async(req, res) => {
    const retData = [];
    await Order.findAll({
        where: {
            CustomerID: req.body.data.user.CustomerID === undefined ? req.body.data.user.id : req.body.data.user.CustomerID
        }
    }).then((order) => {
        order.map((item) => {
            let insert = item.dataValues;
            const ordernumber = item.OrderNumber;
            OrderDetail.findAll({
                where: {
                    OrderNumber: ordernumber
                }
            }).then((detailItem) => {
                detailItem.map((detail) => {
                    const insertItem = {
                        ...insert,
                        sku: detail.IDSKU,
                        mpn: detail.mpn,
                        name: detail.Title,
                        vendor: detail.Vendor,
                        amount: detail.Quantity,
                        price: detail.Price,
                        tracking: detail.TrackingNumber,
                        Status: detail.Status
                    }
                    retData.push(insertItem);
                })
            })
        })
    })
    setTimeout(() => {
        res.json(retData)
    }, 1000);
});

router.post('/lastorder', async(req, res) => {

    await Order.findOne({
        attributes: [
            [Sequelize.fn('MAX', Sequelize.col('OrderNumber')), 'OrderNumber']
        ]
    }).then(function(result) {
        res.json({ 'payment_result': 'succed', 'orderId': result.OrderNumber, 'email': result.Email });
    });
});


router.post('/pay', async(req, res) => {
    const { authID, amount, email, name, department, deliveryMethod, phone, name1, surname, payMethod, payOption, items, city, notCall, notice } = req.body;
    try {
        const date_ = Date.now();
        const date = dateFormat(date_, "yyyy-mm-dd h:MM:ss");
        const orderDate = dateFormat(date_, "yyyy-mm-dd");

        let maxId = '';
        await Order.findOne({
            attributes: [
                [Sequelize.fn('MAX', Sequelize.col('OrderNumber')), 'OrderNumber']
            ]
        }).then(function(result) {
            maxId = result.OrderNumber;
        });

        let notCall_ = 0
        if (notCall) {
            notCall_ = 1
        }

        const id = getOrderId(maxId);
        const orderItem = await Order.create({
            CustomerID: authID,
            OrderNumber: id,
            Amount: amount,
            Name: name,
            Surname: surname,
            City: city,
            Department: department,
            ShipperID: deliveryMethod.id,
            Paid: true,
            Email: email,
            NotCall: notCall_,
            Phone: phone,
            Currenry: 'UAH',
            Status: 'новый',
            Notice: notice,
            PaymentID: payOption.id,
            PaymentMethod: payOption.name,
            OrderDate: orderDate,
            createAt: date,
            updateAt: date,
        }).then(async(ordered) => {
            items.map(async(orderprod) => {
                await OrderDetail.create({
                    OrderID: ordered.OrderID,
                    ProductID: orderprod.id,
                    OrderNumber: ordered.OrderNumber,
                    IDSKU: orderprod.sku,
                    mpn: orderprod.id_sku,
                    Quantity: orderprod.quantity,
                    Price: orderprod.sale_price,
                    Title: orderprod.title,
                    Vendor: orderprod.vendor,
                    Status: 'новый',
                    createdAt: date,
                    updateAt: date
                })
            })
            res.json({ 'payment_result': 'succed', 'orderId': id, 'email': email });
            await transporter.sendMail(orderEmail(email, id)) //await
        })

    } catch (err) {
        res.json({ 'payment_result': err });

    }
})

router.post('/paymentLater', async(req, res) => {
    const { authID, amount, email, name, department, deliveryMethod, phone, name1, surname, payMethod, payOption, items, city, notCall, notice } = req.body;
    const amnt = parseInt(amount) * 100;
    try {
        const date_ = Date.now();
        const date = dateFormat(date_, "yyyy-mm-dd hh:MM:ss");
        const orderDate = dateFormat(date_, "yyyy-mm-dd");
        var maxId = '';

        await Order.findOne({
            attributes: [
                [Sequelize.fn('MAX', Sequelize.col('OrderNumber')), 'OrderNumber']
            ]
        }).then(function(result) {
            maxId = result.OrderNumber;
        });

        const id = getOrderId(maxId === null ? '' : maxId);
        let notCall_ = 0
        if (notCall) {
            notCall_ = 1
        }
        const orderItem = await Order.create({
            CustomerID: authID,
            OrderNumber: id,
            Amount: amount,
            Name: name,
            Surname: surname,
            City: city,
            Department: department,
            ShipperID: deliveryMethod.id,
            Email: email,
            NotCall: notCall_,
            Notice: notice,
            Phone: phone,
            Paid: false,
            Currency: `UAH`,
            Status: 'новый',
            PaymentID: payOption.id,
            PaymentMethod: payOption.name,
            OrderDate: orderDate,
            createAt: date,
            updateAt: date,
        }).then(async(ordered) => {
            items.map(async(orderprod) => {
                await OrderDetail.create({
                    OrderID: ordered.OrderID,
                    ProductID: orderprod.id,
                    OrderNumber: ordered.OrderNumber,
                    IDSKU: orderprod.sku,
                    mpn: orderprod.id_sku,
                    Quantity: orderprod.quantity,
                    Price: orderprod.sale_price,
                    Title: orderprod.title,
                    Vendor: orderprod.vendor,
                    Status: 'новый',
                    createdAt: date,
                    updateAt: date
                })
            })
            res.json({ 'payment_result': 'succed', 'orderId': id, 'email': email });
            await transporter.sendMail(orderEmail(email, id)) //await
        })
    } catch (err) {
        res.json({ 'payment_result': 'failed', err });
    }
});

const getOrderId = (maxId) => {
    if (maxId.includes('-'))
        return 'AI00000001';
    const sub = maxId.substring(2, 10);
    const isub = sub == '' ? 1 : parseInt(sub) + 1;
    let zero = '';
    for (let i = 0; i < 8 - isub.toString().length; i++) {
        zero += '0';
    }
    return 'AI' + zero + isub;
}

module.exports = router;