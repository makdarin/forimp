import express from "express";
import {Customer, Order} from "../db/models";
import bcrypt from "bcryptjs";
import config from "../config";
const orderid = require('order-id')('mysecret')
const dateFormat = require('dateformat');

const nodemailer = require("nodemailer");
const sendgrid = require("nodemailer-sendgrid-transport")

const regEmail = require("../emails/registration");
const orderEmail = require("../emails/order-confirmation")


const transporter = nodemailer.createTransport(sendgrid({
  auth: {api_key: config.SENDGRID_API_KEY}
}))


const router = express.Router();

router.post('/get/list', (req, res) => {
  Order.findAll({
    where: {
      CustomerID: req.body.data.user.CustomerID
    }
  }).then((order) => {
    res.json(order)
  })
});

router.post('/add/nonpay', (req, res) => {
  const date_ = Date.now();
  const date = dateFormat(date_, "yyyy-mm-dd h:MM:ss");
  const orderDate = dateFormat(date_, "yyyy-mm-dd");
  const id = orderid.generate()
  console.log(id)
  console.log(date)
  console.log(req.body)

  try {
    transporter.sendMail(orderEmail(req.body.email, req.body.orderId)) //await
    // Order.create({
    //   OrderNumber: id,
    //   Amount:  req.body.reqdata.amount,
    //   Name: req.body.reqdata.name,
    //   Surname: req.body.reqdata.surname,
    //   Email:  req.body.reqdata.email,
    //   Phone:  req.body.reqdata.phone,
    //   City:  req.body.reqdata.city,
    //   Department: req.body.reqdata.department,
    //   ShipperID: req.body.reqdata.deliveryMethodId,
    //   Paid: false,
    //   PaymentID: req.body.reqdata.payMethod,
    //   Currency: 'UAH',
    //   OrderDate: orderDate,
    //   Created: date
    // }).then((order) => {
    //   res.json(order);
    //   transporter.sendMail(orderEmail(req.body.reqdata.email, id)) //await
    // });
  } catch (e) {
    console.log(e)
  }

  // var sql = "INSERT INTO orders (OrderNumber, Amount, Name, Surname, Email, Phone, City, Department, ShipperID, Paid, PaymentID, PaymentMethod, Currency, OrderDate, Created) VALUES ?";
  // var sql1 = "INSERT INTO orderdetails (OrderNumber, IDSKU, Quantity, Price, Title, Vendor, Created) VALUES ?";
  //


/*  Customer.findOne({
    where: {
      Email: req.body.email
    }
  }).then((customer) => {
    if (customer) {
      res.status(400).send("Пользователь с таким email уже существует!");
    } else {
      bcrypt.hash(req.body.password, config.bcrypt.saltRounds, (err, hash) => {
        Customer.create({
          Email: req.body.email,
          Password: hash
        }).then((customer) => {
          res.json(customer);
          transporter.sendMail(regEmail(req.body.email)) //await
        });
      });
    }
  }).catch((err) => {
    res.status(err.statusCode).send(err.message);
  })*/
});

module.exports = router;
