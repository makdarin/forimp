import express from "express";
import { Product, Brand, Category, Collection, ProductImage, ProductThumbnail, Filter_Options, Order } from "../db/models";
import config from "../config";
import fs from "fs";
import path from "path";
import { getCategoryById, getProductImagesById, getProductThumbnailById, getBrandById, getFilterOptionsByID } from './utilitis';
// import {tempProducts , otherData, enFilters} from "../../temp";
import { result } from "lodash";

const Sequelize = require('sequelize');
const router = express.Router();

const Op = Sequelize.Op;
const cst = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p"];

router.get('/images-list', (req, res) => {
    fs.readdir(path.resolve(process.env.PWD + '/public/assets/products/'), (err, files) => {
        files = files.filter(item => !(/(^|\/)\.[^\/\.]/g).test(item)).map(f => config.apiUrl + '/assets/products/' + f);
        res.json(files);
    });
});

async function makeReturnProductData(products, req, res) {
    try {
        const retproduct = products.map((product, index) => {
            const pID = product === null ? null : product.id;
            const category = product.Category;
            const imgurls = product.ProductImage === null ? [] : product.ProductImage.url.split(',');
            let productImage = [];
            productImage = imgurls.map((url) => {
                return {
                    id: product.ProductImage.id,
                    product_id: product.ProductImage.product_id,
                    url
                }
            });
            const thumbnail = product.ProductThumbnail;
            const brands = product.Brand;
            const filterOpt = product.Filter_Option;

            let filterOptions = [];
            if (filterOpt != undefined) {
                if (filterOpt.brand != "") filterOptions.push({ key: "Brand", ru_key: "Бренд", value: filterOpt.brand });
                if (filterOpt.series != "") filterOptions.push({ key: "Series", ru_key: "Серия", value: filterOpt.series });
                if (filterOpt.price != 0) filterOptions.push({ key: "Price", ru_key: "Цена", value: filterOpt.price });
                if (filterOpt.shipping_time != "") filterOptions.push({ key: "Shippingtime", ru_key: "Время доставки", value: filterOpt.shipping_time });
                if (filterOpt.shape != "") filterOptions.push({ key: "Shape", ru_key: "Форма", value: filterOpt.shape });
                if (filterOpt.width != 0) filterOptions.push({ key: "Width", ru_key: "Ширина", value: filterOpt.width });
                if (filterOpt.equipment != 0) filterOptions.push({ key: "Equipment", ru_key: "Комплектация", value: filterOpt.equipment });
                if (filterOpt.depth != 0) filterOptions.push({ key: "Depth", ru_key: "Глубина", value: filterOpt.depth });
                if (filterOpt.material != "") filterOptions.push({ key: "Material", ru_key: "Материал", value: filterOpt.material });
                if (filterOpt.length != "") filterOptions.push({ key: "Length", ru_key: "Длина", value: filterOpt.length });
                if (filterOpt.installation_type != "") filterOptions.push({ key: "InstallationType", ru_key: "Монтаж", value: filterOpt.installation_type });
                if (filterOpt.color != "") filterOptions.push({ key: "Color", ru_key: "Цвет", value: filterOpt.color });
                if (filterOpt.form != "") filterOptions.push({ key: "Form", ru_key: "Форма", value: filterOpt.form });
                if (filterOpt.type != "") filterOptions.push({ key: "Type", ru_key: "Тип", value: filterOpt.type });
                if (filterOpt.control_type != "") filterOptions.push({ key: "ControlType", ru_key: "Тип упрaвления", value: filterOpt.control_type });
                if (filterOpt.country_vendor != "") filterOptions.push({ key: "CountryVendor", ru_key: "Страна производитель", value: filterOpt.country_vendor });
                if (filterOpt.height != "") filterOptions.push({ key: "Height", ru_key: "Рост", value: filterOpt.height });
                if (filterOpt.bowl_width != 0) filterOptions.push({ key: "Bowlwidth", ru_key: "Ширина чаши", value: filterOpt.bowl_width });
                if (filterOpt.bowl_diameter != 0) filterOptions.push({ key: "Bowldiameter", ru_key: "Диаметр чаши", value: filterOpt.bowl_diameter });
            }
            const buy = product.buy_with === null || product.buy_with === '' ? [] : product.buy_with.split('-');
            const alter = product.alter_product === null || product.alter_product === '' ? [] : product.alter_product.split('-');
            return {
                id: pID,
                title: product === null ? '' : product.title,
                is_featured: product? product.is_featured: false,
                is_hot: product === null ? false : product.is_hot,
                is_new: product.is_new === 0 ? false: true,
                price: product === null ? 0 : parseFloat(product.price),
                sale_price: product === null ? 0 : parseFloat(product.discount),
                vendor: product.vendor,
                review: parseFloat(product.rating),
                is_out_of_stock: product.is_out_of_stock,
                depot: parseFloat(product.depot),
                sku: product.sku,
                id_sku: product.id_sku,
                description_1: product.description_1,
                weight: product.weight == null ? 0 : parseFloat(product.weight),
                inventory: parseFloat(product.inventory),
                is_active: product.is_active,
                is_sale: product.is_sale,
                currency: product.currency,
                discount_percent: product.discount_percent,
                available: product.available,
                url: product.img,
                buy_with: buy,
                alter_product: alter,
                created_at: product.created_at,
                updated_at: product.update,
                variants: [],
                icon: product.icon,
                quantity: 0,
                sub_category_id: product.sub_category_id,
                rect: [
                    product.positionL,
                    product.positionT,
                    product.positionW,
                    product.positionH
                ],
                filterOptions,
                images: productImage,
                thumbnail,
                product_categories: [category],
                brands: [brands],
                collections: []
            };
        })
        res.json(retproduct);
    } catch (err) {
        console.log(err)
    }
}


async function makeReturnProductData2(products, req, res) {
    try {
        let retproduct = [];
        await products.map(async(product, index) => {
            const pID = product === null ? null : product.id;
            const cID = product === null ? null : product.category_id;
            const bID = product === null ? null : product.brand_id;
            const category = cID !== null ? await getCategoryById(cID) : {};
            const temp = await getProductImagesById(pID);
            const imgurls = temp === null || temp[0] === undefined ? [] : temp[0].url.split(',');
            let productImage = [];
            productImage = imgurls.map((url) => {
                return {
                    id: temp[0].id,
                    product_id: temp[0].product_id,
                    url
                }
            });
            const thumbnail = await getProductThumbnailById(pID);
            const brands = bID > 0 ? await getBrandById(bID) : {};
            const filterOpt = await getFilterOptionsByID(pID);

            let filterOptions = [];
            if (filterOpt != undefined) {
                if (filterOpt.brand != "") filterOptions.push({ key: "Brand", ru_key: "Бренд", value: filterOpt.brand });
                if (filterOpt.series != "") filterOptions.push({ key: "Series", ru_key: "Серия", value: filterOpt.series });
                if (filterOpt.price != 0) filterOptions.push({ key: "Price", ru_key: "Цена", value: filterOpt.price });
                if (filterOpt.shipping_time != "") filterOptions.push({ key: "Shippingtime", ru_key: "Время доставки", value: filterOpt.shipping_time });
                if (filterOpt.shape != "") filterOptions.push({ key: "Shape", ru_key: "Форма", value: filterOpt.shape });
                if (filterOpt.width != 0) filterOptions.push({ key: "Width", ru_key: "Ширина", value: filterOpt.width });
                if (filterOpt.equipment != 0) filterOptions.push({ key: "Equipment", ru_key: "Комплектация", value: filterOpt.equipment });
                if (filterOpt.depth != 0) filterOptions.push({ key: "Depth", ru_key: "Глубина", value: filterOpt.depth });
                if (filterOpt.material != "") filterOptions.push({ key: "Material", ru_key: "Материал", value: filterOpt.material });
                if (filterOpt.length != "") filterOptions.push({ key: "Length", ru_key: "Длина", value: filterOpt.length });
                if (filterOpt.installation_type != "") filterOptions.push({ key: "InstallationType", ru_key: "Монтаж", value: filterOpt.installation_type });
                if (filterOpt.color != "") filterOptions.push({ key: "Color", ru_key: "Цвет", value: filterOpt.color });
                if (filterOpt.form != "") filterOptions.push({ key: "Form", ru_key: "Форма", value: filterOpt.form });
                if (filterOpt.type != "") filterOptions.push({ key: "Type", ru_key: "Тип", value: filterOpt.type });
                if (filterOpt.control_type != "") filterOptions.push({ key: "ControlType", ru_key: "Тип упрaвления", value: filterOpt.control_type });
                if (filterOpt.country_vendor != "") filterOptions.push({ key: "CountryVendor", ru_key: "Страна производитель", value: filterOpt.country_vendor });
                if (filterOpt.height != "") filterOptions.push({ key: "Height", ru_key: "Рост", value: filterOpt.height });
                if (filterOpt.bowl_width != 0) filterOptions.push({ key: "Bowlwidth", ru_key: "Ширина чаши", value: filterOpt.bowl_width });
                if (filterOpt.bowl_diameter != 0) filterOptions.push({ key: "Bowldiameter", ru_key: "Диаметр чаши", value: filterOpt.bowl_diameter });
            }
            const buy = product.buy_with === null || product.buy_with === '' ? [] : product.buy_with.split('-');
            const alter = product.alter_product === null || product.alter_product === '' ? [] : product.alter_product.split('-');
            if (product !== null)
                retproduct.push({
                    id: pID,
                    title: product === null ? '' : product.title,
                    is_featured: product.is_featured,
                    is_hot: product === null ? 0 : product.is_hot,
                    is_new: product.is_new === 0 ? false: true,
                    price: product === null ? 0 : parseFloat(product.price),
                    sale_price: product === null ? 0 : parseFloat(product.discount),
                    vendor: product.vendor,
                    review: parseFloat(product.rating),
                    is_out_of_stock: product.is_out_of_stock,
                    depot: parseFloat(product.depot),
                    sku: product.sku,
                    id_sku: product.id_sku,
                    description_1: product.description_1,
                    weight: parseFloat(product.weight),
                    inventory: parseFloat(product.inventory),
                    is_active: product.is_active,
                    is_sale: product.is_sale,
                    currency: product.currency,
                    discount_percent: product.discount_percent,
                    available: product.available,
                    url: product.img,
                    buy_with: buy,
                    alter_product: alter,
                    created_at: product.created_at,
                    updated_at: product.update,
                    variants: [],
                    icon: product.icon,
                    quantity: 0,
                    sub_category_id: product.sub_category_id,
                    rect: [
                        product.positionL,
                        product.positionT,
                        product.positionW,
                        product.positionH
                    ],
                    filterOptions,
                    images: productImage,
                    thumbnail,
                    product_categories: [category],
                    brands: [brands],
                    collections: []
                });
        })
        setTimeout(() => {
            res.json(retproduct);
        }, 2000)
    } catch (err) {
        console.log(err)
    }
}

router.get('/getAllProducts', (req, res) => {

    try {
        Category.hasMany(Product, { foreignKey: 'category_id' });
        Product.belongsTo(Category, { foreignKey: 'category_id' })
        ProductImage.hasOne(Product, { foreignKey: 'productImageId' });
        Product.belongsTo(ProductImage, { foreignKey: 'productImageId' });
        ProductThumbnail.hasMany(Product, { foreignKey: 'thumbnailId' });
        Product.belongsTo(ProductThumbnail, { foreignKey: 'thumbnailId' });
        Brand.hasMany(Product, { foreignKey: 'brand_id' });
        Product.belongsTo(Brand, { foreignKey: 'brand_id' });
        Filter_Options.hasMany(Product, { foreignKey: 'filterId' });
        Product.belongsTo(Filter_Options, { foreignKey: 'filterId' });
        Product.findAll({
            include: [Category, ProductImage, ProductThumbnail, Brand, Filter_Options]
        }).then((products) => {
            makeReturnProductData(products, req, res);
        })
    } catch (err) {
        res.json(err)
    }
});


router.get('/', (req, res) => {
    let limits = {};
    if (req.query.limit) {
        limits = {
            offset: (req.query._start) ? parseInt(req.query._start) : 0,
            limit: parseInt(req.query._limit)
        }

        Product.findAndCountAll({
            ...limits, // <---- here three dots are ES6 syntax , so don't ignore that)
            include: [Category, ProductImage, ProductThumbnail, Brand, Filter_Options]
        }).then(products => {
            makeReturnProductData2(products.rows, req, res);
        })
    } else if (req.query.limit == undefined && req.query.title_contains == undefined) {
        Product.findAndCountAll({
            ...limits, // <---- here three dots are ES6 syntax , so don't ignore that)
        }).then(products => {
            makeReturnProductData2(products.rows, req, res);
        })
    } else if (req.query.title_contains != undefined) {
        const keyword = req.query.title_contains;
        Product.findAll({
            where: {
                title: Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('title')), 'LIKE', '%' + keyword.toLowerCase() + '%')
            }
        }).then(products => {
            makeReturnProductData2(products, req, res);
        })
    }

});


router.get('/count', (req, res) => {
    Product.count().then(count => {
        res.json(count)
    })
});



router.put('/:id', async(req, res) => {
    const upsertbody = req.body;
    const sku = req.params.id;
    if (upsertbody.sku === undefined) res.send({ success: false })

    let buyWith = '';
    let alterPro = '';
    if (upsertbody.buyWith !== undefined)
        upsertbody.buyWith.map((item) => {
            let prefix = buyWith.length === 0 ? "" : "-";
            buyWith += prefix;
            buyWith += item.product_sku;
        });
    if (upsertbody.alternativeProducts !== undefined)
        upsertbody.alternativeProducts.map((item) => {
            let prefix = alterPro.length === 0 ? "" : "-";
            alterPro += prefix;
            alterPro += item.product_sku;
        });

    const insertbody = {
        sku: upsertbody.sku,
        id_sku: upsertbody.mpn,
        vendor_id: upsertbody.vendorId,
        category_id: upsertbody.categoryId,
        sub_category_id: upsertbody.subCategoryId,
        img: upsertbody.pictures[0].img === undefined ? '' : upsertbody.pictures[0].img,
        Brand_id: upsertbody.brandId === undefined ? 0 : upsertbody.brandId,
        collection_id: upsertbody.collectionId,
        vendor: upsertbody.vendor,
        title: upsertbody.name,
        description_1: upsertbody.description1,
        inventory: upsertbody.inventory,
        currency: upsertbody.currency,
        status: upsertbody.status,
        series: upsertbody.series,
        price: upsertbody.productPrice,
        discount: upsertbody.discountPrice,
        discount_percent: upsertbody.discountPercent,
        is_sale: upsertbody.is_sale,
        is_active: upsertbody.is_active,
        available: upsertbody.available,
        weight: upsertbody.weight,
        buy_with: buyWith,
        alter_product: alterPro
    }

    if (sku) {
        const id = await upsert(insertbody, { sku }).then(async function(result) {
            await insertImages(upsertbody.pictures, result.id);
            const thumb = await insertThumbnail(upsertbody.pictures[0], result.id);
            const filter = await insertFilter(upsertbody.parameters, result.id, result.price);
            res.status(200).send({ success: true });
        });
    } else
        res.send({ success: false });
})

async function insertImages(data, id) {
    const ret = await data.map((item, index) => {
        const image = item.img == undefined ? '' : item.img;
        const ext = image.split(".")[image.split(".").length - 1];
        const insertData = {
            product_id: id,
            name: "" + index + cst[index],
            ext: ext,
            mime: "image/jpeg",
            url: image
        };
        upsertImages(insertData, { product_id: id }).then(function(result) {
            return result;
        });
    });
}

function insertThumbnail(data, id) {
    const image = data.img == undefined ? '' : data.img;
    const ext = image.length === 0 ? "" : '.' + image.split(".")[image.split(".").length - 1];
    const name = image.length === 0 ? '' : image.split("/")[image.split("/").length - 1];
    const url = image.length === 0 ? null : image;
    const insertData = {
        product_id: id,
        name: name,
        ext: ext,
        mime: "image/jpeg",
        url: url,
    };
    return upsertThumbnail(insertData, { product_id: id }).then(function(result) {
        return result;
    });
}

async function insertFilter(data, id, price) {
    const insertData = {
        product_id: id,
        price: parseFloat(price)
    };
    await data.map((item) => {
        const name = item.parameter_value;
        const strID = item.parameter_id.split("_")[1].toLowerCase();

        let id = -1;
        if (strID === "brand")
            id = 189;
        else if (strID === "series")
            id = 190;
        else id = parseInt(strID) - 1;
        if (id !== -1) {
            if (enFilters[id] === "height" || enFilters[id] === "length" || enFilters[id] === "depth" || enFilters[id] === "width")
                insertData[`${enFilters[id]}`] = parseFloat(name);
            else insertData[`${enFilters[id]}`] = name;
        }
    })

    return upsertFilter(insertData, { product_id: id }).then(function(result) {
        return result;
    });
}

router.get('/category/Id/:id', (req, res) => {
    const slug = req.params.id;
    // Category.findOne({
    //     where: {
    //         Slug: slug
    //     }
    // }).then((cate)=>{
    // if( cate != null ){
    Product.findAll({
            where: {
                category_id: parseInt(slug) // cate.CategoryID
            }
        }).then(product => {
            makeReturnProductData2(product, req, res);
        })
        // }else{
        //     res.json([])
        // }
        // })
});

router.get('/query', (req, res) => {
    const slug = req.query;

    let condition = {};
    if (slug.section) {
        condition['sectionID'] = parseInt(slug.section);
    }
    if (slug.category) {
        condition['category_id'] = parseInt(slug.category);
    }
    if (slug.subcategory) {
        condition['sub_category_id'] = parseInt(slug.subcategory);
    }
    console.log("backend params :: ", slug, condition)

    Product.findAll({
        where: condition
    }).then(product => {
        makeReturnProductData2(product, req, res);
    })
})

router.get('/subcategory/:id', (req, res) => {
    const slug = req.params.id;
    console.log(slug, "<=======server sub category id")
    Product.findAll({
        where: {
            sub_category_id: parseInt(slug) // cate.CategoryID
        }
    }).then(product => {
        makeReturnProductData2(product, req, res);
    })
});

router.get('/slug/Id/:id', (req, res) => {
    const slug = req.params.id;
    if( slug === "funiture_best_sellers" || slug === "furniture_trending_products" || slug === "new" || slug === "sales" ){
        let condition = {};
        if( slug === "funiture_best_sellers" ){
            condition["is_hot"] = true;
        } else if( slug === "furniture_trending_products") {
            condition["is_featured"] = true;
        } else if(slug === "new"){
            condition["is_new"] = true;
        } else {
            condition["is_sale"] = true;
        }
        Product.findAll({
            where: condition
        }).then(product => {
            makeReturnProductData2(product, req, res);
        })
    } else {
        Collection.findOne({
            where: {
                Tag: slug
            }
        }).then((cate) => {
            if (cate != null) {
                Product.findAll({
                    where: {
                        collection_id: cate.CollectionID
                    }
                }).then(product => {
                    makeReturnProductData2(product, req, res);
                })
            } else {
                res.json([])
            }
        });
    }
});

router.get('/brand/Id/:id', (req, res) => {
    console.log(req.params.id)
    const id = req.params.id;
    Product.findAll({
        where: {
            Brand_id: id
        }
    }).then(product => {
        makeReturnProductData2(product, req, res);
    })

});

router.get('/:id', (req, res) => {
    Product.findByPk(req.params.id).then(product => {
        makeReturnProductData2([product], req, res);
    })
});

// router.put('/:id', (req, res) => {

//     Product.update(req.body, {where: {id: req.params.id}, returning: true, plain: true}).then(([, model]) => {
//         res.json(model.dataValues);
//     })
// });

router.post('/', (req, res) => {
    let product = req.body;
    if (product.id) {
        delete product.id;
    }
    Product.create(req.body).then(product => {
        res.json(product);
    })

});

router.delete('/:id', (req, res) => {
    Product.destroy({ where: { product_id: req.params.id } }).then(response => {
        res.json(response);
    })

});


function upsert(values, condition) {
    return Product
        .findOne({ where: condition })
        .then(function(obj) {
            // update
            if (obj)
                return obj.update(values);
            // insert
            return Product.create(values);
        })
}


function upsertImages(values, condition) {
    return ProductImage
        .findOne({ where: condition })
        .then(function(obj) {
            // update
            if (obj)
                return obj.update(values);
            // insert
            return ProductImage.create(values);
        })
}


function upsertThumbnail(values, condition) {
    return ProductThumbnail
        .findOne({ where: condition })
        .then(function(obj) {
            // update
            if (obj)
                return obj.update(values);
            // insert
            return ProductThumbnail.create(values);
        })
}

function upsertFilter(values, condition) {
    return Filter_Options
        .findOne({ where: condition })
        .then(function(obj) {
            // update
            if (obj)
                return obj.update(values);
            // insert
            return Filter_Options.create(values);
        })
}

module.exports = router;