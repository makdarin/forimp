import express from "express";
import { Product, Category, Collection } from "../db/models";
import config from "../config";
import fs from "fs";
import path from "path";
import { getCategoryById, getProductImagesById, getProductThumbnailById, getBrandById, getFilterOptionsByID } from './utilitis';
// import {tempProducts , otherData, enFilters} from "../../temp";

const Sequelize = require('sequelize');
const router = express.Router();

const Op = Sequelize.Op;
const cst = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m","n","o","p"];

router.get('/images-list', (req, res) => {
  fs.readdir(path.resolve(process.env.PWD + '/public/assets/products/'), (err, files) => {
    files = files.filter(item => !(/(^|\/)\.[^\/\.]/g).test(item)).map(f => config.apiUrl + '/assets/products/' + f);
    res.json(files);
  });
});

function makeReturnProductData(products, req, res){
    try{
        let retproduct = [];
        products.map( async (product, index) => {
            const pID = product.id === null ? 0 : product.id;
            const cID = product.category_id;
            const bID = product.brand_id;
            const category = cID !== null ? await getCategoryById(cID) : {} ;
            const productImage = await getProductImagesById(pID);
            const thumbnail = await getProductThumbnailById(pID);
            const brands = bID > 0 ? await getBrandById(bID): {};
            const filterOpt = await getFilterOptionsByID(pID);

            let filterOptions = [];
            if( filterOpt != undefined ){
                if( filterOpt.brand != "" ) filterOptions.push({key:"Brand", value:filterOpt.brand});
                if( filterOpt.series != "" ) filterOptions.push({key:"Series", value:filterOpt.series});
                if( filterOpt.price != 0 ) filterOptions.push({key:"Price", value:filterOpt.price});
                if( filterOpt.shipping_time != "" ) filterOptions.push({key:"Shippingtime", value:filterOpt.shipping_time});
                if( filterOpt.shape != "" ) filterOptions.push({key:"Shape", value:filterOpt.shape});
                if( filterOpt.width != 0 ) filterOptions.push({key:"Width", value:filterOpt.width});
                if( filterOpt.equipment != 0 ) filterOptions.push({key:"Equipment", value:filterOpt.equipment});
                if( filterOpt.depth != 0 ) filterOptions.push({key:"Depth", value:filterOpt.depth});
                if( filterOpt.material != "" ) filterOptions.push({key:"Material", value:filterOpt.material});
                if( filterOpt.length != "" ) filterOptions.push({key:"Length", value:filterOpt.length});
                if( filterOpt.installation_type != "" ) filterOptions.push({key:"InstallationType", value:filterOpt.installation_type});
                if( filterOpt.color != "" ) filterOptions.push({key:"Color", value:filterOpt.color});
                if( filterOpt.form != "" ) filterOptions.push({key:"Form", value:filterOpt.form});
                if( filterOpt.type != "" ) filterOptions.push({key:"Type", value:filterOpt.type});
                if( filterOpt.control_type != "" ) filterOptions.push({key:"ControlType", value:filterOpt.control_type});
                if( filterOpt.country_vendor != "" ) filterOptions.push({key:"CountryVendor", value:filterOpt.country_vendor});
                if( filterOpt.height != "" ) filterOptions.push({key:"Height", value:filterOpt.height});
                if( filterOpt.bowl_width != 0 ) filterOptions.push({key:"Bowlwidth", value:filterOpt.bowl_width});
                if( filterOpt.bowl_diameter != 0 ) filterOptions.push({key:"Bowldiameter", value:filterOpt.bowl_diameter});
            }
            retproduct.push({
                id:pID,
                title:product.title,
                is_featured:product.is_featured,
                is_hot:product.is_hot,
                price: parseFloat(product.price),
                sale_price:parseFloat(product.discount),
                vendor:product.vendor,
                review:parseFloat(product.rating),
                is_out_of_stock:product.is_out_of_stock,
                depot:parseFloat(product.depot),
                sku:product.sku,
                weight:parseFloat(product.weight),
                inventory:parseFloat(product.inventory),
                is_active:product.is_active,
                is_sale:product.is_sale,
                created_at:product.created_at,
                updated_at:product.update,
                variants:[],
                icon:product.icon,
                rect:[
                    product.positionL,
                    product.positionT,
                    product.positionW,
                    product.positionH
                ],
                filterOptions,
                images: productImage,
                thumbnail,
                product_categories: [category],
                brands:[brands],
                collections:[]
            });
        })
        setTimeout(()=>{
            res.json(retproduct);
        }, 3000)
    }
    catch(err){
        console.log(err)
    }
}

router.get('/getAllProducts',  (req, res) => {
    Product.findAll().then( products => {
        // res.json(products);
        makeReturnProductData(products, req, res);
    })
   
});

router.get('/',  (req, res) => {
    let limits = {};
    if(req.query.limit){
        limits = {
            offset: (req.query._start) ? parseInt(req.query._start) : 0,
            limit: parseInt(req.query._limit)
        }
        Product.findAndCountAll({
            ...limits , // <---- here three dots are ES6 syntax , so don't ignore that)
        }).then( products => {
            makeReturnProductData(products.rows, req, res);
        })
    }else if( req.query.limit == undefined && req.query.title_contains == undefined ){
        Product.findAndCountAll({
            ...limits , // <---- here three dots are ES6 syntax , so don't ignore that)
        }).then( products => {
            makeReturnProductData(products.rows, req, res);
        })
    }else if( req.query.title_contains != undefined ){
        const keyword = req.query.title_contains;
        Product.findAll({
            where: {
                title:Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('title')), 'LIKE', '%' + keyword.toLowerCase() + '%')
            }
        }).then( products => {
            makeReturnProductData(products, req, res);
        })
    }
    
});


router.get('/count', (req, res) => {
    Product.count().then(count => {
        res.json(count)
    })
});



router.get('/category/Id/:id', (req, res) => {
    const slug = req.params.id;
    Category.findOne({
        where: {
            Slug: slug
        }
    }).then((cate)=>{
        if( cate != null ){
            Product.findAll({
                where : {
                    category_id: cate.CategoryID
                }
            }).then(product => {
                makeReturnProductData(product, req, res);
            })
        }else{
            res.json([])
        }
    })
});


router.get('/slug/Id/:id', (req, res) => {
    const slug = req.params.id;
    Collection.findOne({
        where: {
            Tag: slug
        }
    }).then((cate)=>{
        if( cate != null ){
            Product.findAll({
                where : {
                    collection_id: cate.CollectionID
                }
            }).then(product => {
                makeReturnProductData(product, req, res);
            })
        }else{
            res.json([])
        }
    })
});

router.get('/brand/Id/:id', (req, res) => {
    console.log(req.params.id)
    const id = req.params.id;
    Product.findAll({
        where : {
            Brand_id: id
        }
    }).then(product => {
        makeReturnProductData(product, req, res);
    })
    
});

router.get('/:id', (req, res) => {
    Product.findByPk(req.params.id).then(product => {
        makeReturnProductData([product], req, res);
    })
});

router.put('/:id', (req, res) => {
    
    Product.update(req.body, {where: {id: req.params.id}, returning: true, plain: true}).then(([, model]) => {
        res.json(model.dataValues);
    })
});

router.post('/', (req, res) => {
    let product = req.body;
    if (product.id) {
        delete product.id;
    }
    Product.create(req.body).then(product => {
        res.json(product);
    })

});

router.delete('/:id', (req, res) => {
    Product.destroy({where: {id: req.params.id}}).then(response => {
        res.json(response);
    })

});

module.exports = router;
