import express from "express";
import { Cart } from "../db/models";
import { Product } from "../db/models";
import { getProductImagesById, getProductThumbnailById } from './utilitis';

const router = express.Router();
const { Op } = require("sequelize");

router.post('/get', (req, res) => {
  const id = req.body.auth.data.user.CustomerID === undefined ? req.body.auth.data.user.id : req.body.auth.data.user.CustomerID;
  try {
    Product.hasMany(Cart)
    Cart.belongsTo(Product)
    Cart.findAll({
      where: {
        CustomerID: id
      },
      include: Product
    }).then( (cart) => {
      const cartItems = [];
      cart.map(async (item) => {
        const product = item.Product;
        const productImage = await getProductImagesById(product.id);
        const thumbnail = await getProductThumbnailById(product.id);
        cartItems.push({
          id:product.id,
          title:product === null ? '' : product.title,
          is_featured:product.is_featured,
          is_hot:product === null ? 0 : product.is_hot,
          price:product === null ? 0 : parseFloat(product.price),
          sale_price: product === null ? 0 :parseFloat(product.discount),
          vendor:product.vendor,
          review:parseFloat(product.rating),
          is_out_of_stock:product.is_out_of_stock,
          depot:parseFloat(product.depot),
          sku:product.sku,
          id_sku:product.id_sku,
          weight:parseFloat(product.weight),
          inventory:parseFloat(product.inventory),
          is_active:product.is_active,
          is_sale:product.is_sale,
          currency: product.currency,
          discount_percent:product.discount_percent,
          available: product.available,
          buy_with: [],
          alter_product: [],
          created_at:product.created_at,
          updated_at:product.update,
          variants:[],
          icon:product.icon,
          quantity:item.Quantity,
          rect:[
              product.positionL,
              product.positionT,
              product.positionW,
              product.positionH
          ],
          filterOptions:[],
          images: productImage,
          thumbnail,
          product_categories: [],
          brands:[],
          collections:[]
        });
      });
      setTimeout(()=>{
        res.json({
          cartItems,
          amount:cart.length !== 0 ? cart[0].amount : 0,
          cartTotal: cart.length !== 0? cart[0].cartTotal: 0,
          discount: cart.length !== 0? cart[0].discount: 0,
          totalweight: cart.length !== 0? cart[0].totalweight : 0,
          designdiscount: cart.length !== 0? cart[0].designeddiscount: 0,
          designdamount: cart.length !== 0? cart[0].designedamount: 0,
          collectionSlug: cart.length !== 0? cart[0].collectionSlug: 0
        })
      }, 1000);
    })
  } catch(err) {
    res.json(err)
  }
});

router.post('/add', async (req, res) => {
  if( req.body.currentCart === null )
    clear(req, res);
  else{
    const { cartItems, amount, cartTotal, discount, totalweight, designdiscount, designdamount, collectionSlug } = req.body.currentCart;
    const authID = req.body.auth.data.user.CustomerID === undefined ? req.body.auth.data.user.id : req.body.auth.data.user.CustomerID;
    const rmID = req.body.remove;

    try {
      if( rmID !== undefined ){
        remove(rmID, authID, cartItems.length, res);
      }
      await cartItems.map( async (product) => {
        Cart.findOne({
          where:{
            CustomerID: authID,
            ProductID: product.id,
          }
        }).then(async function(cart){
          if( cart ){
            await updateCart(cart.CartID, product.quantity, amount, cartTotal, discount, totalweight, designdiscount, designdamount, collectionSlug);
          } else{
            await Cart.create({
              CustomerID: parseInt(authID),
              ProductID: parseInt(product.id),
              Quantity: parseInt(product.quantity),
              amount:parseFloat(amount),
              cartTotal: parseInt(cartTotal),
              discount: parseInt(discount),
              totalweight:parseFloat(totalweight),
              designeddiscount: parseInt(designdiscount),
              designedamount:parseFloat(designdamount),
              collectionSlug:collectionSlug,
              createAt: Date.now(),
              updateAt: Date.now(),
            });
          }
        });
      });
      res.json({success:true});
    } catch (err) {
      res.json({success:false});
    }
  }
});

const updateCart =async (cid, q, amt, total, discount, totalweight, ddiscount, disamt, slug) => {
  try {
    Cart.update({
      Quantity: q,
      amount:amt,
      cartTotal: total,
      discount:discount,
      totalweight:totalweight,
      designeddiscount: ddiscount,
      designedamount:disamt,
      collectionSlug:slug,
      updateAt: Date.now(),
    },{
      where: {
        [Op.and]: [
          { CartID: cid }
        ]
      },
    })
  } catch (err) {
    console.log(err);
  }
}

const clear= async (req, res) => {
  const id = req.body.auth.data.user.CustomerID === undefined ? req.body.auth.data.user.id : req.body.auth.data.user.CustomerID;
  try {
    const cart = Cart.destroy({
      where: {
        [Op.and]: [
          { CustomerID:id }
        ]
      },
    });
    res.json({success:true})
  } catch (err) {
    res.json({success:false});
  }
};

const remove = (pID, aID, len, res) => {
  try {
    Cart.destroy({
      where: {
        [Op.and]: [
          { ProductID:pID },
          { CustomerID: aID }
        ]
      },
    });
  } catch (err) {
    console.log(err);
  }
};

router.post('/increase', (req, res) => {
  const id = req.body.auth.data.user.CustomerID === undefined ? req.body.auth.data.user.id : req.body.auth.data.user.CustomerID;
  try {
    const cart = Cart.update({
      Quantity: req.body.selectedItem.quantity
    },{
      where: {
        [Op.and]: [
          { CartID: req.body.selectedItem.id },
          { CustomerID: id }
        ]
      },
    })
    res.json(cart)
  } catch (err) {
    res.json(err)
  }
});

router.post('/decrease', (req, res) => {
  const id = req.body.auth.data.user.CustomerID === undefined ? req.body.auth.data.user.id : req.body.auth.data.user.CustomerID;
  try {
    const cart = Cart.update({
      Quantity: req.body.selectedItem.quantity
    },{
      where: {
        [Op.and]: [
          { CartID: req.body.selectedItem.id },
          { CustomerID: id }
        ]
      },
    })
    res.json(cart)
  } catch (err) {
    res.json(err)
  }
});


module.exports = router;
