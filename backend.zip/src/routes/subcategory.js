import express from "express";
import { Subcategory } from "../db/models";

const router = express.Router();

router.get('/', (req, res) => {
    Subcategory.findAll().then(category => {
        res.json(category);
    })
});

router.get('/:id', (req, res) => {
    Subcategory.findOne({
        where: { SubCategoryID: parseInt(req.params.id) }
    }).then(category => {
        res.json(category);
    })
});

module.exports = router;