import { Category, ProductImage, ProductThumbnail, Brand, Filter_Options, Collection } from "../db/models";

export function getCategoryById(id){
    return new Promise(async(resolve, reject) => {
        await Category.findOne({
            where: {
              CategoryID: id
            }
        }).then((category) => {
            if (category) {
                resolve(category);
            } else {
                resolve();
            }
        }).catch((err) => {
            reject(err);
        });
    })
}

export function getProductThumbnailById(id){
    return new Promise(async(resolve, reject) => {
        await ProductThumbnail.findOne({
            where: {
                product_id: id
            }
        }).then((thumb) => {
            if (thumb) {
                resolve(thumb);
            } else {
                resolve();
            }
        }).catch((err) => {
            reject(err);
        });
    })
}

export function getFilterOptionsByID(id){
    return new Promise(async(resolve, reject) => {
        await Filter_Options.findOne({
            where: {
                product_id: id
            }
        }).then((fiter) => {
            if (fiter) {
                resolve(fiter.dataValues);
            } else {
                resolve();
            }
        }).catch((err) => {
            reject(err);
        });
    })
}

export function getBrandById(id){
    return new Promise(async(resolve, reject) => {
        await Brand.findOne({
            where: {
                BrandID: id
            }
        }).then((brand) => {
            if (brand) {
                resolve(brand);
            } else {
                resolve();
            }
        }).catch((err) => {
            reject(err);
        });
    })
}
export function getProductImagesById(id){
    return new Promise(async(resolve, reject) => {
        await ProductImage.findAll({
            where: {
              product_id: id
            }
        }).then((productimage) => {
            if (productimage) {
                resolve(productimage);
            } else {
                resolve();
            }
        }).catch((err) => {
            reject(err);
        });
    })
}

export function getCollectionBySlug(slug){
    return new Promise(async(resolve, reject) => {
        await Collection.findAll({
            where: {
              Tag: slug.toString()
            }
        }).then((collection) => {
            if (collection) {
                resolve(collection);
            } else {
                resolve();
            }
        }).catch((err) => {
            reject(err);
        });
    })
}
