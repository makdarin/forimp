import express from "express";
import { ShopBanner, MainBanner } from "../db/models";

const router = express.Router();

router.get('/shopbanner',  (req, res) => {
    ShopBanner.findAll().then( sbanner => {
        let out = [];
        sbanner.forEach(e => {
            let txts = e.content === null ? "" : e.content.split(';');
            let txtsRu = e.contentRu === null ? "" : e.contentRu.split(';');
            let txtsUa = e.contentUa === null ? "" : e.contentUa.split(';');
            let txtsDe = e.contentDe === null ? "" : e.contentDe.split(';');
            let txtsFr = e.contentFr === null ? "" : e.contentFr.split(';');
            let txtsPl = e.contentPl === null ? "" : e.contentPl.split(';');
            out.push({
                id: e.id,
                type: e.type,
                img: e.img,
                url: e.url,
                title: {
                    ru: e.titleRu,
                    en: e.titleEn,
                    ua: e.titleUa,
                    de: e.titleDe,
                    fr: e.titleFr,
                    pl: e.titlePl
                },
                content:  {
                    ru: txtsRu,
                    en: txts,
                    ua: txtsUa,
                    de: txtsDe,
                    fr: txtsFr,
                    pl: txtsPl
                },
            })
        });
        res.json(out);
    })
});

router.get('/mainbanner',  (req, res) => {
    MainBanner.findAll().then( mbanner => {
        let out = [];
        mbanner.forEach(e => {
            if(e.active)
                out.push({
                    id: e.id,
                    img: e.img,
                    title: {
                        ru: e.titleRu,
                        en: e.titleEn,
                        ua: e.titleUa,
                        de: e.titleDe,
                        fr: e.titleFr,
                        pl: e.titlePl
                    },
                    subtitle: {
                        ru: e.subtitleRu,
                        en: e.subtitleEn,
                        ua: e.subtitleUa,
                        de: e.subtitleDe,
                        fr: e.subtitleFr,
                        pl: e.subtitlePl
                    },
                    btn: {
                        ru: e.btnTextRu,
                        en: e.btnTextEn,
                        ua: e.btnTextUa,
                        de: e.btnTextDe,
                        fr: e.btnTextFr,
                        pl: e.btnTextPl
                    },
                    url: e.btnurl
                })
        });
        res.json(out);
    })
});
module.exports = router;