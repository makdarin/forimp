import express from "express";
import { News } from "../db/models";
import config from "../config";

const router = express.Router();

router.get('/',  (req, res) => {
    News.findAll().then( news => {
        let out = [];
        news.forEach(e => {
            out.push({
                id: e.id,
                title:e.title,
                description:e.content,
                thumbnail: e.url,
                date: e.createdAt
            })
        });
        res.json(out);
    })
});

module.exports = router;