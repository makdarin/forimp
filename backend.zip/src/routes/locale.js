import express from "express";
import { Locale } from "../db/models";

const router = express.Router();


router.get('/:id', async(req, res) => {

    const id = req.params.id;
    const ret = {};
    Locale.findAll().then(locale => {
        locale.forEach(element => {
            ret[`${element.name}`] = element[`${id}`]
        });
        res.json(ret);
    });
});

router.post('/', async(req, res) => {
    const retRu = {};
    const retEn = {};
    const retUa = {};
    Locale.findAll().then(locale => {
        locale.forEach((item) => {
            retRu[`${item.name}`] = item[`ru`];
            retEn[`${item.name}`] = item[`en`];
            retUa[`${item.name}`] = item[`ua`];
        });
        res.json({
            ru: retRu,
            en: retEn,
            ua: retUa
        });
    });

});


module.exports = router;