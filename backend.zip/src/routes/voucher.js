import express from "express";
import { Voucher, Product } from "../db/models";

const router = express.Router();


router.get('/', (req, res) => {
    Voucher.findAll().then( vouchers => {
        res.json(vouchers);
    })
});


module.exports = router;