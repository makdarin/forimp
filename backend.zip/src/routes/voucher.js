import express from "express";
import { Voucher, Product } from "../db/models";

const router = express.Router();


router.get('/', (req, res) => {
    // console.log("this is server slugin ==> " , req.query.slug_in)
    // const slugin = req.query.slug_in;
    Voucher.findAll().then( vouchers => {
        res.json(vouchers);
    })
});


module.exports = router;