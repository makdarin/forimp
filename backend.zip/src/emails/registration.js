const config = require("../config")

module.exports = function (email) {
    console.log(email)
    return {
        to: email,
        from: config.EMAIL_FROM,
        subject: 'Акаунт создан',
        html: `
            <h1>Добро пожаловать в наш магазин</h1>
            <p>Вы успешно создали акаунт с email - ${email}</p>
            <hr/>
            <a href="${config.BASE_URL}">Аквамаркет - магазин сантнехники</a>
       `,
        // attachments: [{
        //     filename: 'logo.png',
        //     path: '/static',
        //     cid: 'cid:unique@test.ee'
        // }]
    }

}