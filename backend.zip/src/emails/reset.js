const config = require("../config")

module.exports = function (email, token) {
    console.log(email)
    return {
        to: email,
        from: config.EMAIL_FROM,
        subject: 'Востановление доступа',
        html: `
            <h1>Вы забыли пароль?</h1>
            <p>Если нет, то проигнорируйте данное письмо</p>
            <p>Иначе нажмите на ссылку ниже:</p>
            <p><a href="${config.BASE_URL}/account/password?token=${token}">Востановить доступ</a></p>
            <hr/>
            <a href="${config.BASE_URL}">Магазин сантнехники</a>
       `
    }

}