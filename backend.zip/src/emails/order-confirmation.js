const config = require("../config")

module.exports = function (email, orderId) {
    // console.log(email)
    return {
        to: email,
        from: config.EMAIL_FROM,
        subject: 'Ваш заказ успешно оформлен',
        html: `
            <h1>Ваш заказ успешно оформлен!</h1>
            <p>Спасибо за заказ. Наш менеджер свяжется с Вами по телефону или e-mail для подтверждения заказа, адреса и времени доставки.</p>
            <p>Номер вашего заказа: ${orderId}</p>
            <hr/>
            <a href="${config.BASE_URL}">Аквамаркет - магазин сантнехники</a>
       `,
    }

}